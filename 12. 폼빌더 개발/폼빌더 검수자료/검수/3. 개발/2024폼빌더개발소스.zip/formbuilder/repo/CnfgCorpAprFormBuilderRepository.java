package com.lgu.abc.cnfg.corp.apr.formbuilder.repo;

import java.util.HashMap;
import java.util.List;

import com.lgu.abc.cnfg.corp.apr.form.CnfgCorpAprForm;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilderList;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilderQuery;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilderView;

/**
 * #2643 폼빌더 기능 개발
 */
public interface CnfgCorpAprFormBuilderRepository {
	public void create(CnfgCorpAprFormBuilderQuery entity);
	public void update(CnfgCorpAprFormBuilderQuery entity);
	public void aprUpdate(CnfgCorpAprForm form);
	public List<CnfgCorpAprFormBuilderList> getFormCount(CnfgCorpAprFormBuilder query);
	public List<CnfgCorpAprFormBuilderList> getFormList(CnfgCorpAprFormBuilder query);
	public CnfgCorpAprFormBuilderList getFormContent(Long formBuilderSeq);
	public void saveFormView(CnfgCorpAprFormBuilderView view);
	public HashMap aprDocRead(CnfgCorpAprFormBuilder query);
	public int findDupFormTitle(CnfgCorpAprFormBuilderQuery query);
	public int remove(CnfgCorpAprFormBuilderQuery entity) ;
	public int aprRemove(CnfgCorpAprFormBuilderQuery entity) ;
	// #3149 [구현-양식관리] 폼빌더 양식 임시저장 처리
	public int selectTempForm(CnfgCorpAprFormBuilderQuery entity);
}