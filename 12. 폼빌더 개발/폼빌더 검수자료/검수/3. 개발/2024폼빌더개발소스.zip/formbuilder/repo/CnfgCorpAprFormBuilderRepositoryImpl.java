package com.lgu.abc.cnfg.corp.apr.formbuilder.repo;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgu.abc.cnfg.corp.apr.form.CnfgCorpAprForm;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilderList;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilderQuery;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilderView;

/**
 * #2643 폼빌더 기능 개발
 */
@Repository("cnfgCorpAprFormBuilderRepository")
public class CnfgCorpAprFormBuilderRepositoryImpl implements CnfgCorpAprFormBuilderRepository {
	
	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;
	
	@Override
	public void create(CnfgCorpAprFormBuilderQuery entity) {
		sqlSessionTemplate.update("com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder.create", entity);
	}
	
	@Override
	public void update(CnfgCorpAprFormBuilderQuery entity) {
		sqlSessionTemplate.update("com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder.update", entity);
	}
	
	@Override
	public void aprUpdate(CnfgCorpAprForm form) {
		sqlSessionTemplate.update("com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder.aprUpdate", form);
	}
	
	@Override
	public int remove(CnfgCorpAprFormBuilderQuery entity) {
		return sqlSessionTemplate.delete("com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder.remove", entity);
	}
	
	@Override
	public int aprRemove(CnfgCorpAprFormBuilderQuery entity) {
		return sqlSessionTemplate.delete("com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder.aprRemove", entity);
	}
	
	@Override
	public List<CnfgCorpAprFormBuilderList> getFormList(CnfgCorpAprFormBuilder query) {
		return sqlSessionTemplate.selectList("com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder.list", query);
	}
	
	@Override	
	public List<CnfgCorpAprFormBuilderList> getFormCount(CnfgCorpAprFormBuilder query) {
		return sqlSessionTemplate.selectList("com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder.formcount", query);
	}
	
	@Override
	public CnfgCorpAprFormBuilderList getFormContent(Long formSeq) {
		return sqlSessionTemplate.selectOne("com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder.selectContent", formSeq);
	}	
	
	@Override
	public void saveFormView(CnfgCorpAprFormBuilderView entity) {
		sqlSessionTemplate.update("com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder.saveFormView", entity);
	}
	@Override
	public HashMap aprDocRead(CnfgCorpAprFormBuilder query) {
		return sqlSessionTemplate.selectOne("com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder.aprdocread", query);
	}
	@Override
	public int findDupFormTitle(CnfgCorpAprFormBuilderQuery query) {
		return sqlSessionTemplate.selectOne("com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder.findDupFormTitle", query);
	}
	@Override
	public int selectTempForm(CnfgCorpAprFormBuilderQuery query) {
		return sqlSessionTemplate.selectOne("com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder.selectTempForm", query);
	}
}