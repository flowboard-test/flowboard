package com.lgu.abc.cnfg.corp.apr.formbuilder;

import lombok.Data;
import lombok.ToString;

/**
 * #2643 폼빌더 기능 개발
 */
@ToString(callSuper = true, includeFieldNames = true)
public @Data class CnfgCorpAprFormBuilderQuery {
	private Long formBuilderSeq;
	private Long corpSeq;
	private Long formSeq;
	private String formTitle;
	private String formContent;
	private String regDtime;
	private Long regUsrKey;
	private String modDtime;
	private Long modUsrKey;
}
