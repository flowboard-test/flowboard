package com.lgu.abc.cnfg.corp.apr.formbuilder;

import lombok.Data;
import lombok.ToString;

/**
 * #2643 폼빌더 기능 개발
 */
@ToString(callSuper = true, includeFieldNames = true)
public @Data class CnfgCorpAprFormBuilderList {
	private Long formBuilderSeq;
	private String formTitle;
	private String formContent;
	private String modDtime;
	private String rownum;
	
	private Long formSeq;
	private String keepYy;
	private String keepMm;
	private String docNoForm;
	private Long formDivCdSeq;
}
