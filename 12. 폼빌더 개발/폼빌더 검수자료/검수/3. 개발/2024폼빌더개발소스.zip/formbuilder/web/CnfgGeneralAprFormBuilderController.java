package com.lgu.abc.cnfg.corp.apr.formbuilder.web;

import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gdata.util.common.base.StringUtil;
import com.lgu.abc.apr.apprline.AprApprLine;
import com.lgu.abc.apr.doc.AprDoc;
import com.lgu.abc.cnfg.corp.apr.form.CnfgCorpAprForm;
import com.lgu.abc.cnfg.corp.apr.form.CnfgCorpAprFormService;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilderList;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilderQuery;
import com.lgu.abc.cnfg.corp.apr.formbuilder.service.CnfgCorpAprFormBuilderService;
import com.lgu.abc.core.support.security.crypto.data.CipherDataEncryptor;
import com.lgu.abc.core.support.security.crypto.key.JCEKeyStore;

/**
 * #2643 폼빌더 기능 개발
 */
@Controller("cnfgGeneralAprFormBuilderController")
@RequestMapping(value = "/cnfg/apr/formbuilder")
public class CnfgGeneralAprFormBuilderController {
//	@Autowired
//	private SessionUtil sessionUtil;
	
	private final static CipherDataEncryptor jceEncryptor = new CipherDataEncryptor(new JCEKeyStore());
	@Autowired
	private CnfgCorpAprFormBuilderService builderService;
	
	@Autowired
	private CnfgCorpAprFormService service;

	/**
	 * 미리보기
	 * 
	 * @param model
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/preview")
	public String previewFormContent(Model model, HttpServletRequest request) throws Exception {
		String formTitle = request.getParameter("formTitle");
		String formContent = request.getParameter("formContent");
		String rtnHtml = builderService.previewFormContent(formContent);
		model.addAttribute("rtnHtml", rtnHtml);
		model.addAttribute("formTitle", formTitle);

		return "/cnfg/corp/apr/formbuilder/formPreview.jstl";
	}
	
	/**
	 * #2949 등록된 결재선 리스트
	 * 
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(method = RequestMethod.GET, value = "/apprlist/{form_seq}.json")
	@ResponseBody
	public HashMap findFormApprLineJson(@PathVariable("form_seq") Long form_seq_id, HttpServletRequest req)
			throws Exception {

		String _no = req.getParameter("no");

		return builderService.getApprSavedList(form_seq_id);
	}
	
	/**
	 * #2949 등록된 Doc결재선 리스트
	 * 
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(method = RequestMethod.GET, value = "/apprDoclist/{form_seq}.json")
	@ResponseBody
	public HashMap findFormApprDocLineJson(@PathVariable("form_seq") Long form_seq_id, HttpServletRequest req)
			throws Exception {

		String _no = req.getParameter("no");

		return builderService.getApprDocSavedList(form_seq_id);
	}
	
	/**
	 * 본문 불러오기
	 * 
	 * @param model
	 * @param formBuilderSeq
	 * @param req
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/getformcontent/{id}")
	@ResponseBody
	public ModelAndView getformcontent(Model model, @PathVariable("id") Long formSeq, HttpServletRequest req)
			throws Exception {
		return builderService.getFormContent(formSeq);
	}

	/**
	 * 양식 미리보기(사용자)
	 * 
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/previewPage")
	public ModelAndView previewPage(Model model, @ModelAttribute("model_entity") AprDoc entity) throws Exception {

		if (entity.getAppr_doc_cont() != null) {
			// String apprDocSeqstr =
			// jceEncryptor.decrypt(URLDecoder.decode(entity.getAppr_doc_seq()+"",
			// "UTF-8"));
			// query.setApprDocSeq(Long.parseLong(apprDocSeqstr));
			entity.setAppr_doc_cont(URLDecoder.decode(entity.getAppr_doc_cont(), "UTF-8"));
		}

		return builderService.previewPage(entity);
	}
	
	@SuppressWarnings("rawtypes")
	@RequestMapping(method = RequestMethod.POST, value = "/getaprdoc")
	@ResponseBody
	public HashMap aprDocRead(Model model, @ModelAttribute("model_entity") CnfgCorpAprFormBuilder entity,
			HttpServletRequest req) throws Exception {

		return builderService.aprDocRead(entity);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/previewEditMacroTagChange.json")
	@ResponseBody
	public HashMap<String, String> previewEditMacroTagChange(@ModelAttribute("model_query") CnfgCorpAprForm entity) throws Exception {
		HashMap<String, String> rtnHm = new HashMap<>();
		rtnHm.put("cont", service.previewEditMacroTagChange(entity));
		return rtnHm;
	}
}
