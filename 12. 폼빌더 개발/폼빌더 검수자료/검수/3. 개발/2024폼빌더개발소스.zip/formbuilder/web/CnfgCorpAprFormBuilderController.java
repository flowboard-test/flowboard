package com.lgu.abc.cnfg.corp.apr.formbuilder.web;

import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gdata.util.common.base.StringUtil;
import com.lgu.abc.apr.apprline.AprApprLine;
import com.lgu.abc.apr.doc.AprDoc;
import com.lgu.abc.cnfg.corp.apr.form.CnfgCorpAprForm;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilderList;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilderQuery;
import com.lgu.abc.cnfg.corp.apr.formbuilder.service.CnfgCorpAprFormBuilderService;
import com.lgu.abc.core.support.security.crypto.data.CipherDataEncryptor;
import com.lgu.abc.core.support.security.crypto.key.JCEKeyStore;

/**
 * #2643 폼빌더 기능 개발
 */
@Controller("cnfgCorpAprFormBuilderController")
@RequestMapping(value = "/cnfg/corp/apr/formbuilder")
public class CnfgCorpAprFormBuilderController {
//	@Autowired
//	private SessionUtil sessionUtil;
	
	private final static CipherDataEncryptor jceEncryptor = new CipherDataEncryptor(new JCEKeyStore());
	@Autowired
	private CnfgCorpAprFormBuilderService builderService;

	@RequestMapping(method = RequestMethod.GET, value = "/formedit.jstl")
	public String newFormBuilder(Model model, CnfgCorpAprForm entity, BindingResult errors) throws Exception {
		return "/cnfg/corp/apr/formbuilder/formedit.jstl";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/itemedit.jstl")
	public String editFormItem(Model model, CnfgCorpAprFormBuilder entity, BindingResult errors) throws Exception {
		return "/cnfg/corp/apr/formbuilder/itemedit.jstl";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/editoredit.jstl")
	public String editFormEditor(Model model, CnfgCorpAprFormBuilder entity, BindingResult errors) throws Exception {
		return "/cnfg/corp/apr/formbuilder/editoredit.jstl";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/attachedit.jstl")
	public String editFormAttachFile(Model model, CnfgCorpAprFormBuilder entity, BindingResult errors)
			throws Exception {
		return "/cnfg/corp/apr/formbuilder/attachedit.jstl";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/rowedit.jstl")
	public String editFormDivisionLine(Model model, CnfgCorpAprFormBuilder entity, BindingResult errors)
			throws Exception {
		return "/cnfg/corp/apr/formbuilder/rowedit.jstl";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/inputedit.jstl")
	public String editFormInput(Model model, CnfgCorpAprFormBuilder entity, BindingResult errors) throws Exception {
		model.addAttribute("model_entity", entity);
		return "/cnfg/corp/apr/formbuilder/inputedit.jstl";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/textedit.jstl")
	public String editFormTextarea(Model model, CnfgCorpAprFormBuilder entity, BindingResult errors) throws Exception {
		model.addAttribute("model_entity", entity);
		return "/cnfg/corp/apr/formbuilder/textedit.jstl";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/tableedit.jstl")
	public String editFormTable(Model model, CnfgCorpAprFormBuilder entity, BindingResult errors) throws Exception {
		model.addAttribute("model_entity", entity);
		return "/cnfg/corp/apr/formbuilder/tableedit.jstl";
	}

	/**
	 * 미리보기
	 * 
	 * @param model
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/preview")
	public String previewFormContent(Model model, HttpServletRequest request) throws Exception {
		String formTitle = request.getParameter("formTitle");
		String formContent = request.getParameter("formContent");
		String rtnHtml = builderService.previewFormContent(formContent);
		model.addAttribute("rtnHtml", rtnHtml);
		model.addAttribute("formTitle", formTitle);

		return "/cnfg/corp/apr/formbuilder/formPreview.jstl";
	}

	/**
	 * 양식 저장
	 * 
	 * @param model
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/save")
	@ResponseBody
	public Map<String, Object> saveFormContent(Model model, HttpServletRequest request) throws Exception {

		Map<String, Object> rst = new HashMap<String, Object>();
		CnfgCorpAprFormBuilderQuery rtn = null;
		try {

			String formSeq = request.getParameter("formSeq");

			if (!StringUtils.isEmpty(formSeq)) {

				formSeq = jceEncryptor.decrypt(URLDecoder.decode(formSeq, "UTF-8"));
			}

			rtn = builderService.saveFormContent(request, formSeq);
			rst.put("result", "SUCCESS");
			rst.put("data", rtn);

		} catch (Exception ee) {
			rst.put("result", "FAIL");
			ee.printStackTrace();
		}

		return rst;
	}

	/**
	 * 양식 삭제
	 * 
	 * @param model
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/remove.json")
	@ResponseBody
	public HashMap<String, String> removeFormContent(@ModelAttribute("model_entity") CnfgCorpAprFormBuilderQuery entity)
			throws Exception {
		HashMap<String, String> rtnHm = new HashMap<String, String>();
		rtnHm = builderService.removeFormContent(entity);
		return rtnHm;
	}

	/**
	 * 양식 리스트 페이지 이동
	 * 
	 * @param model
	 * @param mav
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/listpage.jstl")
	public String getFormList(Model model, ModelAndView mav) throws Exception {
		return "/cnfg/corp/apr/formbuilder/list.form.jstl";
	}

	/**
	 * 양식 리스트
	 * 
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(method = RequestMethod.GET, value = "/formlist.json")
	@ResponseBody
	public HashMap findFormCompletedocJson(Model model, @RequestParam("page") Integer page,
			@RequestParam("pageSize") Integer pageSize, @RequestParam("sortField") String sortField,
			@RequestParam("sortDirection") String sortDirection) throws Exception {

		CnfgCorpAprFormBuilder query = new CnfgCorpAprFormBuilder();
		query.setPage(page);
		query.setPageSize(pageSize);
		query.setSortField(sortField);
		query.setSortDirection(sortDirection);

		return builderService.getFormList(query);
	}

	/**
	 * 양식 컨텐츠 json
	 * 
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(method = RequestMethod.POST, value = "/getformcont")
	@ResponseBody
	public CnfgCorpAprFormBuilderList getformcontentJson(Model model, HttpServletRequest req)
			throws Exception {
		
		String formSeq = req.getParameter("id");

		if (!StringUtils.isEmpty(formSeq)) {

			formSeq = jceEncryptor.decrypt(URLDecoder.decode(formSeq, "UTF-8"));
		}
		
		return builderService.getFormContentJson(Long.parseLong(formSeq));

	}

	/**
	 * #2949 등록된 결재선 리스트
	 * 
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(method = RequestMethod.GET, value = "/apprlist/{form_seq}.json")
	@ResponseBody
	public HashMap findFormApprLineJson(@PathVariable("form_seq") Long form_seq_id, HttpServletRequest req)
			throws Exception {

		String _no = req.getParameter("no");

		return builderService.getApprSavedList(form_seq_id);
	}
	
	/**
	 * #2949 등록된 Doc결재선 리스트
	 * 
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(method = RequestMethod.GET, value = "/apprDoclist/{form_seq}.json")
	@ResponseBody
	public HashMap findFormApprDocLineJson(@PathVariable("form_seq") Long form_seq_id, HttpServletRequest req)
			throws Exception {

		String _no = req.getParameter("no");

		return builderService.getApprDocSavedList(form_seq_id);
	}

	/**
	 * 본문 불러오기
	 * 
	 * @param model
	 * @param formBuilderSeq
	 * @param req
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/getformcontent/{id}")
	@ResponseBody
	public ModelAndView getformcontent(Model model, @PathVariable("id") Long formSeq, HttpServletRequest req)
			throws Exception {
		return builderService.getFormContent(formSeq);
	}

	/**
	 * 양식 미리보기(사용자)
	 * 
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/previewPage")
	public ModelAndView previewPage(Model model, @ModelAttribute("model_entity") AprDoc entity) throws Exception {

		if (entity.getAppr_doc_cont() != null) {
			// String apprDocSeqstr =
			// jceEncryptor.decrypt(URLDecoder.decode(entity.getAppr_doc_seq()+"",
			// "UTF-8"));
			// query.setApprDocSeq(Long.parseLong(apprDocSeqstr));
			entity.setAppr_doc_cont(URLDecoder.decode(entity.getAppr_doc_cont(), "UTF-8"));
		}

		return builderService.previewPage(entity);
	}

	/**
	 * 메뉴샘플페이지 이동
	 * 
	 * @param model
	 * @param mav
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/buildermain.jstl")
	public String getSampleLeftmenu(Model model, ModelAndView mav) throws Exception {
		return "/cnfg/corp/apr/formbuilder/buildermain.jstl";
	}

	@SuppressWarnings("rawtypes")
	@RequestMapping(method = RequestMethod.POST, value = "/getaprdoc")
	@ResponseBody
	public HashMap aprDocRead(Model model, @ModelAttribute("model_entity") CnfgCorpAprFormBuilder entity,
			HttpServletRequest req) throws Exception {

		return builderService.aprDocRead(entity);
	}
	


	/**
	 * 양식명 중복체크
	 * 
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(method = RequestMethod.POST, value = "/findDupFormTitle")
	@ResponseBody
	public int findDupFormTitle(Model model, @ModelAttribute("model_entity") CnfgCorpAprFormBuilderQuery query,
			HttpServletRequest req) throws Exception {

		return builderService.findDupFormTitle(query);
	}

}
