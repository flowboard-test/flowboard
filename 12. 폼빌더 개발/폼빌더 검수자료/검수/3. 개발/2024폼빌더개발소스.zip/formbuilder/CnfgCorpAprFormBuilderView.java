package com.lgu.abc.cnfg.corp.apr.formbuilder;

import lombok.Data;
import lombok.ToString;

/**
 * #2643 폼빌더 기능 개발
 */
@ToString(callSuper = true, includeFieldNames = true)
public @Data class CnfgCorpAprFormBuilderView {
	private Long viewSeq;		//뷰양식 순번
	private Long corpSeq;		//회사 순번
	private Long formSeq;		//양식 순번
	private Long apprDocSeq;	//결재문서 순번
	private String cont;		//뷰양식 내용
	private String viewHistCd;	//1:작성, 2:수정
	private String regDtime;	//등록일자
	private Long RegUsrKey;		//등록자
	private String modDtime;	//수정일자
	private Long modUsrKey;		//수정자
}
