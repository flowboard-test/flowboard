package com.lgu.abc.cnfg.corp.apr.formbuilder.service;

import java.net.URLDecoder;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.ModelAndView;

import com.google.gdata.util.common.base.StringUtil;
import com.lgu.abc.apr.doc.AprDoc;
import com.lgu.abc.apr.apprline.AprApprLine;
import com.lgu.abc.apr.apprline.AprApprLineRepository;
import com.lgu.abc.apr.formapprline.AprFormApprLine;
import com.lgu.abc.apr.formapprline.AprFormApprLineRepository;
import com.lgu.abc.cnfg.corp.apr.form.CnfgCorpAprForm;
import com.lgu.abc.cnfg.corp.apr.form.CnfgCorpAprFormRepository;
import com.lgu.abc.cnfg.corp.apr.form.CnfgCorpAprFormService;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilderList;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilderQuery;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilderView;
import com.lgu.abc.cnfg.corp.apr.formbuilder.repo.CnfgCorpAprFormBuilderRepository;
import com.lgu.abc.common.util.CommonUtil;
import com.lgu.abc.common.util.SequenceUtil;
import com.lgu.abc.common.util.SessionUtil;
import com.lgu.abc.core.prototype.org.user.User;
import com.lgu.abc.cmn.cd.CmnCd;
import com.lgu.abc.common.util.CodeUtil;

/**
 * #2643 폼빌더 기능 개발
 */
@Service("cnfgCorpAprFormBuilderService")
public class CnfgCorpAprFormBuilderServiceImpl implements CnfgCorpAprFormBuilderService {
	protected Log logger = LogFactory.getLog(this.getClass());
	
	// 정규식 패턴: SQL 인젝션에서 자주 사용되는 위험한 문자나 키워드
	private final static String SCRIPTFILTER_CHARACTER = "console|alert|onload|onclick|onchange|onmouseover|onmousedown|onmouseout|onkeyup|onkeydown";
	private final static String SQLFILTER_CHARACTER = "or|and|select|insert|delete|update|drop|union|where|like"
			+ "|\'|\"|\\|\\/|\\;|\\/\\*|\\*\\/";	
	
	@Autowired
	CnfgCorpAprFormRepository formRepo;
	
	@Autowired
	CnfgCorpAprFormBuilderRepository builderRepo;
	
	@Autowired
	private SessionUtil sessionUtil;
	
	@Autowired
	private AprFormApprLineRepository aprFormApprLineRepository;
	
	@Autowired
	private AprApprLineRepository aprApprLineRepository;
	
	@Autowired
	private CnfgCorpAprFormService cnfgCorpAprFormService; 
	
	@Autowired
	private CommonUtil commonUtil;
	
	@Autowired
	private CodeUtil codeUtil;
	
	@Autowired
	private SequenceUtil sequenceUtil;
	
	final String macroEditStr[] = {
	            "AP_APPR_COMP_DTIME" // : "완료일"
				,"AP_FORM_NM" // : "양식명"
				,"AP_DOC_NO_FORM" // : "문서번호"
				,"AP_OPEN_CD_LOCALE_NAME" // : "공개여부"
				,"AP_KEEP_YY" // : "보존연한"
				,"AP_KEEP_MM"} ; // : "보존연한월"	
	
	@Override
	public String previewFormContent(String formContent) {
		String rtnHtml = "";
		if(!StringUtils.isEmpty(formContent)) {
			Document document = Jsoup.parse(formContent);
	
			Elements toolbox = document.getElementsByClass("toolbox");
			if(toolbox != null) toolbox.remove();
			
			Elements inputs = document.select("input[name=inputConf]");
			Elements texts = document.select("input[name=textConf]");
			Elements tbls = document.getElementsByClass("mainTable");
			Elements multis = document.select("tr[id^=tr_multirow_]");
			
			if(inputs != null) makeInputTag(inputs, document);
			if(texts != null) makeText(texts, document);
			if(tbls != null) chngTableClass(tbls);
			if(multis != null) addPlusBtn(multis);
			
			removeTag(document);
			
			rtnHtml = document.toString();
			rtnHtml = rtnHtml.replaceAll("\n", "").replaceAll("\"", "'");
		} else {
			rtnHtml = "ERROR"; 
		}

		return rtnHtml;
	}
	
	private void makeInputTag(Elements inputs, Document document) {
		try {
			for(Element e : inputs) {
				String val = e.val();
				
				if(!StringUtils.isEmpty(val)) {
					JSONParser parser = new JSONParser();
					JSONObject obj = (JSONObject) parser.parse(val);
					
					String placeholder = obj.get("placeholder") == null ? "" : String.valueOf(obj.get("placeholder"));
					String sortType = obj.get("sortType") == null ? "" : String.valueOf(obj.get("sortType"));
					String tdId = obj.get("tdId") == null ? "" : String.valueOf(obj.get("tdId"));
//					String useCal = obj.get("useCal") == null ? "" : String.valueOf(obj.get("useCal"));
//					String calculation = obj.get("calculation") == null ? "" : String.valueOf(obj.get("calculation"));
					
					String input = "<input class='inputBox' type='text'";
					input += " style='width: 90%;'";
					if(!StringUtils.isEmpty(placeholder)) {
 						input += " placeholder='"+placeholder+"'";
					}
					input += " onkeyup='aprDocEdit.setInputValue(this);' />";
					
					String style = "text-align: "+sortType+";";
					
					if(!StringUtils.isEmpty(tdId)) {
						Element prntTd = document.getElementById(tdId);
						
						if(!StringUtils.isEmpty(prntTd.html())) input = "<br>"+input;
						
						prntTd.attr("style", style);
						prntTd.append(input);
					} else {
						Elements prntLi = e.parent().getElementsByClass("items");
						if(prntLi != null) {
							String div = "<div style=\""+style+"\">";
							div += input;
							div += "</div>";
							prntLi.append(div);
						}
					}
				}
			}
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
	}
	
	private void makeText(Elements texts, Document document) {
		try {
			for(Element e : texts) {
				String val = e.val();
				
				if(!StringUtils.isEmpty(val)) {
					JSONParser parser = new JSONParser();
					JSONObject obj = (JSONObject) parser.parse(val);
					
					String text = obj.get("textContent") == null ?  "" : String.valueOf(obj.get("textContent"));
					String sortType = obj.get("sortType") == null ? "" : String.valueOf(obj.get("sortType"));
					String textSize = StringUtils.isEmpty(String.valueOf(obj.get("textSize"))) || obj.get("textSize") == null ? "11" : String.valueOf(obj.get("textSize"));
					String tdId = obj.get("tdId") == null ? "" : String.valueOf(obj.get("tdId"));
					
					String style = "text-align: "+sortType+"; font-size: "+textSize+"pt;";

					if(!StringUtils.isEmpty(tdId)) {
						Element prntTd = document.getElementById(tdId);
						
						if(!StringUtils.isEmpty(prntTd.html())) text = "<br>"+text;
						
						style += "background-color: #f7f7f7;";
						prntTd.attr("style", style);
						prntTd.append(text);
					} else {
						Elements prntLi = e.parent().getElementsByClass("items");
						if(prntLi != null) {
							String div = "<div style=\""+style+"\">";
							div += text;
							div += "</div>";
							prntLi.append(div);
						}
					}
				}
			}
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
	}
	
	private void chngTableClass(Elements tbls) {
		tbls.addClass("tbl_tr_form");
		tbls.removeClass("mainTable");
		
//		for(Element e : tbls) {
//			Elements tbl = e.children();
//			for(Element c : tbl) {
//				c.getElementsByTag("tr").attr("style", "border: 1px solid rgb(215, 215, 215)");
//				c.getElementsByTag("td").attr("style", "border: 1px solid rgb(215, 215, 215)");
//			}
//		}
	}
	
	private void addPlusBtn(Elements multis) {
		for(Element e : multis) {
			String id = e.id().replace("tr_", "").trim();
//			String aTag = "<a href='#' id='a_"+id+"'class='addRow' onclick='cnfgCorpAprFormPreview.addMultiRow(\""+id+"\");'>";
//			aTag += 		  "plus";
//			aTag += 	  "</a>";
//			
//			e.after(aTag);
			e.attr("id", id);
			e.attr("name", id);
		}
	}
	
	// 불필요한 태그 제거 - unwrap
	private void removeTag(Document document) {
		if(document.getElementsByClass("aLine") != null)  document.getElementsByClass("aLine").remove();
		if(document.getElementsByClass("aInLine") != null)  document.getElementsByClass("aInLine").remove();
		if(document.getElementsByClass("removeInRow") != null)  document.getElementsByClass("removeInRow").remove();
		if(document.getElementsByClass("removeRow") != null) document.getElementsByClass("removeRow").remove();
		if(document.getElementsByClass("confTable") != null) document.getElementsByClass("confTable").remove();
		if(document.select("input[name$=Conf]") != null) document.select("input[name$=Conf]").remove();
		if(document.getElementsByClass("showIdx") != null) document.getElementsByClass("showIdx").remove();
//		if(document.select("input[name=inputConf]") != null) document.select("input[name=inputConf]").remove();
//		if(document.select("input[name=textConf]") != null) document.select("input[name=textConf]").remove();
//		if(document.select("input[name=tableConf") != null) document.select("input[name=tableConf").remove();
		
		if(document.getElementsByClass("mainTableDiv") != null) document.getElementsByClass("mainTableDiv").unwrap();
		if(document.getElementsByClass("myContainer") != null) document.getElementsByClass("myContainer").unwrap();
		if(document.getElementsByClass("items") != null) document.getElementsByClass("items").unwrap(); 
		if(document.getElementsByClass("items") != null) document.getElementsByClass("inItems").unwrap();
		if(document.getElementById("sortable") != null) document.getElementById("sortable").unwrap();
		if(document.getElementsByTag("body") != null) document.getElementsByTag("body").unwrap();
		if(document.getElementsByTag("head") != null) document.getElementsByTag("head").unwrap();
		if(document.getElementsByTag("html") != null) document.getElementsByTag("html").unwrap();
	}
	
	@Override
	@Transactional
	public CnfgCorpAprFormBuilderQuery saveFormContent(HttpServletRequest request , String formSeq) throws Exception{
		CnfgCorpAprFormBuilderQuery rtn = new CnfgCorpAprFormBuilderQuery();
		
		boolean isBuildFormExist = false;
			
		CnfgCorpAprForm form = saveAprFormContent(request, formSeq);
		String formBuilderSeq = saveCnfgFormContent(request, form.getForm_seq());
	
		rtn.setFormBuilderSeq(Long.parseLong(formBuilderSeq));
		rtn.setFormSeq(form.getForm_seq());
		return rtn;
	}
	
	private CnfgCorpAprForm saveAprFormContent(HttpServletRequest request, String formSeq)  throws Exception {
		
		User user = sessionUtil.getSession();
		Long usrKey = Long.parseLong(user.getId());
		
		CnfgCorpAprForm form = new CnfgCorpAprForm();
		
		LocalDateTime date = LocalDateTime.now();
		String parseDate = date.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
		
		String formDivCdSeq = request.getParameter("formDivCdSeq");
		String formContent = this.filterSCRIPTInjection( request.getParameter("previewCont") );
		String formTitle = request.getParameter("formTitle");
		String docNo = request.getParameter("docNo");
		String keepYy = request.getParameter("keepYy");
		String keepMm = request.getParameter("keepMm");

		form.setForm_nm(formTitle);
		form.setCont(URLDecoder.decode(formContent, "UTF-8"));
		form.setMod_dtime(parseDate);
		form.setMod_usr_key(usrKey);
		
		if(StringUtils.isEmpty(formSeq)) {
			form.setForm_seq(this.sequenceUtil.getNextSequence("apr_form", "form_seq"));
			form.setCorp_seq(Long.parseLong(user.getCompany().getId()));
			form.setForm_div_cd_seq(Long.parseLong(formDivCdSeq));
			form.setDoc_no_form(docNo);	//"제 경영 신청  -"
			form.setDoc_sn(0);
			form.setKeep_yy(keepYy);
			form.setKeep_mm(keepMm);
			form.setDscrt("");
			form.setUse_yn("T");
			form.setReg_dtime(parseDate);
			form.setReg_usr_key(usrKey);
			form.setMacro_edit_yn("N");
			form.setForm_builder_yn("Y");
			
			formRepo.create(form);
		} else {
			form.setForm_seq(Long.parseLong(formSeq));
			builderRepo.aprUpdate(form);
		}
		
		return form;
	}
	
//	private String makeSaveContent(String formContent) {
//		Document document = Jsoup.parse(formContent);
//		if(document.getElementsByTag("ul") != null) document.getElementsByTag("ul").unwrap();
//		if(document.getElementsByTag("body") != null) document.getElementsByTag("body").unwrap();
//		if(document.getElementsByTag("head") != null) document.getElementsByTag("head").unwrap();
//		if(document.getElementsByTag("html") != null) document.getElementsByTag("html").unwrap();
//		
//		String rtnHtml = document.toString();
//		rtnHtml = rtnHtml.replaceAll("\n", "").replaceAll("\"", "'");
//		
//		return rtnHtml;
//	}
	
	private String saveCnfgFormContent(HttpServletRequest request, Long formSeq) throws Exception {
		User user = sessionUtil.getSession();
		Long usrKey = Long.parseLong(user.getId());
		
		CnfgCorpAprFormBuilderQuery query = new CnfgCorpAprFormBuilderQuery();
		
		LocalDateTime date = LocalDateTime.now();
		String parseDate = date.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
		
		String formTitle = request.getParameter("formTitle");
		String formContent = this.filterSCRIPTInjection( request.getParameter("formContent") );
		
		query.setFormTitle(formTitle);
		query.setFormContent(URLDecoder.decode(formContent, "UTF-8"));
		query.setModDtime(parseDate);
		query.setModUsrKey(usrKey);
		
		CnfgCorpAprFormBuilderList existlist = null;
		
		if(!StringUtils.isEmpty(formSeq)) {
			existlist = this.getFormContentJson(formSeq);
			logger.debug(existlist + "");
		}
		
		if(StringUtils.isEmpty(formSeq)) {
			query.setFormBuilderSeq(this.sequenceUtil.getNextSequence("apr_form_builder", "form_builder_seq"));
			query.setCorpSeq(Long.parseLong(user.getCompany().getId()));
			query.setFormSeq(formSeq);
			query.setRegDtime(parseDate);
			query.setRegUsrKey(usrKey);
			
			builderRepo.create(query);
			
		} else {
			if(existlist == null) {
				
				query.setFormBuilderSeq(this.sequenceUtil.getNextSequence("apr_form_builder", "form_builder_seq"));
				query.setCorpSeq(Long.parseLong(user.getCompany().getId()));
				query.setFormSeq(formSeq);
				query.setRegDtime(parseDate);
				query.setRegUsrKey(usrKey);
				
				builderRepo.create(query);
			}
			else {
				query.setFormSeq(formSeq);
				query.setFormBuilderSeq(existlist.getFormBuilderSeq());
				builderRepo.update(query);
			}
			
		}
		
		return String.valueOf(query.getFormBuilderSeq());
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public HashMap getFormList(CnfgCorpAprFormBuilder query) {
		User user = sessionUtil.getSession();
		query.setCorpSeq(user.getCompany().getId());
		
		List<CnfgCorpAprFormBuilderList> list = builderRepo.getFormList(query);
		
		HashMap map = new HashMap();
		map.put("list", list);
		map.put("count", builderRepo.getFormCount(query));
		
		return map;
	}
	
	//#2949 등록된 결재선 리스트
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public HashMap getApprSavedList(Long apprId) {
		
		AprFormApprLine afal = new AprFormApprLine();
		afal.setForm_seq(apprId);		
		List<AprFormApprLine> apr_form_appr_line_list = this.aprFormApprLineRepository.findAll(afal);
		
		HashMap map = new HashMap();
		map.put("list", apr_form_appr_line_list);
		map.put("count", apr_form_appr_line_list.size());
		
		return map;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public HashMap getApprDocSavedList(Long apprDocId) {
		
		AprApprLine afal = new AprApprLine();
		afal.setAppr_doc_seq(apprDocId);		
		List<AprApprLine> aprApprLineList  = this.aprApprLineRepository.findAll(afal);		
		HashMap map = new HashMap();
		List<CmnCd> appr_proc_cd_List= this.codeUtil.findCmnCd("00005");	
		
		String aprApprLine = "";
		for (int i=0; i< aprApprLineList.size(); i++) {			
			afal = aprApprLineList.get(i);
			
			aprApprLine +=","+ afal.getAppr_line_order();
			
			if(afal.getAppr_proc_cd().contentEquals("01") ){                        		
        		aprApprLine +="^0";    
        	}else if(afal.getAppr_meth_cd().contentEquals("4") ){ 
        		aprApprLine +="^6";
        	}else{
        		aprApprLine +="^"+afal.getAppr_meth_cd();
        	}			
			
			aprApprLine +="^"+afal.getUsr_key()+"^"+afal.getKor_nm();  
        	aprApprLine +="^"+afal.getDept_nm();
        	aprApprLine +="^"+afal.getPos_duty_nm();
        	aprApprLine +="^"+afal.getUsr_id();                            	
        	aprApprLine +="^"+afal.getDept_seq();
        	aprApprLine +="^"+afal.getAppr_proc_cd();
        	        		
        	for(int j=0 ; j < appr_proc_cd_List.size(); j++) {	
        		if(appr_proc_cd_List.get(j).getCmn_cd().contentEquals(afal.getAppr_proc_cd())) {        			
        			aprApprLine +="^"+appr_proc_cd_List.get(j).getCmn_cd_nm();
        			break;        			
        		}
        	}   
        	
        	      	        	
        	if(!afal.getAppr_proc_cd().contentEquals("88") && !afal.getAppr_proc_cd().contentEquals("99")){
        		aprApprLine +="^"+afal.getAppr_dtime();                        		
        	}else{
        		aprApprLine +="^"; 
        	}			
			
		}
		
		map.put("count", aprApprLineList.size());		
		map.put("aprApprLine", aprApprLine);
		
		return map;
	}	
	
	@Override
	public CnfgCorpAprFormBuilderList getFormContentJson(Long formSeq) {
		return builderRepo.getFormContent(formSeq);
	}
	
	@Override
	public ModelAndView getFormContent(Long formSeq) {
		CnfgCorpAprFormBuilderList cont = builderRepo.getFormContent(formSeq);
		String ids = getTableIds(cont.getFormContent());
		
		ModelAndView modelAndView = new ModelAndView();
		
		modelAndView.addObject("cont", cont);
		modelAndView.addObject("ids", ids);
		modelAndView.setViewName("/cnfg/corp/apr/formbuilder/formedit.jstl");
		
		return modelAndView;
	}
	
	@SuppressWarnings("unchecked")
	private String getTableIds(String cont) {
		JSONObject json = new JSONObject();
		
		Document document = Jsoup.parse(cont);
		Elements tbls = document.getElementsByTag("table");

		for(Element tbl : tbls) {
			String id = tbl.attr("id");
			if(!StringUtils.isEmpty(id)) {
				json.put("id"+id, id);
			}
		} 
		
		return json.toString();
	}
	
	
	/**
	 * 기안단계의 미리보기.
	 * */
	@Override
	public ModelAndView previewPage(AprDoc entity) {
		
		
		/*
		 * 참조자 매크로 변수 변환.
		 * */
		
		
		//String cont = makePreviewPage(entity);
		CnfgCorpAprForm cnfgCorpAprForm = new CnfgCorpAprForm();
		cnfgCorpAprForm.setCont(entity.getAppr_doc_cont());
		/*
		 * 자동항목 매크로 변수 변환.
		 * */
		String cont = cnfgCorpAprFormService.previewEditMacroTagChange(cnfgCorpAprForm);
		cont = this.makeMacroToText(cont, entity);
		
		cont = this.filterSCRIPTInjection(cont);
		
		/*
		 * 첨부파일 매크로 변수 변환.
		 * 
		if(entity.getAppr_doc_seq() !=null && entity.getAppr_doc_seq() > 0 ) {
		
			AprDocAtchFileMap adafm = new AprDocAtchFileMap();
			adafm.setAppr_doc_seq(entity.getAppr_doc_seq());
			List<AprDocAtchFileMap> aprDocAtchFileMapList = aprDocAtchFileMapRepository.findAll(adafm);
			entity.setAprDocAtchFileMapList(aprDocAtchFileMapList);
			
			String filestr = "";
			if( aprDocAtchFileMapList != null ) {
				int i = 0; 
				for(AprDocAtchFileMap item: aprDocAtchFileMapList) {
					
					if(i != 0) filestr += ", ";
					filestr += item.getAtch_file_nm();
					
					i++;
				};
				
				cont.replaceAll("$AP_ADD_FILES$", filestr);
			}
	
		}*/
		
		//CnfgCorpAprForm cnfgCorpAprForm = makeCnfgCorpAprForm(entity);
		cnfgCorpAprForm.setCont(cont);
		cnfgCorpAprForm.setSelSearchType(entity.getSearchType());
		// #3155 [구현-결재상신] 폼빌더 양식 용 미리보기 / 인쇄 / 히스토리 페이지
		cnfgCorpAprForm.setForm_builder_yn(entity.getForm_builder_yn());
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("model_entity", cnfgCorpAprForm) ;
		modelAndView.setViewName("/apr/doc/formbuilderpreview.jstl");
		
		return modelAndView;
	}
	
	/**
	 * 매크로 항목 텍스트로 변환
	 * @param cont
	 * @param entity
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public String makeMacroToText(String cont, AprDoc entity) {
		//문서정보 맵
		CnfgCorpAprFormBuilder query = new CnfgCorpAprFormBuilder();
		query.setFormSeq(entity.getForm_seq());
		HashMap docInfoMap = builderRepo.aprDocRead(query);
		
		for(int i=0; i<macroEditStr.length; i++){
			String mapkey = "[$]" + macroEditStr[i]  + "[$]";
			cont = cont.replaceAll( mapkey, this.nullIf((String)docInfoMap.get(macroEditStr[i])));
		}
		
		return cont;
	}
	
	/**
	 * 결재상신/진행 미리보기 본문 세팅
	 * @param entity
	 * @return
	 */
//	private String makePreviewPage(CnfgCorpAprForm entity) {
//		String rtnHtml = "";
//		String formContent = entity.getCont();
//		
//		if(!StringUtils.isEmpty(formContent)) {
//			Document document = Jsoup.parse(formContent);
//			
//			parseInputToText(document);
//			
//			rtnHtml = document.toString();
//			rtnHtml = rtnHtml.replaceAll("\n", "").replaceAll("\"", "'");
//		} else {
//			rtnHtml = "ERROR";
//		}
//
//		return rtnHtml;
//	}
	
	/**
	 * 결재상신/진행 미리보기 본문 세팅
	 * @param entity
	 * @return
	 */
	@Override
	public String makeAprCont(String docCont) {
		String rtnHtml = "";
		
		if(!StringUtils.isEmpty(docCont)) {
			Document document = Jsoup.parse(docCont);
			
			parseInputToText(document);
			
			replaceHtmlTag(document);
			
			rtnHtml = document.toString();
			rtnHtml = rtnHtml.replaceAll("\n", "").replaceAll("\"", "'");
		}

		return rtnHtml;
	}
	
	/**
	 * 불필요한 태그 제거
	 * @param document
	 */
	private void replaceHtmlTag(Document document) {
		if(document.getElementsByTag("body") != null) document.getElementsByTag("body").unwrap();
		if(document.getElementsByTag("head") != null) document.getElementsByTag("head").unwrap();
		if(document.getElementsByTag("html") != null) document.getElementsByTag("html").unwrap();
	}
	
	/**
	 * CnfgCorpAprForm 세팅
	 * @param entity
	 * @return
	 */
//	private CnfgCorpAprForm makeCnfgCorpAprForm(CnfgCorpAprForm entity) {
//		CnfgCorpAprForm cnfgCorpAprForm = new CnfgCorpAprForm();
//		
//		return cnfgCorpAprForm;
//	}
	
	/**
	 * input 태그 텍스트 형식으로 변경
	 * @param document
	 */
	private void parseInputToText(Document document) {
		/*
		 * Elements elms = document.getElementsByTag("input");
		 * 
		 * for(Element elm : elms) { String txt = elm.val(); elm.parent().append(txt); }
		 * 
		 * document.getElementsByTag("input").remove();
		 */
	}
	
	/**
	 * 상신 후 내용 저장
	 * @param cnfgCorpAprForm
	 */
	@SuppressWarnings("deprecation")
	@Override
	public void saveFormView(AprDoc doc, String type) {
		Long corpSeq = this.sessionUtil.getSessionBean().getCorp_seq();
		Long usrKey = this.sessionUtil.getSessionBean().getUsr_key();
		
		CnfgCorpAprFormBuilderView view = new CnfgCorpAprFormBuilderView();
		
		LocalDateTime date = LocalDateTime.now();
		String parseDate = date.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
		
		String viewHistCd = "create".equals(type) ? "1" : "2";
		
		view.setViewSeq(this.sequenceUtil.getNextSequence("apr_doc_view", "view_seq"));
		view.setCorpSeq(corpSeq);
		view.setFormSeq(doc.getForm_seq());
		view.setApprDocSeq(doc.getAppr_doc_seq());
		view.setCont(doc.getAppr_doc_cont());
		view.setViewHistCd(viewHistCd);
		view.setRegDtime(parseDate);
		view.setRegUsrKey(usrKey);
		view.setModDtime(parseDate);
		view.setModUsrKey(usrKey);
			
		builderRepo.saveFormView(view);
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public HashMap aprDocRead(CnfgCorpAprFormBuilder query) {
		
		HashMap docInfoMap = builderRepo.aprDocRead(query);
		
		String AP_APPR_COMP_DTIME = (String)docInfoMap.get("AP_APPR_COMP_DTIME");
		
		if( AP_APPR_COMP_DTIME != null ) {
			
			String str = this.commonUtil.cnvDateStringTz(AP_APPR_COMP_DTIME, "yyyyMMddHHmmss", "yyyy-MM-dd HH:mm:ss" , "Asia/Seoul");
			
			docInfoMap.put( "AP_APPR_COMP_DTIME", str );
		}
		
		return docInfoMap;
	}
	
	@Override
	public int findDupFormTitle(CnfgCorpAprFormBuilderQuery query) {
		return builderRepo.findDupFormTitle(query);
	}
	
	public String nullIf(String str) {
		
		return str != null ? str: "";
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public String replaceApprDocInfo(Long apprDocSeq, String cont, String drft_dtime) {
		
		if(apprDocSeq != null && cont != null) {
			
			logger.info("======replaceApprDocInfo=====");
			
			//문서정보 맵
			CnfgCorpAprFormBuilder query = new CnfgCorpAprFormBuilder();
			query.setApprDocSeq(apprDocSeq);
			HashMap docInfoMap = builderRepo.aprDocRead(query);
			
			logger.info("docInfoMap :: " + docInfoMap);
			
			for(int i=0; i<macroEditStr.length; i++){
				
				String mapkey = "[$]" + macroEditStr[i]  + "[$]";
				String val = (String)docInfoMap.get(macroEditStr[i]);
				
				if(val != null && "AP_APPR_COMP_DTIME".equals(macroEditStr[i])) {
					
					String str = this.commonUtil.cnvDateStringTz(val, "yyyyMMddHHmmss", "yyyy-MM-dd HH:mm:ss" , "Asia/Seoul");
					
					cont = cont.replaceAll( mapkey, str );
				}
				else {
					
					cont = cont.replaceAll( mapkey, this.nullIf(val));
				}

			}
			
			cont = cont.replaceAll( "[$]CT_DRFT_DATE[$]" ,	drft_dtime );
			
			cont = this.filterSCRIPTInjection(cont);
			
		}
		
		return cont;
	}
	
	@Override
	public HashMap<String, String> removeFormContent(CnfgCorpAprFormBuilderQuery entity) throws Exception{
		HashMap<String, String> rtnHm = new HashMap<String, String>();
		int cnt = builderRepo.selectTempForm(entity);
		
		if(cnt > 0) {
			builderRepo.aprRemove(entity);
			builderRepo.remove(entity);
		}
		
		rtnHm.put("result", "SUCCESS");
		
		return rtnHm;
	}
	
	/**
	 * SQL 인젝션 공격 방지를 위한 문자열 필터링 메서드
	 *
	 * @param input 사용자 입력 문자열
	 * @return 필터링된 문자열
	 */
	public static String filterSQLInjection(String input) {
		if (input == null) {
			return null;
		}
		
		String checkpattern = "(" + SQLFILTER_CHARACTER  + ")" ;
		
		Pattern SQL_INJECTION_PATTERN = Pattern.compile(checkpattern);
		
		return SQL_INJECTION_PATTERN.matcher(input).replaceAll("");
	}
	/**
	 * script 인젝션 공격 방지를 위한 문자열 필터링 메서드
	 *
	 * @param input 사용자 입력 문자열
	 * @return 필터링된 문자열
	 */
	public static String filterSCRIPTInjection(String input) {
		if (input == null) {
			return null;
		}
		
		String checkpattern = "(" + SCRIPTFILTER_CHARACTER + ")" ;
		
		Pattern S_INJECTION_PATTERN = Pattern.compile(checkpattern);
		
		return S_INJECTION_PATTERN.matcher(input).replaceAll("");
	}
}
