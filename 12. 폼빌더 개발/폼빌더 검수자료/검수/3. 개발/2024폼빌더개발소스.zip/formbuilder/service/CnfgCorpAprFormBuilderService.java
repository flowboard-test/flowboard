package com.lgu.abc.cnfg.corp.apr.formbuilder.service;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.servlet.ModelAndView;

import com.lgu.abc.apr.doc.AprDoc;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilder;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilderList;
import com.lgu.abc.cnfg.corp.apr.formbuilder.CnfgCorpAprFormBuilderQuery;

/**
 * #2643 폼빌더 기능 개발
 */
public interface CnfgCorpAprFormBuilderService {
	public String previewFormContent(String formContent);
	public CnfgCorpAprFormBuilderQuery saveFormContent(HttpServletRequest request, String formSeq) throws Exception;
	@SuppressWarnings("rawtypes")
	public HashMap getFormList(CnfgCorpAprFormBuilder query);
	@SuppressWarnings("rawtypes")
	public HashMap getApprSavedList(Long apprId);
	@SuppressWarnings("rawtypes")
	public HashMap getApprDocSavedList(Long apprDocId);
	public CnfgCorpAprFormBuilderList getFormContentJson(Long formSeq);
	public ModelAndView getFormContent(Long formSeq);
	public ModelAndView previewPage(AprDoc entity);		
	public String makeAprCont(String docCont);
	public void saveFormView(AprDoc doc, String type);
	
	@SuppressWarnings("rawtypes")
	public HashMap aprDocRead(CnfgCorpAprFormBuilder query);
	public int findDupFormTitle(CnfgCorpAprFormBuilderQuery query);
	public String replaceApprDocInfo(Long apprDocSeq, String cont, String drft_dtime);
	public HashMap<String, String> removeFormContent(CnfgCorpAprFormBuilderQuery entity) throws Exception;
	public String makeMacroToText(String cont, AprDoc entity);
}