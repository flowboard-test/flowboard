package com.lgu.abc.cnfg.corp.apr.formbuilder;

import lombok.Data;
import lombok.ToString;

/**
 * #2643 폼빌더 기능 개발
 */
@ToString(callSuper = true, includeFieldNames = true)
public @Data class CnfgCorpAprFormBuilder {
//	private String formEditor;
//	private String attchFile;
//	private String divisionLine;
	private Long formBuilderSeq;
	private Long formSeq;
	private String confData;
	
	private String corpSeq;
	
	private String searchType;

	private Integer page;

	private Integer pageSize;

	private String rownum;

	private String sortField;

	private String sortDirection;

	private Long apprDocSeq;
}
