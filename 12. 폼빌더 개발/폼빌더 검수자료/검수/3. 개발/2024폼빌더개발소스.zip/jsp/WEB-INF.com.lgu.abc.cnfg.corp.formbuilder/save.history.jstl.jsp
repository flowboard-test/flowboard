<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ include file="/WEB-INF/tags/taglib.inc"%>
<% pageContext.setAttribute("newLineChar", "\n"); pageContext.setAttribute("spaceChar", " ");%>

<%-- #3155 [구현-결재상신] 폼빌더 양식 용 미리보기 / 인쇄 / 히스토리 페이지 --%>

<!DOCTYPE html>
<html lang="ko">
<script type="text/javascript">
$(document).ready(function() {
	var width = $(".formbuilder_editedview.vertical").css("width");
	$(".table04_box_form").css("width", width);
	$(".table05_box_form").css("width", width);
});
</script>
<body>
	<div id="middle">
		<div class="content">
			<div id="apprDocContent">
				<div id="content" style="padding:10px;">${model_entity.appr_doc_cont_view}</div>
			</div>
			<!-- 참조문서 영역 -->
			<div id="attachFileArea" class="table05_box_form" style="display:inherit;">
				<table cellspacing="0" class="table04_form" summary="문서">
					<caption>문서</caption>
					<colgroup>
						<col width="140">
						<col width="*">
					</colgroup>
					<tr>
						<th scope="row"><s:message code="PC.COM.C4_H_121"/></th> <%-- 다국어변환OTO : 참조문서 --%> 
						<td class="doc" id="referenceDocList"></td>
					</tr>
				</table>
			</div>
			<!-- 결재의견 영역 -->
			<div class="table04_box_form">
				<table cellspacing="0" class="table04_form" summary="<s:message code="PC.COM.C4_H_163"/>" style="word-break: break-all;"> <%-- 다국어변환OTO : 결재의견 --%> 
					<caption><s:message code="PC.COM.C4_H_163"/></caption> <%-- 다국어변환OTO : 결재의견 --%> 
					<colgroup>
						<col width="140">
						<col width="*">
					</colgroup>
					<tr>
						<th scope="row" style="vertical-align:middle;"><s:message code="PC.COM.C4_H_163"/></th> <%-- 다국어변환OTO : 결재의견 --%> 
						<td>
							<c:forEach items="${model_entity.opnList}" var="item" varStatus="status">
								<span class="user">
									<span class="approvalOpinionCode${item.opn_cd}"><abc:cmnCd divCd="00008" cmnCd="${item.opn_cd}"/></span>
									<span class="F_12_black_b">
										${item.kor_nm}/${item.dept_nm}/${item.pos_duty_nm}
									</span>
									<c:if test="${item.subs_appr_yn == 'Y' && (item.opn_cd == '2' || item.opn_cd == '3' || item.opn_cd == '4' || item.opn_cd == '7')}">
										<span class="F_12_black_b">
											(<s:message code="PC.COM.C2_H_146"/> : ${item.substitutionUserName}) <%-- 다국어변환OTO : 대결 --%> 
										</span>
									</c:if>
									<span class="F_11_gray" style="margin-left:10px;">
										<abc:printDtime dtimeStr="${item.reg_dtime}"/>
									</span>
								</span>
								<br/>
								<div style="padding:0px 0 0 40px;">
									${fn:replace(fn:replace(item.opn_cont, newLineChar, '<br/>'), spaceChar, '&nbsp;')}
								</div>
								<br/>
							</c:forEach>
							<c:if test="${empty model_entity.opnList}">
								<span>
									 <s:message code="PC.COM.H1_H_069"/> <%-- 다국어변환OTO : 결재의견이 없습니다 --%> 
								</span>
							</c:if>
						</td>
					</tr>
				</table>
			</div>
		</div>
		<f:form id="aprDocPreviousPrintForm" name="entity" method="POST" commandName="model_entity">
			<f:hidden path="appr_doc_seq" value="${model_entity.appr_doc_seq}"/>
			<f:hidden path="ref_doc_list" value="${model_entity.ref_doc_list}"/>
			<f:hidden path="approvalIds" value="${fn:replace(fn:replace(model_entity.approvalIds, '[', ''), ']', '')}"/>
			<f:hidden path="readLevelAuthorizer" value="${model_entity.readLevelAuthorizer}"/>
		</f:form>
		
		<input type="hidden" id="approvalLineLocationCode" value="${model_entity.aprCorpCnfg.approval_line_location.code}"/>
	</div>
</body>
</html>
