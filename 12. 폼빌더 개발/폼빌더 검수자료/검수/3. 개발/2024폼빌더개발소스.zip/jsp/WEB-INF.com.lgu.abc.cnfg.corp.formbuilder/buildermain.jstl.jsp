<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ include file="/WEB-INF/tags/taglib.inc"%>
<%
	//  #2895 폼빌더 양식편집 화면
%>
<!--  -->
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=1920, user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>LG U+ 그룹웨어</title>

<script type="text/javascript" 
	src="<s:url value="/resources/jquery-1.8.3/jquery-1.8.3.min.js"/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>

<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/abc-theme-default.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>" />
<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/abc-common/abc-theme-01.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>" />
<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/abc-common/abc-widget.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>" />
<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/abc-common/default-class.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>" />
<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/abc-common/lay_profile.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>" />

<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/abc-common/win_cmn_adrBook.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>" />

<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/abc-layout-print.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>">
<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/abc-icon.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>">
<!-- <link rel="stylesheet" type="text/css" href="<s:url value='/resources/abc/css/abc-main.css'/>"> -->

<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/abc-table.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>">
<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/abc-layout.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>">

<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/asis_css/common.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>">
<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/cropper.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>">
<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/cropper-common.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>">
<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/font-load.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>">

<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/kendo.orgos.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>" />
<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/kendo_table.orgos.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>" />
<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/kendoui/styles/kendo.common.min.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>" />
<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/kendoui/styles/kendo.uniform.min.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>" />
<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/jquery-1.8.3/jquery-ui-1.10.2.custom.min.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>" />
	
<script type="text/javascript"
	src="<s:url value='/resources/jquery-1.8.3/jquery-ui-1.10.2.custom.min.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>

<script type="text/javascript"
	src="<s:url value='/resources/kendoui/js/kendo.all.min.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript"
	src="<s:url value='/resources/kendoui/js/kendo.web.min.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript"
	src="<s:url value='/resources/kendoui/js/kendo.fx.min.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>

<% //공통 set %>
<!-- : Multi Language Script Message - 20201118 문석진 -->
<script type="text/javascript" src="<s:url value='/resources/abc/js/i18n/jquery.i18n.properties.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript" src="<s:url value='/resources/abc/js/i18n/common_i18n.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript" src="<s:url value='/resources/abc/js/i18n/jquery.i18n.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript" src="<s:url value='/resources/abc/js/i18n/jquery.i18n.messagestore.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
	

<%@ include file="/resources/abc/js/abc-common.jsp"%>

<script type="text/javascript">
	<!-- 다국어 파일 로드 2021/06/08-->
	<jsp:include  page="/WEB-INF/i18n/i18n_script_${sessionScope.session.locale_tag}.jsp"/>
	<!-- 다국어 파일 로드 2021/06/08-->
</script>
<% //공통end %>

<script type="text/javascript" src="<s:url value="/resources/abc/js/abc-common/validation-utils.js"/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript" src="<s:url value="/resources/abc/jsUtils/_abc.js"/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript" src="<s:url value="/resources/abc/js/abc-layout-admin.js"/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>

<script type="text/javascript"
	src="<s:url value='/resources/abc/js/apr/apr.doc.edit.window_apprLine.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>


<link rel="stylesheet" type="text/css" 
	href="<s:url value='/resources/abc/css/new_css/admin_style.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>" />
	
<% //45gram 해당css 가 없어서 임시 추가 %>	
<link rel="stylesheet" type="text/css" 
	href="<s:url value='/resources/abc/css/new_css/admin_style02.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>" />
	

<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/apr/apr.doc.edit.window_apprLine.jstl.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>" />
<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/cnfg/corp/cnfg.corp.apr.formbuilder.jstl.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>" />
<link rel="stylesheet" type="text/css"
	href="<s:url value='/resources/abc/css/cnfg/corp/cnfg.corp.apr.formbuilder.editedview.jstl.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>" />

</head>



<body>
	<div id="wrap" class="new_wrap_admin formbuilder_wrap" data-global="<%=request.getContextPath()%>">
		<div class="layMain">
			<div class="topSide">
				<h2>양식편집기</h2>
				<div class="topSearchArea">
					<span class="topSearch vM"><input id="doc_title_input" name="doc_title_input"
						style="width: 100%;" class="k-textbox" 
						type="text" placeholder="양식명을 입력해 주세요."></span> <span
						class="topBtnArea">
						<button type="button" class="k-button" title="불러오기" id="clickFetchBtn">불러오기</button>
						<button type="button" class="k-button mL5" title="미리보기" id="clickPreviewBtn">양식보기</button>
						<button type="button" class="mailsendBtn mL5" title="저장" id="clickSaveBtn">편집완료</button>
						<button type="button" class="k-button mL5" title="닫기" id="clickCancelBtn">닫기</button>
					</span>
				</div>
			</div>
			<!-- //topSide -->

			<div class="middleSide">
			
			<aside id="laySide" class="laySide">
				<div id="laySide_outBdr">
					<div id="laySubMenuBx" cw_menuid="">
						<nav id="laySubMenu" class="laySubMenu laySubMenu_cnfgCorp">
							<!-- <ul class="subMenuSet">
                                <li class="subMenuTitle"></li>
                                <li class="F_SubMenu_title"><a href="#none">양식편집기 페이지</a></li>
                                //
                                [1/1/ibx_type : CORP/ibx_dept_info: ]
                                //
                            </ul> -->
							<ul class="subMenuPanelArea">
								<li>
									<!-- 표 컴포넌트 - 표 컴포넌트 -->
									<ul id="subMenuPanelBar"
										class="panelBar k-widget k-reset k-header k-panelbar"
										data-role="panelbar" tabindex="0" role="menu">
										<li aria-expanded="true" id="menu100"
											class="menu000 k-item k-state-default k-first k-state-highlight k-state-active"
											role="menuitem" aria-hidden="false"><span
											class="k-link k-header"> 표 컴포넌트<span
												class="k-icon k-i-arrow-n k-panelbar-collapse"></span>
										</span>
											<ul class="k-group k-panel" role="group" aria-hidden="true"
												style="display: block;">
												
												<li class="k-item k-state-default k-first" role="menuitem"><a
													id="menu_cptable" 
													class="k-link k-state-selected k-state-focused">표 컴포넌트</a></li>
											</ul></li>
										<li aria-expanded="true" id="menu200"
											class="menu000 k-item k-state-default k-state-active" role="menuitem"
											aria-hidden="false"><span class="k-link k-header">
												기본 항목<span class="k-icon k-i-arrow-s k-panelbar-expand"></span>
										</span>
											<ul class="k-group k-panel" role="group" aria-hidden="true"
												style="display: none;">
											    <li class="k-item k-state-default k-last" role="menuitem"><a 
                                                	id="menu_cpformtitle" class="k-link k-state-selected k-state-focused">양식명</a></li>
                                                <li class="k-item k-state-default k-last" role="menuitem"><a 
                                                	id="menu_cplogo" class="k-link k-state-selected k-state-focused">회사로고</a></li>	
											    <li class="k-item k-state-default k-first" role="menuitem"><a id="menu_cptitle" class="k-link k-state-selected k-state-focused">제목</a></li>
                                                <li class="k-item k-state-default k-last" role="menuitem"><a 
                                                	id="menu_cplabel" class="k-link k-state-selected k-state-focused">레이블</a></li>
                                                <li class="k-item k-state-default k-last" role="menuitem"><a 
                                                	id="menu_cpdivdline" class="k-link k-state-selected k-state-focused">구분선</a></li>
                                                <li class="k-item k-state-default" role="menuitem"><a 
                                                	id="menu_cpwebeditor" class="k-link k-state-selected k-state-focused">본문내용</a></li>
                                                <li class="k-item k-state-default" role="menuitem"><a id="menu_cpinput" class="k-link k-state-selected k-state-focused">텍스트</a></li>
                                                <li class="k-item k-state-default" role="menuitem"><a id="menu_cptextarea" class="k-link k-state-selected k-state-focused">멀티텍스트</a></li>
                                                <!-- <li class="k-item k-state-default" role="menuitem"><a id="menu_cpmultiwebeditor" class="k-link k-state-selected k-state-focused">편집기</a></li> -->
                                                <li class="k-item k-state-default" role="menuitem"><a id="menu_cpnumber" class="k-link k-state-selected k-state-focused">숫자</a></li>
                                                
                                                <li class="k-item k-state-default k-first" role="menuitem"><a
													id="menu_cpcalculator" 
													class="k-link k-state-selected k-state-focused">가로연산</a></li>
												<li class="k-item k-state-default k-first" role="menuitem"><a
													id="menu_cpcalculatorcol" 
													class="k-link k-state-selected k-state-focused">세로연산</a></li>

												<li class="k-item k-state-default k-first" role="menuitem"><a
													id="menu_cpcalculatortotal" 
													class="k-link k-state-selected k-state-focused">합계</a></li>

												<li class="k-item k-state-default k-first" role="menuitem"><a
													id="menu_cpcalculatorglobaltotal" 
													class="k-link k-state-selected k-state-focused">총계</a></li>
													
                                                <li class="k-item k-state-default" role="menuitem"><a id="menu_cpcurrency" class="k-link k-state-selected k-state-focused">통화</a></li>
                                                <li class="k-item k-state-default" role="menuitem"><a
													 id="menu_cpradio" class="k-link k-state-selected k-state-focused">라디오</a></li>
												<li class="k-item k-state-default" role="menuitem"><a
													id="menu_cpselectbox" class="k-link k-state-selected k-state-focused">드롭박스</a></li>
												<li class="k-item k-state-default" role="menuitem"><a
													id="menu_cpcheckbox" class="k-link k-state-selected k-state-focused">체크박스</a></li>
												<li class="k-item k-state-default" role="menuitem"><a
													id="menu_cpdatebox" class="k-link k-state-selected k-state-focused">날짜</a></li>
                                                <li class="k-item k-state-default" role="menuitem"><a 
                                                	id="menu_cpdatetime" class="k-link k-state-selected k-state-focused">시간</a></li>
                                                <li class="k-item k-state-default" role="menuitem"><a 
                                                	id="menu_cpdatebetween" class="k-link k-state-selected k-state-focused">기간</a></li>
                                                <li class="k-item k-state-default" role="menuitem"><a 
                                                	id="menu_cpuser" class="k-link k-state-selected k-state-focused">사용자</a></li>
                                                <li class="k-item k-state-default" role="menuitem"><a 
                                                	id="menu_cpdept" class="k-link k-state-selected k-state-focused">부서</a></li>
                                                <li class="k-item k-state-default k-last" role="menuitem"><a
													id="menu_cpreciptient" class="k-link k-state-selected k-state-focused">수신자</a></li>	
                                                <li class="k-item k-state-default" role="menuitem"><a 
                                                    id="menu_cpgap" class="k-link k-state-selected k-state-focused">여백</a></li>
                                                
                                              	
											</ul></li>
											
										<li aria-expanded="true" id="menu300"
											class="menu000 k-item k-state-default k-last k-state-active"
											role="menuitem" aria-hidden="false"><span
											class="k-link k-header"> 결재선항목<span
												class="k-icon k-i-arrow-s k-panelbar-expand"></span>
										</span>
											<ul class="k-group k-panel" role="group" aria-hidden="true"
												style="display: none;">

												<li class="k-item k-state-default" role="menuitem"><a id="menu_cpapprovalline" class="k-link k-state-selected k-state-focused">결재선</a></li>

												<li class="k-item k-state-default k-last" role="menuitem"><a id="menu_cpapprovalline_multi"class="k-link k-state-selected">결재정보+결재선</a></li>

												<li class="k-item k-state-default k-last" role="menuitem"><a id="menu_cpapprovalline_single_type_b"class="k-link k-state-selected">대외공문 결재선</a></li>

												<li class="k-item k-state-default k-first" role="menuitem"><a
                                                id="menu_cpapprovalline_singleAdd" class="k-link k-state-selected">합의 결재선</a></li>                                                    
												<li class="k-item k-state-default k-last" role="menuitem"><a
                                                id="menu_cpapprovalline_final" class="k-link k-state-selected">수신 결재선</a></li>
											</ul></li>
											
										<li aria-expanded="true" id="menu400"
											class="menu000 k-item k-state-default k-state-active" role="menuitem"
											aria-hidden="false"><span class="k-link k-header">
												연동항목<span class="k-icon k-i-arrow-s k-panelbar-expand"></span>
										</span>
											<ul class="k-group k-panel" role="group" aria-hidden="true"
												style="display: none;">
												<li class="k-item k-state-default k-first" role="menuitem"><a
													id="menu_cpmacro_usrnm" class="k-link k-state-selected k-state-focused">기안자</a></li>
												<li class="k-item k-state-default" role="menuitem"><a
													id="menu_cpmacro_usrdept" class="k-link k-state-selected k-state-focused">기안부서</a></li>
												<li class="k-item k-state-default" role="menuitem"><a
													id="menu_cpmacro_email" class="k-link k-state-selected k-state-focused">기안자이메일</a></li>
												<li class="k-item k-state-default" role="menuitem"><a
													id="menu_cpmacro_pos" class="k-link k-state-selected k-state-focused">직위</a></li>
												<li class="k-item k-state-default" role="menuitem"><a
													id="menu_cpmacro_empno" class="k-link k-state-selected k-state-focused">사번</a></li>
												<li class="k-item k-state-default" role="menuitem"><a
													id="menu_cpmacro_hp" class="k-link k-state-selected k-state-focused">휴대폰번호</a></li>
												<li class="k-item k-state-default" role="menuitem"><a
													id="menu_cpmacro_codrfttel" class="k-link k-state-selected k-state-focused">직통전화</a></li>
												<li class="k-item k-state-default" role="menuitem"><a
													id="menu_cpmacro_cotel" class="k-link k-state-selected k-state-focused">대표번호</a></li>
												<li class="k-item k-state-default" role="menuitem"><a
													id="menu_cpmacro_cofax" class="k-link k-state-selected k-state-focused">팩스</a></li>
												<li class="k-item k-state-default" role="menuitem"><a
													id="menu_cpmacro_drftday" class="k-link k-state-selected k-state-focused">기안일</a></li>
												<li class="k-item k-state-default" role="menuitem"><a
													id="menu_cpdocinfo_cpdtime" class="k-link k-state-selected k-state-focused">완료일</a></li>
												<li class="k-item k-state-default" role="menuitem"><a
													id="menu_cpdocinfo_docno" class="k-link k-state-selected k-state-focused">문서번호</a></li>
												<li class="k-item k-state-default" role="menuitem"><a
													id="menu_cpdocinfo_opennm" class="k-link k-state-selected k-state-focused">공개여부</a></li>
												<li class="k-item k-state-default" role="menuitem"><a
													id="menu_cpdocinfo_keepy" class="k-link k-state-selected k-state-focused">보존연한</a></li>
												<!-- li class="k-item k-state-default" role="menuitem"><a
													href="formbuilder_3_15.html" class="k-link">전사문서함</a></li -->
												<li class="k-item k-state-default" role="menuitem"><a
													id="menu_cpinputfile" class="k-link k-state-selected k-state-focused">첨부파일명</a></li>
												<li class="k-item k-state-default k-last" role="menuitem"><a
													id="menu_cprefperson" class="k-link k-state-selected k-state-focused">참조자</a></li>
												<li class="k-item k-state-default k-last" role="menuitem"><a
													id="menu_cpreviewer" class="k-link k-state-selected k-state-focused">조회자</a></li>
											</ul></li>
										
									</ul>
								</li>
							</ul>
							<!-- //subMenuPanelArea -->
						</nav>
					</div>
				</div>
			</aside>

			<div id="layContent" class="layContent formbdContent">
				<!-- <div id="layContainer" class="layContainer"></div> -->
				<div class="formbdContainer">

					<!-- 폼보드 Edit 영역 -->
					<div class="formbdEditView">
						<div id="editorDataArea" class="formbdEditArea componentsEditArea sortAble">
							
						</div>
						<!-- //formbdEditArea -->
					</div>
					<!-- //폼보드 Edit 영역 -->

					<!-- 폼보드 속성 영역 -->
					<div class="formbd_outBdr">
						
						<!-- 
						<div class="formbdTitle">
							<span>표컴포넌트 속성</span>
						</div>
						<ul class="formbdMenu">
							<li>
								<p class="formbdMenuTit">표컴포넌트 만들기</p>
								<div class="formBtnBox btngrid">
									<button type="button" class="k-button formBtn">행추가</button>
									<button type="button" class="k-button formBtn">행삭제</button>
									<button type="button" class="k-button formBtn">열추가</button>
									<button type="button" class="k-button formBtn">열삭제</button>
									<button type="button" class="k-button formBtn">표합치기</button>
									<button type="button" class="k-button formBtn">표나누기</button>
								</div>
							</li>
							<li>
								<p class="formbdMenuTit">입력 너비</p>
								<div class="formbdMenuCon">
									<input id="" name="" style="width: 100%;" class="k-textbox"
										readonly="readonly" type="text">
								</div>
							</li>
							<li>
								<p class="formbdMenuTit">기본값 (필수 입력 시 노출되는 문장)</p>
								<div class="formbdMenuCon">
									<input id="" name="" style="width: 100%;" class="k-textbox"
										readonly="readonly" type="text">
								</div>
							</li>
						</ul>
						 -->
					</div>
					<!-- //formbd_outBdr -->
					<!-- //폼보드 속성 영역 -->

				</div>
				<!-- //formbdContainer -->
			</div>
			<!-- //formbdContent -->
			
			</div>

		</div>
		<!-- //layMain -->
	</div>
	<!-- //formbuilder_wrap -->
	
	<!-- //aprDocEdit_window_line  -->
	<div id="aprDocEdit_window_line" style="display:none">
    		<form id="aprDocEdit_windowForm" name="aprDocEdit_windowForm" class="fmConts" action="/cnfg/corp/apr/.jstl?_=1727413701763" method="post" onsubmit="return false">
    			<input type="hidden" name="appr_line_cnfg_seq" value="">
    			<input type="hidden" name="apprLineHiddenStr" value="">
    			<!-- 왼쪽 박스 -->
    			<div class="apprLine_leftBx">
    				<!-- 탭스트립 박스 -->	
    				<div id="tabStrip_apprLine">
    					<ul>
    						<li class="k-state-active">조직도</li>  
    						<!-- <li>결재선</li>  -->
    						<li>검색</li>  
    					</ul>
    					<!-- 조직도 treeView -->
    					<div><div id="tabConts_organTree"></div></div>
    					<!-- 결재선 검색 -->
    					<div><div id="tabConts_apprline_search"></div></div>
    				</div>
    			</div>
    			<div class="textbullet win_bottomBx" style="top:385px;">
    				<span style="font-size:10.5px;"><img class="k-image" src="/resources/abc/images/new_images/org/ico_user1.png"> 부서장</span>  
    				<span style="font-size:10.5px;"><img class="k-image" src="/resources/abc/images/new_images/org/ico_user2.png"> 접수담당자</span>  
    				<span style="font-size:10.5px;"><img class="k-image" src="/resources/abc/images/new_images/org/ico_user3.png"> 근태관리자</span>  
    				<span style="font-size:10.5px;"><img class="k-image" src="/resources/abc/images/new_images/org/ico_user4.png"> 결재문서함관리자</span>  
    			</div>
    			<div class="win_bottomBx" style="top:410px;">
    				<span class="ftStrong">* * 부서/사용자 클릭시 결재선에 추가 됩니다.<!-- 부서/사용자 클릭시 결재선에 추가 됩니다. --></span>
    			</div>
    			<div class="apprLine_rightTopBx">
    				<span class="floatL mailsendBtn-margin">
    					<button class="k-button" onclick="aprDocEditWin_line.clickDeleteAll()">모두 삭제<!-- 모두 삭제 --></button>
    					<button class="k-button" onclick="aprDocEditWin_line.clickDelete()">삭제</button>  
    				</span>
    				<span class="floatR mailsendBtn-margin">
    					<button class="multiBtn_left" title="" onclick="aprDocEditWin_line.clickUp()">위로</button>  
    					<button class="multiBtn_right" title="" onclick="aprDocEditWin_line.clickDown()">아래로</button>  
    				</span>
    			</div>
    			<!-- 오른쪽 박스 -->
    			<div class="apprLine_rightBx">
    				<div id="apprLineWindowGrid" style="overflow:auto;"></div>
    			</div>
    			<!-- 하단 버튼박스  -->
    			<div class="apprLine_btnBx" style="top:410px;">
    				<div class="floatL">
    					<input type="text" name="appr_line_tit" id="appr_line_tit" class="k-textbox" style="width:300px;">
    					<button id="apprLineSaveBtn" class="k-button" onclick="aprDocEditWin_line.onSave()">결재선 저장</button>
    				</div>
    				<div class="floatR">
    					<button class="mailsendBtn" onclick="aprDocEditWin_line.onApply()">확 인</button>&nbsp;&nbsp;
    					<button class="k-button" onclick="aprDocEditWin_line.onClose()">취 소</button>
    				</div>
    			</div>
    		</form>
    		<div id="kendoWindow"></div>
    		<div id="form_appr_line"></div>
    	</div>
    	<!-- // aprDocEdit_window_line -->
    	
    	<!-- // -->
    	<!-- 기본양식 불러오기-->
    	 
    	<div id="openDocPopup" class="k-widget k-window" data-role="draggable" 
    		style=" display:none;padding-top: 44px; min-width: 90px; min-height: 50px; width: 550px; top: 84.5px; left: 134.5px; touch-action: none; z-index: 50000; opacity: 1; transform: scale(1);">
        <div class="k-window-titlebar k-header" style="margin-top: -44px;">
            &nbsp;<span class="k-window-title" id="">기존양식 불러오기</span>
            <div class="k-window-actions">
                <a role="button" id="openDocPopClose" ><span class="k-icon k-i-close"></span></a>
            </div>
        </div>
		
        <div id="openDocGridOutter" data-role="window" class="layerpopup k-window-content k-content" tabindex="0" role="dialog" aria-labelledby="" >

            
            <div class="k-grid k-widget formbuilderlayer">
                <div class="formbuildertbl" style="max-height: 420px; overflow-y: auto;">                    
                    <table class="tbl_noneC scroll_y" style="width:100%;">
                        <colgroup>
                            <col width="*;">
                            <col width="160px;">
                        </colgroup>
                        <thead>
                            <tr>
                                <th>양식명</th>
                                <th>선택</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            
                        </tbody>
                    </table>
                </div>

                <div class="k-pager-wrap k-grid-pager k-widget k-floatwrap" data-role="pager" style="border-top: 0px;">
                    <a href="#" aria-label="Go to the first page" class="k-link k-pager-nav k-pager-first k-state-disabled" data-page="1" tabindex="-1"><span class="k-icon k-i-seek-w"></span></a>
                    <a href="#" aria-label="Go to the previous page" class="k-link k-pager-nav  k-state-disabled" data-page="1" tabindex="-1"><span class="k-icon k-i-arrow-w"></span></a>
                    <ul class="k-pager-numbers k-reset">
                        <li class="k-current-page"><span class="k-link k-pager-nav">1</span></li>
                        <li><span class="k-state-selected">1</span></li>
                        <li><a tabindex="-1" href="#" class="k-link" data-page="2">2</a></li>
                        <li><a tabindex="-1" href="#" class="k-link" data-page="3">3</a></li>
                    </ul>
                    <a href="#" aria-label="Go to the next page" class="k-link k-pager-nav" data-page="2" tabindex="-1"><span class="k-icon k-i-arrow-e"></span></a>
                    <a href="#" aria-label="Go to the last page" class="k-link k-pager-nav k-pager-last" data-page="3" tabindex="-1"><span class="k-icon k-i-seek-e"></span></a>                    
                    <span class="k-pager-sizes k-label">
                        <span title="" class="k-widget k-dropdown k-header">
                            <span unselectable="on" class="k-dropdown-wrap k-state-default">
                                <span unselectable="on" class="k-input">10</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span>
                            </span>
                            <select data-role="dropdownlist" style="display: none;">
                                <option value="10" selected="selected">10</option>
                                <option value="20">20</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                            </select>
                        </span>
                    </span>

                    <a href="#" class="k-pager-refresh k-link" title="새로고침"><span class="k-icon k-i-refresh">새로고침</span></a><span class="k-pager-info k-label"> 1/19</span>
                </div>
            </div>
            

        </div>
    </div>
     
     <!-- --><!-- //기본양식 불러오기 -->
    	
    	<div id="bodyblockDiv" class="k-overlay" style="z-index: 20000; opacity: 0.35;"></div>
    	<div style="z-index: 30000; position: fixed; left: 709.5px; top: 300px;" id="loadingView"><img src="/resources/abc/images/mai/loading.gif"></div>
    		
<%@include file="/INC-JSP/layer/layCmn_profile.jspf" %>
<%@include file="/INC-JSP/layer/layCmn_blind.jspf" %>
<%@include file="/INC-JSP/layer/layCmn_alert.jspf" %>
<%@include file="/INC-JSP/layer/layCmn_confirm.jspf" %>
<%@include file="/INC-JSP/layer/layCmn_myRightPopup.jspf" %>
	
</body>

<script type="text/javascript" src="<s:url value='/resources/abc/js/apr/approval.common.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>

<script type="text/javascript"
	src="<s:url value='/resources/abc/js/cnfg/corp/comp/cnfg.corp.apr.formbuilder.comp.cpcommon.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript"
	src="<s:url value='/resources/abc/js/cnfg/corp/comp/cnfg.corp.apr.formbuilder.comp.cpelemparent.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript"
	src="<s:url value='/resources/abc/js/cnfg/corp/comp/cnfg.corp.apr.formbuilder.comp.cpview.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript"
	src="<s:url value='/resources/abc/js/cnfg/corp/comp/cnfg.corp.apr.formbuilder.comp.builderdoclist.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>


<!-- 
<script type="text/javascript"
	src="<s:url value='/resources/abc/js/cnfg/corp/comp/cnfg.corp.apr.formbuilder.comp.cptitle.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript"
	src="<s:url value='/resources/abc/js/cnfg/corp/comp/cnfg.corp.apr.formbuilder.comp.cptable.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript"
	src="<s:url value='/resources/abc/js/cnfg/corp/comp/cnfg.corp.apr.formbuilder.comp.cpwebeditor.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript"
	src="<s:url value='/resources/abc/js/cnfg/corp/comp/cnfg.corp.apr.formbuilder.comp.cpradio.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
 
  --> 
 
<script type="text/javascript"
	src="<s:url value='/resources/abc/js/cnfg/corp/cnfg.corp.apr.formbuilder.main.jstl.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>



</html>
