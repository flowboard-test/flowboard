<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ include file="/WEB-INF/tags/taglib.inc"%>
<% pageContext.setAttribute("newLineChar", "\n"); pageContext.setAttribute("spaceChar", " ");%>

<% //#3155 [구현-결재상신] 폼빌더 양식 용 미리보기 / 인쇄 / 히스토리 페이지 %>

<!DOCTYPE html>
<html lang="<c:out value="${sessionScope.session.locale_tag}" default="ko"></c:out>">
<head>
<c:set var="browserTitle">Biz <s:message code="PC.COM.C4_H_016"/></c:set> <%-- 다국어변환OTO : 그룹웨어 --%> 
<%@ include file="/WEB-INF/com/lgu/abc/jspf/htmlHead.jspf"%>
<link rel="stylesheet" type="text/css" href="<s:url value='/resources/abc/css/apr/apr.doc.print.jstl.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"/>
<link rel="stylesheet" type="text/css" href="<s:url value='/resources/abc/css/font-load.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"/>
<link rel="stylesheet" type="text/css" href="<s:url value='/resources/jquery.qtip/jquery.qtip.min.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"/>
<!-- 문석진 추가 다국어용 css 파일 -->
<link rel="stylesheet" type="text/css" href="<s:url value='/resources/abc/css/lang/abc-lang.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"/>
<script type="text/javascript" src="<s:url value='/resources/jquery-1.8.3/jquery-1.8.3.min.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript" src="<s:url value='/resources/jquery.qtip/jquery.qtip.min.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript" src="<s:url value='/resources/kendoui/js/kendo.web.min.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript" src="<s:url value='/resources/abc/jsUtils/_abc.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>

<script type="text/javascript" src="<s:url value='/resources/abc/js/cnfg/corp/comp/cnfg.corp.apr.formbuilder.comp.cpview.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<link rel="stylesheet" type="text/css" href="<s:url value='/resources/abc/css/cnfg/corp/cnfg.corp.apr.formbuilder.editedview.jstl.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"/>

<c:choose>
	<c:when test="${sessionScope.user.lang_cd eq 'ko'}">
		<script type="text/javascript" src="<s:url value='/resources/kendoui/js/cultures/kendo.culture.ko.min.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
	</c:when>
	<c:when test="${sessionScope.user.lang_cd eq 'zh'}">
		<script type="text/javascript" src="<s:url value='/resources/kendoui/js/cultures/kendo.culture.zh.min.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
	</c:when>
	<c:when test="${sessionScope.user.lang_cd eq 'ja'}">
		<script type="text/javascript" src="<s:url value='/resources/kendoui/js/cultures/kendo.culture.ja.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
	</c:when>
</c:choose>

<%@ include file="/resources/abc/js/abc-common.jsp"%>
<script type="text/javascript" src="<s:url value='/resources/abc/js/apr/apr.doc.previous.print.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<!-- 전자결재 공통 -->
<script type="text/javascript" src="<s:url value='/resources/abc/js/apr/approval.common.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>

<!-- Daum Editor 기본 style 값(인쇄 화면에서는 Editor 를 사용하지 않기 때문에 기본 style 을 지정) -->
<c:if test="${sessionScope.uiManager.editor.code == '2'}">
	<style type="text/css">
		body {font-size:12px;}
		p {font-size:inherit; font-family:inherit;}
	</style>
</c:if>

<script type="text/javascript">
$(document).ready(function() {
	var width = $(".formbuilder_editedview.vertical").css("width");
	$(".table04_box_form").css("width", width);
	$(".table05_box_form").css("width", width);
	
	aprDocPreviousPrint.setReady();
	if($("#ksys_yn").val() == 'Y'){
		$(".ylwWrap").css("width", "100%");
		$(".ylwWrap > div > table tr th, .ylwWrap > div > table tr td ").css("fontSize", "0.83rem");
	}
});
</script>
</head>

<body>
	<input type="hidden" id="bfrAprPrint" style="display:none" value="${bfrAprPrint}"/>
	<f:form id="printOptionForm" commandName="print_opt">
		<c:if test="${print_opt.use_yn == 'Y'}">
			<c:forEach var="i" begin="1" end="13">
			<fmt:formatNumber var="no" minIntegerDigits="2" value="${i}" type="number"/>
			<c:set var="property" value="op_${no}"/>
			<f:hidden path="${property}"  />
			</c:forEach>
		</c:if>
	</f:form>
	<c:if test="${model_entity.ksys_yn == 'Y'}">
		<input type="hidden" id="ksys_yn" value="${model_entity.ksys_yn}"/>
	</c:if>
	<div id="p_wrapper">
		<!-- 상단 Top 영역 -->
		<div id="header">
			<h1><img src="/resources/abc/images/apr/title_${sessionScope.user.lang_cd}.gif" alt="<s:message code="PC.COM.C2_H_094"/>"/></h1> <%-- 다국어변환OTO : 인쇄 --%> 
			<ul class="menu">
				<li style="width:70px;">
					<input type="checkbox" id="printMemo" <c:if test="${print_opt.op_04 == 'Y'}"> checked="checked"</c:if>>
					<label for="printMemo"><s:message code="PC.COM.C4_H_168"/></label> <%-- 다국어변환OTO : 의견포함 --%> 
				</li>
				<li style="width:95px;">
					<input type="checkbox" id="printAttach" <c:if test="${print_opt.op_05 == 'Y'}"> checked="checked"</c:if>>
					<label for="printAttach">참조문서 포함</label>
				</li>
				<li style="width:70px;">
					<input type="checkbox" id="printCmt" <c:if test="${print_opt.op_11 == 'Y'}"> checked="checked"</c:if>>
					<label for="printCmt"><s:message code="PC.COM.C4_H_203"/></label> <%-- 다국어변환OTO : 댓글포함 --%> 
				</li>	
			</ul>
			<div class="btn">
				<a href="javascript:void(0);" class="print" onclick="aprDocPreviousPrint.movePage('prev', '1');"><s:message code="PC.COM.C2_H_055"/></a> <%-- 다국어변환OTO : 이전 --%> 
				<span id="currentPage">${model_entity.page}</span> / <span id="lastPage">${fn:length(model_entity.approvalIds)}</span>
				<a href="javascript:void(0);" class="print" onclick="aprDocPreviousPrint.movePage('next', '${fn:length(model_entity.approvalIds)}');"><s:message code="PC.COM.C2_H_054"/></a> <%-- 다국어변환OTO : 다음 --%> 
				<a href="javascript:void(0);" class="print" onclick="aprDocPreviousPrint.callPrint(); return false;"><s:message code="PC.COM.C2_H_094"/></a> <%-- 다국어변환OTO : 인쇄 --%> 
				<a href="javascript:void(0);" class="close" onclick="aprDocPreviousPrint.windowClose(); return false;"><s:message code="PC.COM.C2_H_027"/></a> <%-- 다국어변환OTO : 닫기 --%> 
			</div>
			<div class="clear"></div>
		</div>
		<div id="noprint" style="padding-bottom:15px;"></div>
		<!-- 인쇄 영역 -->
		<div id="middle" style="margin-top:45px;">
		<c:choose>
			<c:when test="${bfrAprPrint == 'true'}">
				${previewHtml}
			</c:when>
			<c:otherwise>
				<div class="content">
					<div id="apprDocContent">
						<div id="content" style="padding:10px;">${model_entity.appr_doc_cont}</div>
					</div>
					<!-- 첨부파일/참조문서 영역 -->
					<div id="attachFileArea" class="table05_box_form">
						<table cellspacing="0" class="table04_form" summary="문서">
							<caption>문서</caption>
							<colgroup>
								<col width="140">
								<col width="*">
							</colgroup>
							<tr>
								<th scope="row"><s:message code="PC.COM.C4_H_121"/></th> <%-- 다국어변환OTO : 참조문서 --%> 
								<td class="doc" id="referenceDocList"></td>
							</tr>
						</table>
					</div>
	
					<!-- 결재의견 영역 -->
					<div class="table04_box_form">
						<table cellspacing="0" class="table04_form" summary="<s:message code="PC.COM.C4_H_163"/>" style="word-break: break-all;"> <%-- 다국어변환OTO : 결재의견 --%> 
							<caption><s:message code="PC.COM.C4_H_163"/></caption> <%-- 다국어변환OTO : 결재의견 --%> 
							<colgroup>
								<col width="140">
								<col width="*">
							</colgroup>
							<tr>
								<th scope="row" style="vertical-align:middle;"><s:message code="PC.COM.C4_H_163"/></th> <%-- 다국어변환OTO : 결재의견 --%> 
								<td>
									<c:forEach items="${model_entity.opnList}" var="item" varStatus="status">
										<span class="user">
											<span class="approvalOpinionCode${item.opn_cd}"><abc:cmnCd divCd="00008" cmnCd="${item.opn_cd}"/></span>
											<span class="F_12_black_b">
												${item.kor_nm}/${item.dept_nm}/${item.pos_duty_nm}
											</span>
											<c:if test="${item.subs_appr_yn == 'Y' && (item.opn_cd == '2' || item.opn_cd == '3' || item.opn_cd == '4' || item.opn_cd == '7')}">
												<span class="F_12_black_b">
													(<s:message code="PC.COM.C2_H_146"/> : ${item.substitutionUserName}) <%-- 다국어변환OTO : 대결 --%> 
												</span>
											</c:if>
											<span class="F_11_gray" style="margin-left:10px;">
												<abc:printDtime dtimeStr="${item.reg_dtime}"/>
											</span>
										</span>
										<br/>
										<div style="padding:0px 0 0 40px;">
											${fn:replace(fn:replace(item.opn_cont, newLineChar, '<br/>'), spaceChar, '&nbsp;')}
										</div>
										<br/>
									</c:forEach>
									<c:if test="${empty model_entity.opnList}">
										<span>
											 <s:message code="PC.COM.H1_H_069"/> <%-- 다국어변환OTO : 결재의견이 없습니다 --%> 
										</span>
									</c:if>
								</td>
							</tr>
						</table>
					</div>
					<!-- #1963 [오피스][전자결재] 전자결재 인쇄 버튼 클릭 시 댓글 인쇄 기능 추가 -->
					<!-- 결재댓글 영역 -->
 					<div id="cmtArea" class="table04_box_form">
						<table cellspacing="0" class="table04_form" summary="<s:message code="PC.COM.C4_H_166"/>" style="word-break: break-all;"> <%-- 다국어변환OTO : 결재댓글 --%> 
							<caption><s:message code="PC.COM.C4_H_166"/></caption> <%-- 다국어변환OTO : 결재댓글 --%> 
							<colgroup>
								<col width="140">
								<col width="*">
							</colgroup>
							<tr>
								<th scope="row" style="vertical-align:middle;"><s:message code="PC.COM.C4_H_166"/></th> <%-- 다국어변환OTO : 결재댓글 --%> 
								<td>
									<c:forEach items="${cmtList}" var="item" varStatus="status">
										<span class="user">
											<span class="F_12_black_b">
												<span class="abcUsr" data="${item.reg_usr_key}"><abc:usrShow usr_key="${item.reg_usr_key}"/></span>
											</span>
											<span class="F_11_gray" style="margin-left:10px;">
												<abc:printDtime dtimeStr="${item.reg_dtime}"/>
											</span>
										</span>
										<br/>
										<div style="word-wrap: break-word;padding:5px 0 0 10px;">
											${item.apr_cmt_cont}
										</div>
										<br/>
									</c:forEach>
									<c:if test="${empty cmtList}">
										<span>
											 <s:message code="PC.COM.H1_H_070"/> <%-- 다국어변환OTO : 결재댓글이 없습니다 --%> 
										</span>
									</c:if>
								</td>
							</tr>
						</table>
					</div>	
				</div>
			</c:otherwise>
		</c:choose>
		</div>
	</div>

	<f:form id="aprDocPreviousPrintForm" name="entity" method="POST" commandName="model_entity">
		<f:hidden path="appr_doc_seq" value="${model_entity.appr_doc_seq}"/>
		<f:hidden path="ref_doc_list" value="${model_entity.ref_doc_list}"/>
		<f:hidden path="approvalIds" value="${fn:replace(fn:replace(model_entity.approvalIds, '[', ''), ']', '')}"/>
		<f:hidden path="readLevelAuthorizer" value="${model_entity.readLevelAuthorizer}"/>
	</f:form>

	<input type="hidden" id="approvalLineLocationCode" value="${model_entity.aprCorpCnfg.approval_line_location.code}"/>
	
	<%-- #2889 양식관리 사용자 정의 화면 --%>
	<script type="text/javascript">	
	if( typeof CPView == 'object'){
	    CPView.init({
	        target : $("#formbuilder_view")
	        ,
	        html : $("#formbuilder_view").html()
	        ,
	        type : 'view' //editview | view
	        ,
	        isDoc : true
	        ,
	        apprDocSeq : "${model_entity.appr_doc_seq}"
	        ,
	        docStatus : "${model_entity.appr_doc_stts_cd}"
	    });			    	
	}	
	</script>

</body>
</html>
