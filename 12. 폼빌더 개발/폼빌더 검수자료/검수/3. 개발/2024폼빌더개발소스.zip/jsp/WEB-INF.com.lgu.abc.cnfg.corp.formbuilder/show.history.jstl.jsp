<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ include file="/WEB-INF/tags/taglib.inc"%>
<% pageContext.setAttribute("newLineChar", "\n"); pageContext.setAttribute("spaceChar", " ");%>

<%-- #3155 [구현-결재상신] 폼빌더 양식 용 미리보기 / 인쇄 / 히스토리 페이지 --%>

<!DOCTYPE html>
<html lang="ko">
<head>
<c:set var="browserTitle">Biz <s:message code="PC.COM.C4_H_016"/></c:set> <%-- 다국어변환OTO : 그룹웨어 --%> 
<%@ include file="/WEB-INF/com/lgu/abc/jspf/htmlHead.jspf"%>
<c:if test="${returnCode == '200'}">
<link rel="stylesheet" type="text/css" href="<s:url value='/resources/abc/css/apr/apr.doc.print.jstl.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"/>
<link rel="stylesheet" type="text/css" href="<s:url value='/resources/abc/css/font-load.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"/>
<link rel="stylesheet" type="text/css" href="<s:url value='/resources/jquery.qtip/jquery.qtip.min.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"/>
<script type="text/javascript" src="<s:url value='/resources/jquery-1.8.3/jquery-1.8.3.min.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript" src="<s:url value='/resources/jquery.qtip/jquery.qtip.min.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript" src="<s:url value='/resources/kendoui/js/kendo.web.min.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript" src="<s:url value='/resources/abc/jsUtils/_abc.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<c:choose>
	<c:when test="${sessionScope.user.lang_cd eq 'ko'}">
		<script type="text/javascript" src="<s:url value='/resources/kendoui/js/cultures/kendo.culture.ko.min.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
	</c:when>
	<c:when test="${sessionScope.user.lang_cd eq 'zh'}">
		<script type="text/javascript" src="<s:url value='/resources/kendoui/js/cultures/kendo.culture.zh.min.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
	</c:when>
	<c:when test="${sessionScope.user.lang_cd eq 'ja'}">
		<script type="text/javascript" src="<s:url value='/resources/kendoui/js/cultures/kendo.culture.ja.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
	</c:when>
</c:choose>
<%@ include file="/resources/abc/js/abc-common.jsp"%>
<script type="text/javascript" src="<s:url value='/resources/abc/js/apr/apr.doc.history.cont.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>

<link rel="stylesheet" type="text/css" href="<s:url value='/resources/abc/css/cnfg/corp/cnfg.corp.apr.formbuilder.editedview.jstl.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"/>

<!-- Daum Editor 기본 style 값(인쇄 화면에서는 Editor 를 사용하지 않기 때문에 기본 style 을 지정) -->
<c:if test="${sessionScope.uiManager.editor.code == '2'}">
	<style type="text/css">
		body {font-size:12px;}
		p {font-size:inherit; font-family:inherit;}
	</style>
</c:if>
<style type="text/css">
	#middle {margin-top:45px;}
</style>
<script type="text/javascript">
$(document).ready(function() {
	aprDocHistoryContent.setReady();
	
	var width = $(".formbuilder_editedview.vertical").css("width");
	$(".table04_box_form").css("width", width);
	$(".table05_box_form").css("width", width);

});
</script>
</c:if>
<c:if test="${returnCode != '200'}">
<link rel="stylesheet" type="text/css" href="<s:url value='/resources/abc/css/abc-layout.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"/>
</c:if>
</head>
<body>
<c:if test="${returnCode == '200'}">
	<div id="p_wrapper">
		<!-- 상단 Top 영역 -->
		<div id="header">
			<div class="btn">
				<a href="javascript:void(0);" class="close" onclick="aprDocHistoryContent.windowClose(); return false;"><s:message code="PC.COM.C2_H_027"/></a> <%-- 다국어변환OTO : 닫기 --%> 
			</div>
			<div class="clear"></div>
		</div>
		<!-- 인쇄 영역 -->
		<div style="margin-top: 45px;"><div id="editorArea">
			<div class="formbuilderView" id="formbuilder_view">${content}</div>
		</div></div>
	</div>
</c:if>
<c:if test="${returnCode != '200'}">
	<div class="layerror">
		<div class="messege" style="margin-top:150px;">
			<div class="msg">
				<img src="/resources/abc/images/error_ico.png" />
				<span class="tit" style="font-size:25px; margin-bottom:40px;">${exceptionMessage}</span>
			</div>
		</div>
		<div class="txtAlignC">
			<div class="marginC _btn">
				<button class="home" onclick="window.close(); return false;"><s:message code="PC.COM.C2_H_027"/></button> <%-- 다국어변환OTO : 닫기 --%> 
			</div>
		</div>
	</div>
</c:if>
</body>
</html>
