<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ include file="/WEB-INF/tags/taglib.inc"%>
 
<link rel="stylesheet" type="text/css" href="<s:url value='/resources/abc/css/apr/apr.doc.print.jstl.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"/>
<link rel="stylesheet" type="text/css" href="<s:url value='/resources/abc/css/font-load.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"/>
<link rel="stylesheet" type="text/css" href="<s:url value='/resources/jquery.qtip/jquery.qtip.min.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"/>
<!-- 문석진 추가 다국어용 css 파일 -->
<link rel="stylesheet" type="text/css" href="<s:url value='/resources/abc/css/lang/abc-lang.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"/>
<script type="text/javascript" src="<s:url value='/resources/jquery-1.8.3/jquery-1.8.3.min.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript" src="<s:url value='/resources/jquery.qtip/jquery.qtip.min.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript" src="<s:url value='/resources/ckeditor/ckeditor.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript" src="<s:url value='/resources/kendoui/js/kendo.web.min.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>
<script type="text/javascript" src="<s:url value='/resources/abc/jsUtils/_abc.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>

<link rel="stylesheet" type="text/css" href="<s:url value='/resources/abc/css/cnfg/corp/cnfg.corp.apr.formbuilder.editedview.jstl.css'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"/>
		
<script type="text/javascript" src="<s:url value='/resources/abc/js/abc-common/abc-common-codeFunc.js'/>?version=<s:eval expression='@abcProp[\'version.cache\']'/>"></script>

<% //#3155 [구현-결재상신] 폼빌더 양식 용 미리보기 / 인쇄 / 히스토리 페이지 %>
<script type="text/javascript">
$(document).ready(function() {
	var width = $(".formbuilder_editedview.vertical").css("width");
	$(".table05_box_form").css("width", width);

	if($("#aprDocEditAddDocList li a",parent.window.opener.document).length ==0 ){
		$("#referenceDocList").html('');
	}else{
		$("#referenceDocList").html($("#aprDocEditAddDocList",parent.window.opener.document).html());
	}
	
	$("#referenceDocList button span").removeClass("o-icon o-listDelete");
	$("#referenceDocList li button").contents().unwrap().wrap( '<span></span>' );
	$("#referenceDocList li a").contents().unwrap().wrap( '<span></span>' );
	$("#referenceDocList li" ).css('list-style' ,'none');
	$("#referenceDocList span").addClass("verti_Top");
});
</script>

<div id="preview"  style="height:100%;" class="previewInfo">
	<div id="middle" >
		<div class="content">
			<div class="mB10">
				<button type="button" class="k-button" style="float:right" onclick="PreviousPrint.previewHtmlPrint()"><span class="o-icon o-i-print"><s:message code="PC.COM.C2_H_094"/></span></button>
			</div>
			<div id="printArea">
				<div class="formbuilder_print">
					<div class="formbuilderView formbuilderCenterView" id="formbuilder_view">${model_entity.cont }</div>
				</div>
				<!-- 첨부파일/참조문서 영역 -->
				<div class="table05_box_form" style="display: flex;">
					<table cellspacing="0" class="table04_form" summary="문서">
						<caption>문서</caption>
						<colgroup>
							<col width="140">
							<col width="*">
						</colgroup>
						<tr>
							<th scope="row"><s:message code="PC.COM.C4_H_121"/></th> <%-- 다국어변환OTO : 참조문서 --%> 
							<td class="doc" id="referenceDocList"></td>
						</tr>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
var PreviousPrint = {
	previewHtmlPrint : function(){
		var previewHtml = $("#printArea").html();
		var form_builder_yn = "${model_entity.form_builder_yn }";
		
		var test = window.open("/apr/doc/bfrAprPrint.jstl", "bfrAprPrint", "width=900, height=700, scrollbars=yes","_blank");
		var frmObj = $('<form>', {'id': 'frmPreview', 'action': '/apr/doc/bfrAprPrint.jstl', 'method':'POST', 'target':'bfrAprPrint', 'style':'diplay:none'});
		var inpObj = $('<input>', {'id':'previewHtml', 'name':'previewHtml', 'value':previewHtml, 'style':'display:none'});
		var inpObj2 = $('<input>', {'id':'form_builder_yn', 'name':'form_builder_yn', 'value': form_builder_yn, 'style':'display:none'});
		
		frmObj.append(inpObj);
		frmObj.append(inpObj2);
		
		$(document.body).append(frmObj);
		
		$('#frmPreview').submit();
		$('#frmPreview').remove();
	}
}
</script>
