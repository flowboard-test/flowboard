/**
 * 폼빌더 컴포넌트.
 * 
 * 양식명 컴포넌트
 * 
*/
let CPFormTitle = {

    CP_ID: null
    ,
    CP_TYPE: "CPFormTitle"
    ,
    CP_ITEM_TITLE: "양식명"

    ,
    getAttrView(prop) {

        let vwid = "att_tle";
        let template = `<div id="div_${vwid}" class="formbdTitle"><span>양식명컴포넌트 속성</span></div>
            <ul id="ul_${vwid}" class="formbdMenu">
                <li>
                    <p class="formbdMenuTit">헤더로 사용</p>
                    <div class="formbdMenuCon">
                        <div class="btnWrap">
                            <label  for="toggle" class="toggleSwitchBtn cp_rdheaderToggle off">
                                <span id="cp_rdheader" data-id="${this.CP_ID}" class="togglebtn"></span>
                            </label>
                        </div>
                    </div>
                </li>
                
                <li>
                    <p class="formbdMenuTit">너비</p>
                    <div class="formbdMenuCon">
                        <div class="dropdownArea">
                            <span  title="" class="k-widget k-dropdown k-header formbd_drop" unselectable="on" role="listbox" aria-haspopup="true" aria-expanded="false" tabindex="1" aria-owns="" aria-disabled="false" aria-busy="false" aria-activedescendant="b9638adf-c13e-4791-9aa7-7e060777ee7b" style="width: 60px;"><span unselectable="on" class="k-dropdown-wrap k-state-default">
                            <span unselectable="on" class="k-input">%</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span></span>
                            <input id="cp_txwidthUnit" style="width: 60px; display: none;" class="formbd_drop" name="formbd_drop" type="text" value="" data-role="dropdownlist"></span>
                        </div>
                        <input id="cp_txwidth" name="" style="width:150px;" class="k-textbox mL5" type="number" value="100" >
                        

                        
                        
                    </div>
                </li>
	        	
                <li>
                    <p class="formbdMenuTit">글꼴</p>
                    <div class="formbdMenuCon">
                        <span title="" class="k-widget k-dropdown k-header" style="width:100%;">
                            <span unselectable="on" class="k-dropdown-wrap k-state-default">
                                <span id="disp_cp_cbfont-family" unselectable="on" class="k-input">선택</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span>
                            </span>
                            <select id="cp_cbfont-family" data-role="dropdownlist" style="display: none;">
                            </select>
                        </span>
                    </div>
                </li>
                <li>
                    <p class="formbdMenuTit">정렬</p>
                    <div class="formbdMenuCon">
                        <span title="" class="k-widget k-dropdown k-header" style="width:100%;">
                            <span unselectable="on" class="k-dropdown-wrap k-state-default">
                                <span id="disp_cp_cbtext-align" unselectable="on" class="k-input">왼쪽정렬</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span>
                            </span>
                            <select id="cp_cbtext-align" data-role="dropdownlist" style="display: none;">
                                <option value="left" selected="selected">왼쪽정렬</option>
                                <option value="center">가운데정렬</option>
                                <option value="right">오른쪽정렬</option>
                            </select>
                        </span>
                    </div>
                </li>
                <li>
                    <p class="formbdMenuTit">글자 크기</p>
                    <div class="formbdMenuCon">
                        <span title="" class="k-widget k-dropdown k-header" style="width:100%;">
                            <span unselectable="on" class="k-dropdown-wrap k-state-default">
                                <span id="disp_cp_cbfont-size" unselectable="on" class="k-input">18</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span>
                            </span>
                            <select id="cp_cbfont-size" data-role="dropdownlist" style="display: none;">
                                <option value="12">12</option>
                                <option value="14">14</option>
                                <option value="16">16</option>
                                <option value="18" selected="selected">18</option>
                                <option value="20">20</option>
                                <option value="24">24</option>
                            </select>
                        </span>
                    </div>
                </li>
                
            </ul>`;

        let $templ = $(template);

        $templ.find('#cp_txwidth').on('keyup', function (e) {

            CPElemParent.changeAttrViewHandler(e);
        });
        
        $templ.find('#cp_rdheader').on('click', function (e) {

            let thisEl = $('.cp_rdheaderToggle');
            let cpid = $(e.target).attr('data-id');

            if (thisEl.hasClass('off')) {

                //header option on
                thisEl.removeClass('off');
                $(e.target).attr('value', "on");
            }
            else {
                thisEl.addClass('off');
                $(e.target).attr('value', "off");
            }

            CPElemParent.changeAttrViewHandler(e);

            e.stopPropagation();
        });


        let fntselect2 = $templ.find('#cp_cbfont-size');
        let fntselect3 = $templ.find('#cp_cbtext-align');

        fntselect2.kendoDropDownList();
        fntselect3.kendoDropDownList();

        var data = [
            { text: "%", value: "%" },
            { text: "px", value: "px" },
            //{ text: "em", value: "2" },
        ];
        $templ.find("#cp_txwidthUnit").kendoDropDownList({
            dataTextField: "text",
            dataValueField: "value",
            dataSource: data,
            index: 0
        });

        return $templ;
    }
    ,
    addCompo(prop) {

    	if(CPCommon.isExistComp(this.CP_TYPE)){
    		
    		return;
    	}

        let template = this.getCpHtml(prop);

        let $attrview = CPFormTitle.getAttrView();
        
        let fntselect = $attrview.find('#cp_cbfont-family');                    

        CPElemParent.getFontFamilySelect()
        .then((elem)=>{
        	
        	fntselect.append( elem );

            fntselect.kendoDropDownList();

	        CPElemParent.addComp({
	            cptype: CPFormTitle.CP_TYPE
	            , cpid: this.CP_ID
	            , template: template
	            , vwtemplate: $attrview
	        });
	        
        });   

    }
    ,
    selectComp(prop) {

        let $attrview = CPFormTitle.getAttrView();
        
        let fntselect = $attrview.find('#cp_cbfont-family');                    

        CPElemParent.getFontFamilySelect()
        .then((elem)=>{
        	
        	fntselect.append( elem );

            fntselect.kendoDropDownList();

	        CPElemParent.selectComp({
	            cptype: CPFormTitle.CP_TYPE
	            , cpid: prop.cpid
	            , vwtemplate: $attrview
	            , data_attr: prop.data_attr
	        });
	        
        });    

    }
    ,
    getCpHtml(prop) {

        let cpid = null;

        if (prop && prop.cpid) {
            cpid = prop.cpid;
        } else {
            cpid = this.createCpid();
        }

        this.CP_ID = cpid;

        return `
        <div class="${this.CP_TYPE} previewoff tblformbdCon" id="${cpid}"><span>${CPFormTitle.CP_ITEM_TITLE}</span> <button type="button" class="k-button dltBtn groupTrash"></button></div>
        <div class='${this.CP_TYPE} previewon splitWrap' data-id="${cpid}"> 
            <div class="splitBlock">          

                <!-- 스크립트 입력 -->
        		<span id="pv_${cpid}" style="width:100%;font-family:맑은고딕;font-size:18px;">$AP_FORM_NM$</span>

            </div>
        </div>
        `;

    }
    ,
    createCpid() {

        return 'CPFormTitle_AP_FORM_NM' ;

    }


}
