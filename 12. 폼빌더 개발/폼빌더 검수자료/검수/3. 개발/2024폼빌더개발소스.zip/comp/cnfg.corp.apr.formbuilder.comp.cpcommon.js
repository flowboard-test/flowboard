/**
 * 폼빌더 컴포넌트.
 * 
 * 공통 컴포넌트
 * 
*/
let /**
 * 
 */
CPCommon = {

	_curOrgPopId : null
	,
	_preToggleMenu : 'menu100'
	,
    //함수 축약식
    //메뉴
	menuToggleInit() {
		
		
		function othermenuClose(curid){
			
			$('.menu000').each((i,itm)=>{
				
				if( $(itm).attr('id') != curid){
					$(itm).find('.k-group.k-panel').hide();
				}
				
			});
			
		}

		// 대메뉴 클릭 시 서브메뉴 토글
        $('.menu000').click(function (e) {

            let curid = $(this).attr('id');

            if(curid == undefined) return;

            if( curid.indexOf('menu_') > -1 
                || ( $(e.target).attr('id') && $(e.target).attr('id').indexOf('menu_') > -1 ) ) return;
            
            if(!GB_CUR_STATE.isScreenExpaned)
                othermenuClose(curid);
            
            $('.menu000.k-state-highlight').removeClass('k-state-highlight');
            
            if( CPCommon._preToggleMenu == curid ){
                $(this).find('.k-group.k-panel').slideToggle();
                CPCommon._preToggleMenu = null;
                return;
            }
            
            $(this).find('.k-group.k-panel').slideToggle();
            
            $(this).addClass('k-state-highlight');
            CPCommon._preToggleMenu = curid;
            
            //$(window).scrollTop(0);
        	
        });
        $('a.k-link').removeClass('k-state-selected').removeClass('k-state-focused') ;
        
        $('.k-group .k-item a').click(function (e) {
        	
        	$('a.k-link').removeClass('k-state-selected').removeClass('k-state-focused') ;
        	$(this).addClass('k-state-selected').addClass('k-state-focused');
        });

    }
    ,
    //속성판에 값셋팅.
    setAttrPanel(target, strAttrVal) {

        // format - attribute:value,,,, ex) font-size:5px,font-color:red
        try {

            CPCommon.console.log(strAttrVal)

            target.attr('style', strAttrVal);

        } catch (e) {
            alert('CPCommon.creatAttrJson error: invalid value ' + strAttrVal);
        }

    }
    ,
    setDocHorizon($docbody){
    	//가로모드  justify-content: center;
        $('.formbdEditView').css('display', 'flex');

        $('.formbdEditView').css('overflow-x', 'auto')

        $docbody.css('width', '297mm')
        //$docbody.css('height', GB_CUR_STATE.screenH);
        //$('.laySide').css('min-height', '905px');
        
        GB_PROPS.docDirectionId = 'ASPECT_hori';
    }
    ,
    setDocVertical($docbody){
    	//세로모드  justify-content: center;
    	$('.formbdEditView').css('display', 'flex');

        $('.formbdEditView').css('overflow-y', 'auto');

        //A4 SIZE
        $docbody.css('width', '210mm')
        $docbody.css('min-width', '210mm')
        //$docbody.css('height', GB_CUR_STATE.screenH);
        
        GB_PROPS.docDirectionId = 'ASPECT_vert';
    }
    ,
  //가로세로모드변경.
    changeHorizon($docbody, $target) {
    	
        CPCommon.console.log("target.prop('id')", $target.prop('id'))

        //builder 편집 영역 bg 공통.
        /*
        $('.formbdEditView').css('background-color', 'rgb(235, 226, 226)');
        $('.formbdEditView').css('justify-content', 'center');
        
        $('.formbdEditArea').attr("style"
        , "min-width:100%; background-color: #fcf7f7;  border-radius: 2px;    border-top: 3px solid #00c0ef;    box-shadow: 0px 3px 9px rgba(0,0,0,.5);    background-clip: padding-box;    outline: 0;"); 

		*/
        
        $('.formbd_outBdr').css('position','absolute').css('right','0');

        if ($target != undefined
            && $target.prop('id').indexOf('ASPECT_hori') > -1) {

        	this.setDocHorizon($docbody);
        }
        else {
        	this.setDocVertical($docbody);
        	

        }
    }
    ,
    formWinSizeInit(overH){    	
    	
    	let screenH=(screen.height + 450);

        if(overH){
            screenH = overH + 200;
        }
    	
        GB_CUR_STATE.screenH = screenH;
        screenH += "px";
        
        //console.log('screenH',screenH);
        
    	//$('.formbdContainer').css('height', screenH);
    	//$('.laySide').css('height', $('.formbdContainer').css('height'));
    	////$('.formbdEditView').css('height', '100%');
    	//$('.formbdEditArea ').css('minHeight', screenH);    	
    	
    	return screenH;
    }
    ,
    checkAndExpandDoc(cpid){

        let compId = cpid;
        
        const curComprect = document.querySelector("#" + compId).getBoundingClientRect();
        CPCommon.console.log("curComprect ", curComprect );
        //top menu height 80
        if( ( window.screen.height - 100 ) < curComprect.top ){
        	
        	GB_CUR_STATE.isScreenExpaned = true;
            //expand height
            CPCommon.formWinSizeInit(curComprect.top)

        }
        
    }
    ,
    /***
     * 
     * 가로/세로 보기 뷰모드 기능.
     * 
     * 
    */
    createDocHorizon($parent) {
    	
    	GB_CUR_STATE.screenH = this.formWinSizeInit();
    	
        let htm = `<div class="formbdTitle"><span>속성</span></div>
                        <ul class="formbdMenu">
                            <li>
                                <p class="formbdMenuTit">레이아웃 방향 설정</p>
                                <div class="formbdMenuCon">
                                    <div class="radioWrap">
                                        <span>
                                            <input type="radio" id="ASPECT_vert" name="acpectRadio" id="" class="k-radio" >
                                            <label id="ASPECT_vert_label" for="ASPECT_vert">세로</label>
                                        </span>
                                        <span class="mL15">
                                            <input type="radio" id="ASPECT_hori" name="acpectRadio" id="" class="k-radio">
                                            <label id="ASPECT_hori_label" for="ASPECT_hori">가로</label>
                                        </span>
                                    </div>
                                </div>
                            </li>
                        </ul>
                     <div class="formbdTitle"></div>
                    `;
        let $target = $('.formbdEditView');

        //clear
        $(document).off('click', 'input[name=acpectRadio]');
        $('#aspectArea').remove();

        //event
        $(document).on('click', 'input[name=acpectRadio]', function (e) {
            CPCommon.changeHorizon($parent, $(e.target));
        });

        $('.formbd_outBdr').append($(htm));
        
        /*this.changeHorizon($parent, $('#ASPECT_vert'));
        $('#ASPECT_vert').prop('checked', 'checked');
		*/
        if(GB_PROPS.docDirectionId){
        	$('#'+GB_PROPS.docDirectionId).click();
        }
        else{
        	$('#ASPECT_vert').click();
        }
    }
    ,
    /**
     * 
     * 확대/축소 기능.
     * 
     * 
    */
    createZoomHtml($target){
    	
    	let htm = `
             <!-- Zoom 버튼 -->
			 <div id="zoomPanel" class="ZoomWrap">
			     <button type="button" class="btnZoom"><span class="blind">확대/축소</span></button>
			     <div id="zoomRadioArea" class="Zoomlayer" style="display:none">
			                    <div class="Zoomhead"><p class="title">확대/축소</p></div>
			                    <div class="ZoomCon">
			                        <ul>
			                            <li>
			                                <input type="radio" id="zoomRadio_0" name="zoomRadio"  value="0" checked="checked">
			                                <label for="zoomRadio_0">맞춤 </label>
			                            </li>
			                            <li>
			                                <input type="radio" id="zoomRadio_1" name="zoomRadio" value="4">
			                                <label for="zoomRadio_1">400%</label>
			                            </li>
			                            <li> 
			                                <input type="radio" id="zoomRadio_2" name="zoomRadio" value="2">
			                                <label for="zoomRadio_2">200%</label>
			                            </li>
			                            <li>
			                                <input type="radio" id="zoomRadio_3" name="zoomRadio" value="1" >
			                                <label for="zoomRadio_3">100%</label>
			                            </li>
			                            <li>
			                                <input type="radio" id="zoomRadio_4" name="zoomRadio" value="0.7">
			                                <label for="zoomRadio_4">70%</label>
			                            </li>
			                            <li>
			                                <input type="radio" id="zoomRadio_5" name="zoomRadio" value="0.5">
			                                <label for="zoomRadio_5">50%</label>
			                            </li>
			                            <li>
			                                <input type="radio" id="zoomRadio_6" name="zoomRadio" value="0.3">
			                                <label for="zoomRadio_6">30%</label>
			                            </li>
			                        </ul>
			                        
			                        <div id="zoomSlider" value="80" style="margin-top:5px;"></div>
			                    </div>
			                    
			                    <div class="txtAlignC">
			                        <button type="button" id="ZoomcloseBtn" class="mailsendBtn mL5" onclick="" title="닫기">닫기</button>
			                    </div>
				</div>
			</div>
			<!-- //Zoom 버튼 -->	

            `; 
        //<li><span>사용자 지정:<input type="number" name="" id="zoomInput">(화면배수)</span>
		//</li>    
    	  
    	$('#zoomPanel').remove();
    	
        $(htm).appendTo($target);
        
        this.zoomonEventOn();
    }
    ,
    zoomonEventOn(){
    	
    	let $target = $('#previewArea #content');

        //clear
        $(document).off('click', '.btnZoom');
        $(document).off('change', '#zoomInput');
        $(document).off('click', 'input[name=zoomRadio]');
        $(document).off('click', '#ZoomcloseBtn');
        
        //event
        $(document).on('click', '.btnZoom', function (e) {

            if( $('#zoomRadioArea').is(':visible') ){

                $('#zoomRadioArea').css('animation', 'fade_down 1s');
                $('#zoomRadioArea').hide();

            }
            else{

                $('#zoomRadioArea').css('animation', 'fade_up 1s');
                $('#zoomRadioArea').show();
            }
            
            
        });
        $(document).on('click', 'input[name=zoomRadio]', function (e) {

            let val = $(e.target).val();
            CPCommon.console.log('zoom val ', val)
            
            let left = "50%";
            
            switch( val ){
            
	        	case "0.7" :		        	
		        	left = "30%";
		        	break;
		        	
	        	case "0.5" :	        		
	        		left = "20%";
		        	break;
		        	
	        	case "0.3" :	        		
	        		left = "10%";
		        	break;
		        	
	        	case "0" :
	        	case "1" :
	        		left = "50%";
	        		break;
	        		
	        	case "2" :
	        		left = "60%";
	            	break;
	            	
	        	case "4" :
	        		left = "80%";
	             	break;
	        }
            
            //$("#zoomSlider > .ui-slider-handle").css("left",left);

            if($.isNumeric(val)){
            	
            	/*
            	if(val >= 1){ 
        			val = ( 50 + (Number(val)-1) * 10 ) ;
        		}else{                			
        			val = Number(val) * 50;                			
        		}
            	
            	
            	console.log("!!!!!" , val );
            	

                //val = 1 + ( Number(val) / 10 ) ;
                */
                
                $('#zoomInput').val(val);

                $target.css('zoom',val);  
                
                $("#zoomSlider > .ui-slider-handle").css("left",left);                
                
                
            }
        });
        /*
        $(document).on('change', '#', function (e) {

            let val = $('#zoomInput').val();
            CPCommon.console.log('zoom val', val)

            if($.isNumeric(val)){

                val = 1 + ( Number(val) / 10 ) ;

                $target.css('zoom',val);
                
                
            }
        });
        */
        $("#zoomSlider").slider({
        	min : 10,
        	max : 90,
        	values: [50],
        	stop: function( event, ui ) {
        		        		
        		let val = ui.value;
                if($.isNumeric(val)){
                	try{
                		
                		/*
                		 *  val = 0 zoom 0.1
                		 *  val = 10 zoom 0.3
                		 *  val = 20 zoom 0.5 
                		 *  val = 30 zoom 0.7 
                		 *  val = 40 zoom 0.9
                		 *  val = 50 zoom 1
                		 *  val = 60 zoom 2
                		 *  val = 70 zoom 3
                		 *  val = 80 zoom 4
                		 *  val = 90 zoom 5
                		 */
	                    //val = ( (Number(val)-10) / 20 ) ;
	                    //$target.css('zoom',val);
                		
                		if(val >= 50){ 
                			val = ( 1 + (Number(val)-50) * 0.1 ) ;
                		}else{                			
                			val = Number(val) / 50;                			
                		}
                		
                		$target.css('zoom',val.toFixed(2) );
                		
                	}catch(e){}
                    
                }
        	}
        });
        $('#zoomSlider .ui-slider-handle').css('background', '#2958dc');
         
        $(document).on('click', '#ZoomcloseBtn', function (e) {
            $('#zoomRadioArea').hide();                
        });
        
    }
    ,
    /**  
     * prop : {$target, editorIframeName, iframeHeight}
     * 
     * */
    creatNamoEditor(prop){

        //prop.$target.remove($('[name=editorIframSubmitForm]'));

        function appendHiddenInput( prop ){

            var input2 = document.createElement('input');
            // set attribute (input)
            input2.setAttribute("type", "hidden");
            input2.setAttribute("id",  prop._id);
            input2.setAttribute("name", prop._name);
            input2.setAttribute("value", prop._value);

            prop.targetForm.appendChild(input2);
        }

        let submitFrame = `<iframe id="${prop.editorIframeName}" name="${prop.editorIframeName}" 
                frameborder="0" scrolling="no" style="width:100%; height:${prop.iframeHeight}px;"></iframe>`

        var newForm = document.createElement('form');
        // set attribute (form) 
        newForm.name = "editorIframSubmitForm";
        newForm.method = 'post';
        newForm.action = '/common/editor/namoeditor/editor';
        newForm.target = prop.editorIframeName;

        appendHiddenInput({
            targetForm : newForm
            , _id : 'readonly'
            , _name : 'readonly'
            , _value : 'false'
        });
        appendHiddenInput({
            targetForm : newForm
            , _id : 'toolbar'
            , _name : 'toolbar'
            , _value : 'true'
        });
        appendHiddenInput({
            targetForm : newForm
            , _id : 'height'
            , _name : 'height'
            , _value : prop.iframeHeight
        });
        appendHiddenInput({
            targetForm : newForm
            , _id : 'editorIframeName'
            , _name : 'editorIframeName'
            , _value : prop.editorIframeName
        });
        appendHiddenInput({
            targetForm : newForm
            , _id : 'editorObjectName'
            , _name : 'editorObjectName'
            , _value : newForm.name
        });

        prop.$target.append(newForm);
        prop.$target.append($(submitFrame));

        newForm.submit();

        return;
        
        

    }
    ,
    /** 결재선 설정 treeView **/
    initOranPopup(){
    	
    	let appline_htm = `
    		<div id="aprDocEdit_window_line">
    		<form id="aprDocEdit_windowForm" name="aprDocEdit_windowForm" class="fmConts" action="/cnfg/corp/apr/.jstl?_=1727413701763" method="post" onsubmit="return false">
    			<input type="hidden" name="appr_line_cnfg_seq" value="">
    			<input type="hidden" name="apprLineHiddenStr" value="">
    			<!-- 왼쪽 박스 -->
    			<div class="apprLine_leftBx">
    				<!-- 탭스트립 박스 -->	
    				<div id="tabStrip_apprLine">
    					<ul>
    						<li class="k-state-active">조직도</li>  
    						<li>결재자매크로</li>  
    						<!-- 20201211 결재선 탭 삭제 -->
    						<!-- <li>결재선</li>  -->
    						<li>검색</li>  
    					</ul>
    					<!-- 조직도 treeView -->
    					<div><div id="tabConts_organTree"></div></div>
    					<!-- 결재선 검색 -->
    					<div><div id="tabConts_apprline_search"></div></div>
    				</div>
    			</div>
    			<div class="textbullet win_bottomBx" style="top:385px;">
    				<span style="font-size:10.5px;"><img class="k-image" src="/resources/abc/images/new_images/org/ico_user1.png"> 부서장</span>  
    				<span style="font-size:10.5px;"><img class="k-image" src="/resources/abc/images/new_images/org/ico_user2.png"> 접수담당자</span>  
    				<span style="font-size:10.5px;"><img class="k-image" src="/resources/abc/images/new_images/org/ico_user3.png"> 근태관리자</span>  
    				<span style="font-size:10.5px;"><img class="k-image" src="/resources/abc/images/new_images/org/ico_user4.png"> 결재문서함관리자</span>  
    			</div>
    			<div class="win_bottomBx" style="top:410px;">
    				<span class="ftStrong">* * 부서/사용자 클릭시 결재선에 추가 됩니다.<!-- 부서/사용자 클릭시 결재선에 추가 됩니다. --></span>
    			</div>
    			<div class="apprLine_rightTopBx">
    				<span class="floatL mailsendBtn-margin">
    					<button class="k-button" onclick="aprDocEditWin_line.clickDeleteAll()">모두 삭제<!-- 모두 삭제 --></button>
    					<button class="k-button" onclick="aprDocEditWin_line.clickDelete()">삭제</button>  
    				</span>
    				<span class="floatR mailsendBtn-margin">
    					<button class="multiBtn_left" title="" onclick="aprDocEditWin_line.clickUp()">위로</button>  
    					<button class="multiBtn_right" title="" onclick="aprDocEditWin_line.clickDown()">아래로</button>  
    				</span>
    			</div>
    			<!-- 오른쪽 박스 -->
    			<div class="apprLine_rightBx">
    				<div id="apprLineWindowGrid" style="overflow:auto;"></div>
    			</div>
    			<!-- 하단 버튼박스  -->
    			<div class="apprLine_btnBx" style="top:410px;">
    				<div class="floatL">
    					<input type="text" name="appr_line_tit" id="appr_line_tit" class="k-textbox" style="width:300px;">
    					<button id="apprLineSaveBtn" class="k-button" onclick="aprDocEditWin_line.onSave()">결재선 저장</button>
    				</div>
    				<div class="floatR">
    					<button class="mailsendBtn" onclick="aprDocEditWin_line.onApply()">확 인</button>&nbsp;&nbsp;
    					<button class="k-button" onclick="aprDocEditWin_line.onClose()">취 소</button>
    				</div>
    			</div>
    		</form>
    	</div>
    	`;
    	
    	$('body')
    	.append('<div id="kendoWindow"></div>')
    	.append('<div id="form_appr_line"></div>')
    	.append($(appline_htm));
    }
    ,
    paintApprLineWindow : function() {
    	
    	$("#aprDocEdit_window_line").show();
    	//this.initOranPopup();
    	$('#apprLineWindowGrid').html('');

    	$('#form_appr_line').val('');

		if (aprDocEditWin_line.aprDocEdit_window != null) {
			aprDocEditWin_line.configIdOverlap = true;

			aprDocEditWin_line.onOpen();
			
			CPCommon.hideLoading();
			return;
		}
		aprDocEditWin_line.setMode(1);
		//45gram !important
		aprDocEditWin_line.cpEditor = true;
		aprDocEditWin_line.onOpen();
		
		CPCommon.hideLoading();
	}
    ,
    showLoading(){

		$('#bodyblockDiv').show();
		$('#loadingView').show();
    }
    ,
    hideLoading(){
    	
    	$('#bodyblockDiv').hide();
    	$('#loadingView').hide();
    	$('#panelBar_LblCnfgBx').hide();
    }
    ,
    cmmBlindOpen(){
    	$('#bodyblockDiv').show();
    }
    ,
    cmmBlindClose(){
    	$('#bodyblockDiv').hide();
    }
    ,
    ajaxError: function(x, e){
		
		var params = {
				msg: $.i18n_json("PC.SCR.CMN_H1_H_064"),//오류가 발생했습니다.",
				callback : function() {
					$(".k-loading-mask").remove();   
				}
		};
		
		if (x.status == 403) {
			window.location = "/error/403";
		} else if (x.status == 404) {
			window.location = "/error/404";
		} else if (x.status == 500) {
			//window.location = "/error/500";
		} else if (x.status == 501) {
			window.location = "/error/501";
		} else if (x.status == 503) {
			window.location = "/error/503";
		} else if (x.status == 505) {
			window.location = "/error/505";
		} else if (x.status == 600) { // 사용자 정의(차세대그룹웨어) IllegalRequestException
			params.msg = JSON.parse(x.responseText).message;
			layCmn.alert(params);
		} else if (e == 'parsererror') {
			alert('Error.\n Parsing JSON Request Failed.');
			CPCommon.cmmBlindClose();
			$(".k-loading-mask").remove();   
		} else if(e == "error") {
			layCmn.alert(params);
		} else {
			if(x.responseText != null) {
				params.msg = JSON.parse(x.responseText).message;
			}
			layCmn.alert(params);
		}
	}
    ,
    labelWithDelButton($target, text){
    	
    	$target.append($(`<button class="mailsendBtn mL5">${text}&nbsp;<a class='itemdel' onclick='$(this).parent().remove()'>X</a></button>`));
    	
    }
    ,
    collectRreviewHtml(){

        const _style = GB_PROPS.docDirectionId == "ASPECT_vert" ?"vertical":"horizontal";

        let collecthtm = '<div id="builderContArea" class="formbuilder_editedview '+ _style +'">'+CPPreview.mix()+'</div>';

        $('#previewArea').remove();
        
        return collecthtm;       

    }
    ,
    popExec(cont=""){
		/*
		 * <button id='changeView' onclick='CPView.changeViewMode()'>changeView</button>
        	<button id='revokeView' onclick='CPView.revokeEditPreview()'>revokeView</button>
		 * 
		 * */
		//45gram	
        let previewArea = `
        <section id="previewArea" class="formbuilder_editedview" style="overflow:auto">
            <button id='close' onclick='CPCommon.hidePopup();'>X</button>
            <article id='content' >${cont}</article>
        </section>`;

        document.body.insertAdjacentHTML("beforeend",previewArea);
        document.body.style.overflow = "hidden";
        
        //CPPreview.previewFuncInit();
        
        CPView.init({
            target : $("#previewArea #content")
            ,
            html : $("#previewArea #content").html()
            ,
            type : 'editview'
        });
        
        if(GB_PROPS.docDirectionId == 'ASPECT_hori'){
        	CPCommon.setDocHorizon($("#previewArea #content"));
        }
        else{
        	CPCommon.setDocVertical($("#previewArea #content"));
        }
        
        CPCommon.hideLoading();
        
        CPCommon.createZoomHtml($('#previewArea'));
        
	}
    ,
    //메인 > 양식보기
    showPopup(){
    	
    	const _html = CPPreview.mix();    	
    	
    	if( _html == "" ){    		
    		CPCommon.popExec();
    		return;
    	}  
        
        
        CPElemParent.getMacroTagChangeAllHtml(_html)
    	.then(data => {
    		
    		CPCommon.popExec(data);
    		//CPCommon.console.log( 'getMacroTagChangeAllHtml', data );
    	})
    	.catch(err => {
    		
    		let logerr = err;

    	}); 

    }
    ,
    //불러오기 > 양식보기
    loadPreviewPopup(_html){
    	
    	
    	
        CPElemParent.getMacroTagChangeAllHtml(_html)
    	.then(data => {    		
    		CPCommon.popExec(CPPreview.mix(true,data));
    	})
    	.catch(err => {
    		
    		let logerr = err;

    	}); 

    }
    ,

    hidePopup(){

        $("#previewArea").remove();

        document.body.style.overflow = "auto";
        
        //불러오기 경우는 팝업이 오픈상태로 있어야 하므로 백그라운드를 다시 켜줌.
        if(CPPreview.copy == null){
        	
        	this.cmmBlindOpen();
        }
        
    }
    ,
    isExistComp(cptype){
    	
    	let chk = GB_PROPS.bdview.find('.'+ cptype).length > 0;
    	
    	if(chk){
    		layCmn.alert({
                msg: "해당 컴포넌트는 문서에 하나만 사용가능합니다. \n삭제 후 추가하세요.",
                callback: function (e) { }
            });
        	
    		return true;
    	}
    	
    	return false;
    }
    ,
    isNotNull(str){
    	
    	if(str != null && str != ''){
    		return true;
    	}
    	
    	return false;
    }
    ,
    encryptData(str){
    	
    	if(this.isNotNull(str))
        	return approvalAtchFile.encryptSeq(str);
    	else
    		return str;
    }
    ,
    encryptSeq : function(appr_doc_seq, callfunc) {
		
		var params = {"appr_doc_seq" : appr_doc_seq};
		var encryptedData;
		
		$.ajax({
			url:  "/apr/docatchfilemap/cipherDataEncryptor",
			type: "POST",
			data: params,
			async: false,
			success: function (res) {
				callfunc( encodeURIComponent(res.appr_doc_seq) );
        	}
        });
	}
       
}

CPCommon.console = {
    mode: 'dev'
    ,
    log(...arg){

        if(this.mode == 'debug')
            console.log("[CPCommonlog]" + arg[0], arg[1]);

    }
}   