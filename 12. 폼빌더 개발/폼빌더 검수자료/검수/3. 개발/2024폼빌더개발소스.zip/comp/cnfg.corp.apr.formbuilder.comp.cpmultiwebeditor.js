/**
 * 폼빌더 컴포넌트.
 * 
 * 타이틀 컴포넌트
 * 
*/

let CPMultiWebeditor = {

    CP_ID: null
    ,
    CP_TYPE: 'CPMultiWebeditor'
    ,
    CP_ITEM_TITLE : '편집기'
    ,
    getAttrView(prop) {

    	let vwid = "att_tle";
    	
    	let template = `<div id="div_${vwid}" class="formbdTitle"><span>편집기 속성</span></div>
             <ul id="ul_${vwid}" class="formbdMenu">
                 <li>
                     <p class="formbdMenuTit">텍스트 편집을 할 수 있는 편집기(에디터)
</p>
                 </li>
             </ul>
             `;
        let $templ = $(template);

        return $templ;   
    }
    ,
    addCompo(prop){

        let template = this.getCpHtml(prop);
        
        let $attrview = this.getAttrView()                  

        CPElemParent.addComp({
            cptype: this.CP_TYPE
            ,cpid: this.CP_ID
            ,template: template
            ,vwtemplate: $attrview
        });                 
        
    }
    ,
    selectComp(prop){

        let template = this.getCpHtml();
        
        let $attrview = this.getAttrView()               

        CPElemParent.selectComp({
            cptype: this.CP_TYPE
            ,cpid: prop.cpid
            ,template: template
            ,vwtemplate: $attrview
            ,data_attr: prop.data_attr
        });          
        
    }
    ,
    getCpHtml(prop){

        let cpid = null;
        let cptitle = null;

        if(prop && prop.cpid){
            cpid = prop.cpid;
            cptitle = prop.cptitle;
        }else{
            cpid = this.createCpid();
            cptitle = this.CP_ITEM_TITLE;
        }
        
        this.CP_ID = cpid;        

        return  `
        <div class="${this.CP_TYPE} previewoff tblformbdCon" id="${cpid}"><span>${cptitle}</span> <button type="button" class="k-button dltBtn groupTrash"></button></div>
        <div class='${this.CP_TYPE} previewon' data-id="${cpid}"></div>
        `;

    }
    ,
    createCpid(){

        return this.CP_TYPE + '_' + Math.floor(Math.random() * 10000);

    }

};