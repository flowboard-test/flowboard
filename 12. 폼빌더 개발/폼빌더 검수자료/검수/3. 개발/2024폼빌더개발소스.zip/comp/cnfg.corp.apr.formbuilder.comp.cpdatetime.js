/**
 * 폼빌더 컴포넌트.
 * 
 * 시간 컴포넌트
 * 
*/

let CPDateTime = {

    CP_ID: null
    ,
    CP_TYPE: 'CPDateTime'
    ,
    CP_ITEM_TITLE: '시간'
    ,
    getAttrView(prop) {

        let vwid = "att_tle";
        let template = '<li></li>';

        let $templ = $(template);

        return $templ;
    }
    ,
    addCompo(prop) {

        let cpid = this.CP_ID = this.createCpid();
        let cptitle = this.CP_ITEM_TITLE;

        let optionhtml = '';

        /**
         * abcDtime function
         * 
         * abc.core\src\main\webapp\resources\abc\js\abc-common\abc-common-codeFunc.js
        */
        let tohr = abcDtime.getTodayHourClient();
        // 오늘분(클라이언트)
        let tomin = abcDtime.getTodayMinuteClient();
        let selected = 'selected';

        CPCommon.console.log('tohr',tohr);
        CPCommon.console.log('tomin',tomin);
        
        for (let i = 0; i < 24; i++) {

            if(i != tohr && ('0'+i) != tohr){ selected = ''; }
            else selected = 'selected';

            if (i < 10)
                optionhtml = optionhtml.concat(`<option value="0${i}" ${selected}>0${i}</option>`);
            else
                optionhtml = optionhtml.concat(`<option value="${i}" ${selected}>${i}</option>`);

        }
        let optionminhtml = '';
        for (let i = 0; i < 60; i++) {

            if(i != tomin && ('0'+i) != tomin){ selected = ''; }
            else selected = 'selected';

            if (i < 10)
                optionminhtml = optionminhtml.concat(`<option value="0${i}" ${selected}>0${i}</option>`);
            else
                optionminhtml = optionminhtml.concat(`<option value="${i}" ${selected}>${i}</option>`);

        }

        let template = `
             <div class="${this.CP_TYPE} previewoff tblformbdCon" id="${cpid}"><span>${cptitle}</span> <button type="button" class="k-button dltBtn groupTrash"></button></div>
             <div class='${this.CP_TYPE} previewon ' data-id="${cpid}"> 
                 <div class="" id="pvdiv_${cpid}" >          

                     <!-- preview area -->
        	 		<span><select id="pv_${cpid}_hr" class="pview-kendo-datetime" style="width:50px;">${optionhtml}</select></span>  시
                    &nbsp;<span><select id="pv_${cpid}_min" class="pview-kendo-datetime" style="width:50px;">${optionminhtml}</select></span>  분

                 </div>
             </div>
             `;

        CPElemParent.addComp({
            cptype: CPDateTime.CP_TYPE
            , cpid: this.CP_ID
            , template: template
            , vwtemplate: CPDateTime.getAttrView()
        });

    }
    ,
    selectComp(prop) {

        this.CP_ID = prop.cpid;

        CPElemParent.selectComp({
            cptype: CPDateTime.CP_TYPE
            , cpid: this.CP_ID
            , vwtemplate: CPDateTime.getAttrView()
            , cp_attr_set_fn: CPDateTime.setAttItemHtml
        });

    }

    ,
    createCpid() {

        return CPDateTime.CP_TYPE + "_" + Math.floor(Math.random() * 10000);

    }

}
