let CPCalculator = {

    CP_ID : null
    ,
    CP_TYPE : "CPCalculator"
    ,
    CP_ITEM_TITLE : "가로연산" 
    ,
    CP_STYLE : 'row' 
    ,
    CP_UseableItemLists : new Object()
    ,
    msg : {
        "not-in-table" : '연산컴포넌트는 테이블 내에서 생성이 가능합니다.',
        "onlyone" : '하나의 행에 1개의 세로연산컴포넌트만 입력할 수 있습니다.',
        "onlyone-col" : '하나의 열에 1개의 가로연산컴포넌트만 입력할 수 있습니다.',
        "isMerged" : '연산컴포넌트는 표합치기 해제 후 생성이 가능합니다.',
        "noMerge" : '연산컴포넌트 삭제 후 표합치기 가능 합니다.',
        "alert001" : '해당 속성과 동일한 행에 숫자 속성을 추가 후 사용 가능 합니다.',
        "alert002" : '공백을 삭제 했습니다.',
        "alert003" : '불완전한 수식입니다.',        
        "alert004" : '연결된 함수가 없습니다.',
        "alert005" : '는 사용이 불가능 합니다.',
        "alert006" : '` ( ` 괄호 앞에 수식을 입력 하세요.',
    }
    ,
    onOffClass : 'calculator'
    ,

    alert( type = '' ){
        let _msg = this.msg[type];
        
        if( _msg ) 
        	//alert(_msg);
	        layCmn.alert({
	            msg: _msg,
	            callback: function (e) { }
	        });
        //else console.log("alert" , type);
    }
    ,
    getTitle(){

        let _title = this.CP_ITEM_TITLE;

        if( CPCalculator.CP_STYLE =='col') _title = "세로연산";
        else if( CPCalculator.CP_STYLE =='row') _title = "가로연산";

        CPCalculator.CP_ITEM_TITLE = _title;

        return _title;
        
    }
    ,
    getDataTarget(_style){

        let _data = "data-row-target";

        if( _style =='col') _data = "data-col-target";

        return _data;
    }

    ,
    setCPSTYLE(cpstyle=''){
        if(cpstyle)
        this.CP_STYLE = cpstyle;
    }
    ,
    
    getAttrView(prop){

        let vwid = "att_tle";

        let templateAdd = `
                        <li>
                            <p class="formbdMenuTit">멀티로우</p>
                            <div class="formbdMenuCon">
                                <div class="btnWrap">
                                    <label for="toggle" class="toggleSwitchBtn off">
                                        <input type='button' id="cp_multirow" class="togglebtn" value="off" style=" border:0;font-size:0;">                                           
                                    </label>
                                </div>
                            </div>
                        </li>
                        `;

        let calculatorBoard = ` 
                                <span data-style="+">+</span>
                                <span data-style="-">-</span>
                                <span data-style="*">x</span>
                                <span data-style="/">%</span>
                                <span data-style="(">(</span>
                                <span data-style=")">)</span>  
                            `;

              
        /*    
        col = 세로연산
        row = 가로연산
        */
        if( CPCalculator.CP_STYLE =='col'){
            templateAdd ='';   
            calculatorBoard = `<span data-style="+">+</span>`;
        }
        
        const notice =  CPCalculator.CP_STYLE =='col'?"예) A1+A2+A3":"예) (A1-2*B1-2)/C1*2";

        let template = `<div id="div_${vwid}" class="formbdTitle"><span>${this.getTitle()} 속성</span></div>
                        <ul id="ul_${vwid}" class="formbdMenu">

                            <li>
                                <p class="formbdMenuTit">사용 가능 항목</p>
                                <div class="formbdMenuCon">
                                    <div id="useableItemListsWrap">
                                        <div> loading...</div>                                        
                                    </div>
                                </div>

                                <div id="useableCalListsWrap">
                                    ${calculatorBoard}                                  
                                </div>

                            </li>                            
                            
				        	<li>
                                <p class="formbdMenuTit disInline vM">연산식 입력</p>
                                <span class="formbdicon_Question vM mB10"><p class="formbd_notes_wrap">${notice}</p></span>
                                <div class="formbdMenuCon">
                                    <input id="cp_calculator" name="" style="width:100%;" class="k-textbox" type="text"  value="" placeholder="함수를 입력하세요.">
                                    <span id="cp_calculator_alert" class="alert"></span>
                                </div>
				        	</li>                

                            ${templateAdd}

                            
                        </ul>`;

    

        let $templ = $(template);           


        //이벤트 연결
        let fntradio = $templ.find('#cp_multirow');
        fntradio.on('click',function (e) {
            if($(e.target).parent('label').hasClass('off')){
                $(this).parent('label').removeClass('off'); 
                $(`#${CPCalculator.CP_ID}popBtnArea`).removeClass('dn');
                $(this).attr('value','on');
            }
            else{
                $(this).parent('label').addClass('off');
                $(`#${CPCalculator.CP_ID}popBtnArea`).addClass('dn');
                $(this).attr('value','off');
            }
 
            CPElemParent.changeAttrViewHandler(e);
        });

        $templ.find('#cp_calculator').on('keyup',function (e) {
            CPCalculator.checkCalculatorData();
            CPElemParent.changeAttrViewHandler(e);
        });

        $templ.find('#useableItemListsWrap,#useableCalListsWrap').on('click',function (e) {

            const _tag = $(e.target).attr("data-style");
            const _cp_calculator = $("#cp_calculator");
            const _cp_calculator_txt = _cp_calculator.val();

            if( _tag == undefined ||_tag=='' )return false;           
            
            _cp_calculator.val(  
                _cp_calculator_txt.substring(0,_cp_calculator[0].selectionStart) +
                _tag + 
                _cp_calculator_txt.substring(_cp_calculator[0].selectionEnd, _cp_calculator_txt.length) 
            );

            _cp_calculator.focus();

            CPCalculator.checkCalculatorData();
            CPElemParent.changeAttrViewHandler(e);

        });

        $templ.find('#useableItemListsWrap').on('mouseover',function (e) {

            $(".CPNumber.previewoff").each((_,itm)=>{

                if( $(itm).attr("id") == $(e.target).attr("data-id")){

                    $(itm).addClass("here");

                    setTimeout(() => {
                        $(itm).addClass("end");
                    }, 500);

                    setTimeout(() => {
                        $(itm).removeClass("end");
                        $(itm).removeClass("here");
                    }, 1000);                    

                }
                
            });

        });
    
        return $templ;                
    }
    ,
    checkCalculatorData(CPCalculatorID=''){

        //flush
        CPCalculator.onCalculator(false);
        //CPCalculator.onCalculatorItemFlush();

        //flush
        const _cp_calculator = $("#cp_calculator");
        if( _cp_calculator.length == 0 ){
            CPCalculator.onCalculatorItem([]);
            return;
        }

        const _alert = $('#cp_calculator_alert');
        _alert.html("");

        const _pv_data = $(`#pv_${CPCalculator.CP_ID}data`);
        _pv_data.val('');

        const _pv_txt = $(`#pv_${CPCalculator.CP_ID}calFrom`);
        _pv_txt.html("");   


        //
        let _val = _cp_calculator.val().toUpperCase();

        const CP_UseableItemListsKey = Object.keys(CPCalculator.CP_UseableItemLists);

        if(_val.length == 0 || CP_UseableItemListsKey.length == 0 ) 
            return CPCalculator.onCalculatorItem([]);

        if( CP_UseableItemListsKey.length == 0) {
            _alert.html(CPCalculator.msg.alert001);
            return;
        }

        //대문자로 변경
        _cp_calculator.val(_val);

        //공백 제거
        const blank = /\s/g;
        if( _val.match( /\s/g ) ){ 
            _alert.html(CPCalculator.msg.alert002);
            _cp_calculator.val( _val.replace( blank,''));
            return;
        }           

        let _function = [];
        _function.push("+");
        _function.push("-");
        _function.push("*");
        _function.push("/");
           


        //함수 테스트
        let _valTest = _val;
        _function.forEach((_f)=>{
            _valTest = _valTest.replaceAll(_f,",");               
        });



        /**
         * A(B+C)경우 에러로 처리 한다. => A*(B+C)
         */
        if( _valTest.includes("(") ){

            const _valTestArray = [..._valTest];
            let _next = _valTest.indexOf("(");
            while(_next > -1){    
                
                if(_next > 0 && _valTestArray[_next-1] != ',' ){
                    CPCalculator.onCalculator(false);
                    _alert.html(CPCalculator.msg.alert006);
                    break;
                }
  
                _next =  _valTest.indexOf("(", _next + 1);               
            } 
        }



        if( 
            //중복 수식
            _valTest.includes(",,") ||

            //수식 맨앞 맨뒤
            _valTest.substr(0, 1) ==',' || 
            _valTest.substr(_valTest.length-1, 1) ==',' ||

            //소가로 갯수
            _valTest.split('(').length != _valTest.split(')').length
        ){
            CPCalculator.onCalculator(false);
            _alert.html(CPCalculator.msg.alert003);
            return;
        }
            





        _function.push("(");
        _function.push(")");

        _function.forEach((_f)=>{
            _val = _val.replaceAll(_f,",");               
        });
            
            





        //check 
        let _msg = [];
        //중복값제거
        let splitVal =  [...new Set(_val.split(","))];

        //선처리
        CP_UseableItemListsKey.forEach((key)=>{                
            splitVal.some((split,idx,arr)=>{

                    //공백 제거
                    if(split.trim() == ''){
                        splitVal.splice(idx, 1);
                        return true;
                    }

                    //숫자사용 허용시           
                    if(/[0-9]/.test(split) && /[A-Z]/.test(split) == false){
                        splitVal.splice(idx, 1);
                        return true;
                    }                                   

                });  
        });

        //가능한 문자 추출
        CP_UseableItemListsKey.forEach((key)=>{                
                splitVal.some((split,idx,arr)=>{                    

                    if( key != split && arr.length-1 == idx && key.includes(split)){
                        splitVal.splice(idx, 1);
                        _msg.push(key);
                    }                                     

                });  
        });


        //사용허용된 값 제거
        let usedItemKey = [] ;
        CP_UseableItemListsKey.forEach((key)=>{                
                splitVal.forEach((split,idx)=>{
                    if(key == split){
                        splitVal.splice(idx, 1);  
                        usedItemKey.push(key);
                    }                   
                });
        });


        //used item display change
        CPCalculator.onCalculatorItem(usedItemKey);  


        //나머지는 사용 불가
        if(splitVal.length>0){
            CPCalculator.onCalculator(false);
            _alert.html(`${splitVal.join(',')}${CPCalculator.msg.alert005}`);
            return;
        }
           
        //참고 할만한 값 표출
        if(_msg.length>0){
            CPCalculator.onCalculator(false);
            _alert.html(_msg.join(','));
            return;
        }


                 



        //finish
        const dumChar = '^@^';
        const addValueDumChar = '@';
        let _finish_val = dumChar+_cp_calculator.val()+dumChar;
        _function.forEach((_f)=>{
            _finish_val = _finish_val.replaceAll(_f,dumChar+_f+dumChar);               
        }); 

        let set_data = _finish_val;
        let set_txt = _finish_val;

        CP_UseableItemListsKey.forEach((key)=>{ 
            set_data = set_data.replaceAll( dumChar+key+dumChar,  addValueDumChar+CPCalculator.CP_UseableItemLists[key]+addValueDumChar);     
            set_txt = set_txt.replaceAll( dumChar+key+dumChar,  "<span>"+key+"</span>");     
        });
            
        //
        _pv_data.val(set_data.replaceAll(dumChar,  ''));
        _pv_txt.html(set_txt.replaceAll(dumChar,  ''));



        //flush
        //console.log("!!!!checkCalculatorData");

    }
    ,
    onCalculator(show = true){

        const _pv_alert = $(`#${CPCalculator.CP_ID}alertmsg`);  
        const _CPCalculator = $(`#${CPCalculator.CP_ID}`).closest(".changeWrap");
        if( show ){  
                 
            _pv_alert.html("");

            _CPCalculator.addClass(CPCalculator.onOffClass);
            _CPCalculator.addClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);
            _CPCalculator.find(".previewon").addClass(CPCalculator.onOffClass);
            _CPCalculator.find(".previewon").addClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);
            _CPCalculator.find(".previewoff").addClass(CPCalculator.onOffClass);
            _CPCalculator.find(".previewoff").addClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);

        }else{

            _pv_alert.html(CPCalculator.msg.alert004);

            //_CPCalculator.addClass("888");
            _CPCalculator.removeClass(CPCalculator.onOffClass);
            _CPCalculator.removeClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);
            _CPCalculator.find(".previewon").removeClass(CPCalculator.onOffClass);
            _CPCalculator.find(".previewon").removeClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);
            _CPCalculator.find(".previewoff").removeClass(CPCalculator.onOffClass);
            _CPCalculator.find(".previewoff").removeClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);


            //
            CPCalculator.onCalculatorItemFlush();

            //
            /*
            const _changeWrap = $(`#${CPCalculator.CP_ID}`).closest(".changeWrap");
            let _getID =_changeWrap.find(".CPCalculator.previewon").attr('data-total-target'); 
            if(_getID != undefined){
                $(`#${_getID}`).addClass('twinkle');                
                $(`#${_getID}`).addClass('twinkle001');                
            }
            */


        }

    }
    ,

    onCalculatorItemFlush(){
        

        if(!CPCalculator.CP_ID) this.alert('no-cpID');
         

        if(  
            GB_CUR_STATE.CP_ID != CPCalculator.CP_ID && 
            $(`#${CPCalculator.CP_ID}`).not('.calculator').length > 0 
        ){

           // $(`#${CPCalculator.CP_ID}`).click();

           //console.log("test target -- 99");

        }


        $(".changeWrap").each((_,itm)=>{

            const _itms = $(itm).find('.previewon.calculator');
            const _style_col = $(itm).find(".CPNumber.previewon").attr(`data-col-target`);
            const _style_row = $(itm).find(".CPNumber.previewon").attr(`data-row-target`);  
            
            //check flush able(1/4)
            //let flush = true;
            if( (CPCalculator.CP_STYLE == 'col' && _style_row != undefined && CPCalculator.CP_ID != _style_col) ||
                (CPCalculator.CP_STYLE == 'row' && _style_col != undefined && CPCalculator.CP_ID != _style_row)
            ){
                //flush = false; 
                return true;              
            }

            //내부에 수식이 없는 경우.
            if( 
                $(_itms).length == 0 && 
                _style_row == undefined && 
                _style_col == undefined && 
                $(itm).hasClass(CPCalculator.onOffClass) 
            ){               

                //if(flush){
                //console.log("777",CPCalculator.CP_STYLE , _style_row , _style_col , itm );
                //$(itm).addClass("777");
                $(itm).removeClass(CPCalculator.onOffClass);
                //}
                
                $(itm).removeClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);
            }

            //테스트중
            if($(itm).find('.previewon').hasClass(CPCalculator.CP_TYPE)){                    
                //console.log("test - 241107 - onCalculatorItemFlush" , itm);
                return true;
            }

            //테스트중2
            if($(_itms).hasClass(CPCalculator.onOffClass) == false){
                //console.log("calculator - false" , itm);
            }


            if( 
                $(itm).hasClass(CPCalculator.onOffClass) == false ||
                CPCalculator.CP_ID == $(itm).attr(CPCalculator.getDataTarget(CPCalculator.CP_STYLE))
            ){

                //$(itm).addClass("666");
                $(itm).removeClass(CPCalculator.onOffClass);
                $(itm).find(".previewon").removeClass(CPCalculator.onOffClass);
                $(itm).find(".previewon").removeClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);
                $(itm).find(".previewon").removeAttr(CPCalculator.getDataTarget(CPCalculator.CP_STYLE));
                $(itm).find(".previewoff").removeClass(CPCalculator.onOffClass);
                $(itm).find(".previewoff").removeClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);

            }
             
        });

    }

    ,
    onCalculatorItem(lists){        

        //CPCalculator.CP_ID

        const CP_UseableItemListsKey = Object.keys(CPCalculator.CP_UseableItemLists);

        if( CP_UseableItemListsKey.length == 0) return;

        //console.log("onCalculatorItem", CP_UseableItemListsKey,lists);
        

        if( lists.length > 0 ){          
            this.onCalculator(true);
        }else{
            this.onCalculator(false);
        }
        

        CP_UseableItemListsKey.some((key)=>{

            const _itemID = CPCalculator.CP_UseableItemLists[key];
            const _changeWrap = $(`#${_itemID}`).closest(".changeWrap");

            if( _changeWrap.length <= 0 ) return true;
            

            if(lists.includes(key)){

                _changeWrap.addClass(CPCalculator.onOffClass);
                _changeWrap.addClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);
                _changeWrap.find(".previewon").addClass(CPCalculator.onOffClass);
                _changeWrap.find(".previewon").addClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);
                _changeWrap.find(".previewon").attr(CPCalculator.getDataTarget(CPCalculator.CP_STYLE),CPCalculator.CP_ID);
                _changeWrap.find(".previewoff").addClass(CPCalculator.onOffClass);
                _changeWrap.find(".previewoff").addClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);
                
            }else{

                const _style_col = $(_changeWrap).find(".CPNumber.previewon").attr(`data-col-target`);
                const _style_row = $(_changeWrap).find(".CPNumber.previewon").attr(`data-row-target`);   
    
    
                //check flush able(2/4)
                if( _style_row == undefined && _style_col == undefined ){
                /*                     
                if( _style_row != undefined || 
                    _style_col != undefined ||
                    (CPCalculator.CP_STYLE == 'col' && _style_row != undefined && CPCalculator.CP_ID != _style_col) ||
                    (CPCalculator.CP_STYLE == 'row' && _style_col != undefined && CPCalculator.CP_ID != _style_row)
                ){
                */

                    //console.log("555",CPCalculator.CP_STYLE , _style_row , _style_col , _changeWrap );
                    //_changeWrap.addClass("555");
                    _changeWrap.removeClass(CPCalculator.onOffClass);
                    _changeWrap.find(".previewon").removeClass(CPCalculator.onOffClass);
                    _changeWrap.find(".previewoff").removeClass(CPCalculator.onOffClass);
                }
                    
                    _changeWrap.removeClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);                
                    _changeWrap.find(".previewon").removeClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);
                    _changeWrap.find(".previewon").removeAttr(CPCalculator.getDataTarget(CPCalculator.CP_STYLE));
                    _changeWrap.find(".previewoff").removeClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);
                

            }

            //flush table data
            if( typeof CPTable == 'object' && $(`#${_itemID}`).closest("TD").length > 0 ){            
                CPTable._table.setItemData( $(`#${_itemID}`).closest('TD')[0] );
            }
            

        });

    }
    ,
    flushItems(_table=''){

        if( _table == '' && $(`#${CPCalculator.CP_ID}`).closest('table').length > 0 ){  
            _table = $(`#${CPCalculator.CP_ID}`).closest('table')[0];
        } 

        if( _table == '' ){
            this.alert('no-table-obj');
            return;
        }


        //
        const _CPCalculator_id_array =[];
        $(_table).find('.CPNumber.previewon.calculator').each((_,_itm)=>{
            _CPCalculator_id_array.push($(_itm).attr(CPCalculator.getDataTarget(CPCalculator.CP_STYLE)));
        });  
        


        //
        $(_table).find('.CPCalculator.previewon').each((_,_cp)=>{

            let removeIdx =[];
            $(_CPCalculator_id_array).each((_idx,_cpid)=>{
                if(_cpid == $(_cp).attr('data-id')) removeIdx.push(_idx);                
            });

            //remove
            $(removeIdx.reverse()).each((_,no)=>{
                _CPCalculator_id_array.splice(no, 1);
            });

        });


        //
        $(_CPCalculator_id_array).each((_,_cpid)=>{

            $(_table).find('.CPNumber.previewon.calculator').each((_,_itm)=>{

                if( $(_itm).attr(CPCalculator.getDataTarget(CPCalculator.CP_STYLE)) == _cpid ){    

                    const _changeWrap = $(_itm).closest(`.changeWrap`);

                    const _style_col = $(_changeWrap).find(".CPNumber.previewon").attr(`data-col-target`);
                    const _style_row = $(_changeWrap).find(".CPNumber.previewon").attr(`data-row-target`);   

                    //check flush able(4/4)
                    if(_style_row == undefined && _style_col == undefined){
                        //_changeWrap.addClass("444");
                        _changeWrap.removeClass(CPCalculator.onOffClass);
                        _changeWrap.find(".previewon").removeClass(CPCalculator.onOffClass);
                        _changeWrap.find(".previewoff").removeClass(CPCalculator.onOffClass);
                    }
                    
                    _changeWrap.removeClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);                    
                    _changeWrap.find(".previewon").removeClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);
                    _changeWrap.find(".previewon").removeAttr(CPCalculator.getDataTarget(CPCalculator.CP_STYLE));                    
                    _changeWrap.find(".previewoff").removeClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);

                }
            });  

        });



    }

    ,
    useableItemLists(){      
        

        //
        const _table = $(`#${this.CP_ID}`).closest(`table`);
        const _tr = $(`#${this.CP_ID}`).closest(`tr`);

        CPCalculator.CP_UseableItemLists = new Object();

        let  _html = '';

        //
        function innertFunction(td){


            //연산 관련 항목은 새로고침 대상에서 제외.
            if( $(td).find(`.${CPCalculator.CP_TYPE}`).length > 0 ) return;
            if( $(td).find(`.CPCalculatortotal`).length > 0 ) return;
            if( $(td).find(`.CPCalculatorglobaltotal`).length > 0 ) return;



            const _itemID = $(td).find(".itemID").attr("data-id");
            const _numberItemID = $(td).find(".CPNumber.previewon").attr("data-id");
            const _style_col = $(td).find(".CPNumber.previewon").attr(`data-col-target`);
            const _style_row = $(td).find(".CPNumber.previewon").attr(`data-row-target`);



            //check flush able(3/4)
            let flush = true;
            if( (CPCalculator.CP_STYLE == 'col' && _style_row != undefined && CPCalculator.CP_ID != _style_col) ||
                (CPCalculator.CP_STYLE == 'row' && _style_col != undefined && CPCalculator.CP_ID != _style_row)
            ){
                flush = false;
            }

           
            
            //flush
            if( flush ){
                //console.log("999",CPCalculator.CP_STYLE , _style_row , _style_col , td );
                //$(td).find(".changeWrap").addClass("999");
                $(td).find(".changeWrap").removeClass(CPCalculator.onOffClass);
                $(td).find(".changeWrap").removeClass(CPCalculator.onOffClass + CPCalculator.CP_STYLE);
            }
           
    
            /*
                sample
                input pv_CPNumber_4802
            */
            if( _numberItemID != undefined ){    
                CPCalculator.CP_UseableItemLists[_itemID] = _numberItemID;      
                _html += `<span data-id='${_numberItemID}' data-style='${_itemID}'>${_itemID}</span>`;    
            }

        }


        //
        if( CPCalculator.CP_STYLE == 'col'){

            let _tdIDX = null;
            const _td = $(`#${this.CP_ID}`).closest(`td`);            
            _table.find('tr').each(function(_,tr){            	
                if( tr == _tr[0] ){   
                	let countIdx = 0;
                    $(tr).find('td').each(function(idx,td){
                    	countIdx += td.colSpan;
                        if( td == _td[0] ){
                            _tdIDX = countIdx;                            
                            return false;
                        }
                    });
                    return false;
                }
            });
            


            if( _tdIDX != null ){

                _table.find('tr').each(function(_,tr){

                	let countIdx = 0;
                    $(tr).find('td').each(function(idx,td){  
                    	countIdx += td.colSpan;
                        if( countIdx != _tdIDX ) return true;
                        innertFunction(td); 
                    });

                });
                
            }
            

        }else{

            _table.find('tr').each(function(_,tr){
                if( tr == _tr[0] ){         
                    
                    $(tr).find('td').each(function(_,td){
                        innertFunction(td); 
                    });

                    return false;                
                }
            });

        }


        //show        
        if(_html == ''){
            _html = CPCalculator.msg.alert001;
            $('#cp_calculator').attr("disabled",true);   
            $("#useableCalListsWrap").css("display","none");      
        }else{
            $('#cp_calculator').attr("disabled",false);
            $("#useableCalListsWrap").css("display","block");     
        }

        $("#useableItemListsWrap").html(_html);

    }
    ,
    addCompo(prop){

        //check in table
        if(  $('.tableSelectOn').length == 0 ){
            CPCalculator.alert("not-in-table");
            return;
        }


        //
        if(CPCalculator.CP_STYLE == "row" && (CPTable.countCpCalculatorRow(CPCalculator.CP_STYLE) != 0)){
            CPCalculator.alert("onlyone");
            //GB_PROPS.attview.html('');
            return;
        }

        //
        if(CPCalculator.CP_STYLE == "col" && CPTable.countCpCalculatorCol(CPCalculator.CP_STYLE) != 0){
            CPCalculator.alert("onlyone-col");
            //GB_PROPS.attview.html('');
            return;
        }

        //test
        //if(CPTable.isMerged() != 'isNoMerged'){
        if(CPTable.isMerged() != 'isNoMerged' && CPCalculator.CP_STYLE == "row"){
        	CPCalculator.alert("isMerged");
            return;
        }
        


        let template = CPCalculator.getCpHtml(prop);
        let $attrview = CPCalculator.getAttrView(prop)

        
        
        CPElemParent.addComp({
            cptype: CPCalculator.CP_TYPE
            ,cpid: CPCalculator.CP_ID
            ,template: template
            ,vwtemplate: $attrview
        });

        //flush data
        setTimeout(function(){     	
            //CPCalculator.checkMultirow(CPCalculator.CP_ID);
            CPCalculator.useableItemLists();  
            CPCalculator.checkCalculatorData();
        }, 100);
        
    }
    ,
    selectComp(prop){


        //flush
        $(`#${prop.cpid}`).removeClass('twinkle');

        //flush
        CPCalculator.setCPSTYLE($("#"+prop.cpid).attr("data-style"));

        //
        const attr = $(`#${prop.cpid}`).attr('data_attr');
        let attrJson = CPElemParent.parseDataAttrToJson(attr);
  

        let template = this.getCpHtml(prop);        
        let $attrview = CPCalculator.getAttrView(prop);

        CPCalculator.CP_ID = prop.cpid;
        
        
        CPElemParent.selectComp({
            cptype: CPCalculator.CP_TYPE
            ,cpid: prop.cpid
            ,template: template
            ,vwtemplate: $attrview
            ,data_attr: prop.data_attr
        });


        //flush data
        setTimeout(function(){     	
            //CPCalculator.checkMultirow(prop.cpid);
            CPCalculator.useableItemLists();  
            CPCalculator.checkCalculatorData();
        }, 100);


        //kendo
        if(attrJson['cp_multirow']=='on')
            $("#cp_multirow").parent('label').removeClass('off');        

        
    }
    ,
    getCpHtml(prop){

        let cpid = null;

        if(prop && prop.cpid){
            cpid = prop.cpid;
        }else{
            cpid = this.createCpid();
        }
        
        this.CP_ID = cpid;
        
        return  `
        <div class="${this.CP_TYPE} previewoff tblformbdCon" id="${cpid}" data-style="${this.CP_STYLE}"><span>${CPCalculator.getTitle()}</span> <button type="button" class="k-button dltBtn groupTrash"></button></div>
        <div class='${this.CP_TYPE} previewon splitWrap' data-id="${cpid}" data-style="${this.CP_STYLE}"> 
            <div class="splitBlock">  

                <input type="hidden" id="pv_${cpid}data" value="">            
            
                <span class="pv_table_id"></span>

                <!-- 스크립트 입력 -->
                <div class="calculatorWrap"> 
                    <div id="calSumWrap"><span id="pv_${cpid}calSum" class="calSum"><b>= </b>0</span></div>                    
                    <div id="pv_${cpid}calFrom" class="calFrom"></div>
                </div>
                <span id="${cpid}alertmsg" class="alertmsg"></span>

            </div>
            <div id="${cpid}popBtnArea" class="popBtnArea dn">
                <button class="btn_cpcalculator_add">+</button>
            </div>
        </div>
        `;

    }
    ,
    createCpid(){

        return CPCalculator.CP_TYPE + '_' + Math.floor(Math.random() * 10000);

    }    
}