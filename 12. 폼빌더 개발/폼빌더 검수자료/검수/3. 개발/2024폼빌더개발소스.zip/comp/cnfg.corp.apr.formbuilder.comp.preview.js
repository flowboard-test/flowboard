//
let CPPreview = {

    EDITORID : "editorDataArea"
    ,
    roof : [".here",".pv_table_id",".formbdItem",".changeWrap",".formbdoverArea",".sortAbleItem",".tbl_formbd"]
    ,
    delItemClass : ["pv_table_id","moveIcon","previewoff","itemID"]
    ,
    delItemID : []
    ,
    delClass : ["here","previewon","dn","tbl_formItem**","tbl_formbd**"]
    ,
    delID : []
    ,
    replaceOuterClass : ["sortAbleItem","formbdoverArea","changeWrap","formbdItem"]
    ,
    replaceOuterID : []
    ,
    copy : null  

    ,    

    mix(useHtml = false ,html = ''){
    	
    	if( useHtml ){  
    		
    		if(html == '') return "";
    		
    		const _new = document.createElement("div");
    		_new.innerHTML=html;
    		
    		this.copy = _new;
    		
    	}else{
    		
    		this.copy = document.getElementById(this.EDITORID).cloneNode(true);
    		
    	}

        

        this.roof.forEach((_wrap)=>{

            this.copy.querySelectorAll(_wrap).forEach((itm)=>{            

                if( itm.tagName == 'TABLE' ){

                    this.removeAttribute(itm);

                    itm.querySelectorAll('tr').forEach((tr , _idx)=>{
                        ['th','td'].forEach((_tar)=>{
                            tr.querySelectorAll(_tar).forEach((th)=>{

                                this.removeItem(th);    
                                this.removeAttribute(th);                                

                                const children = th.childNodes;
                                for (let i = 0; i < children.length; i++) {

                                    this.removeItem(children[i]);  
                                    this.removeAttribute(children[i]);
                                    //this.replaceOuter(children[i]);
                                }

                            });
                        });
                    });
    
                }else{
    
                    this.removeItem(itm);    
                    this.removeAttribute(itm);

                    const children = itm.childNodes;
                    for (let i = 0; i < children.length; i++) {
                        this.removeItem(children[i]);  
                        this.removeAttribute(children[i]);

                        this.replaceOuter(children[i]);
                    }                   
    
                }

                this.replaceOuter(itm);    
    
            });

        });        

        return this.copy.innerHTML;

    }
    ,
    removeItem(itm){

        console.log( "removeItem" , itm  );

        if( itm == undefined ) return;

        const itmClassList = itm.classList;

        if( itmClassList == undefined ) return;

        //remove class
        this.delItemClass.some((_cls)=>{   
            if(itmClassList.contains(_cls)){
                itm.remove(); 
                return true;
            }  
        });


        //remove id
        const itmID = itm.id;

        if( itmID == undefined ) return;

        this.delItemID.some((_cid)=>{
            if( itmID == _cid ){
                itm.remove(); 
                return true;
            }                          
        });

    }

    ,removeAttribute(itm){

        if( itm == undefined ) return;

        const itmClassList = itm.classList;

        if( itmClassList == undefined ) return;


        //remove class
        let remove = [];
        this.delClass.forEach((_cls)=>{

            if( _cls.includes("**") ){

                itmClassList.forEach((__cls)=>{
                    if(__cls.includes(_cls.replace("**","")) )
                        remove.push(__cls);
                });

            }else if(itmClassList.contains(_cls))
                remove.push(_cls); 

        });

        //remove
        remove.forEach((cls)=>{
            itmClassList.remove(cls);            
        });





        //remove id
        const itmID = itm.id;

        if( itmID == undefined ) return;

        this.delID.forEach((_cid)=>{
            if( itmID == _cid )
                itm.id = '';                           
        });

    }

    ,
    replaceOuter(itm){

        const itmClassList = itm.classList;

        if( itmClassList == undefined ) return;

        this.replaceOuterClass.forEach((_cls)=>{
            if(itmClassList.contains(_cls)){
                itm.outerHTML = itm.innerHTML;
            }                        
        });


        const itmID = itm.id;

        if( itmID == undefined ) return;
        this.replaceOuterID.forEach((_cid)=>{
            if( itmID == _cid )
                itm.outerHTML = itm.innerHTML;                        
        });

    }
}