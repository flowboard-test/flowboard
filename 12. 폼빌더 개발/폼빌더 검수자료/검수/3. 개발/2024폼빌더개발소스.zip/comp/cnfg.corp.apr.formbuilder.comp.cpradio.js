/**
 * 폼빌더 컴포넌트.
 * 
 * 타이틀 컴포넌트
 * 
*/

let CPRadio = {

    CP_ID: null
    ,
    CP_TYPE: 'CPRadio'
    ,
    CP_ITEM_TITLE : '라디오'
    	
    ,
    
    MAX_LEN : 10
    
    ,
    getAttrView(prop) {

        let vwid = "att_tle";
        let template = `<div class="formbdTitle"><span>라디오 속성</span></div>
                        <ul class="formbdMenu">
                            <li>
                                <p class="formbdMenuTit">입력 항목</p>
                                <div class="formbdMenuCon">
                                    <ul class="radioAddList">
                                    </ul>                                    
                                </div>
                            </li>
                        </ul>`;

        let $templ = $(template);

        return $templ;
    }
    ,
    addCompo(prop) {
        let cpid = this.CP_ID = this.createCpid();
        let cptitle = this.CP_ITEM_TITLE;
        
        let template = `
            <div class="${this.CP_TYPE} previewoff tblformbdCon" id="${cpid}"><span>${cptitle}</span> <button type="button" class="k-button dltBtn groupTrash"></button></div>
            <div class='${this.CP_TYPE} previewon splitWrap' data-id="${cpid}"> 
                <div class="splitBlock" id="pvdiv_${cpid}">          

                    <!-- preview area -->
                    


                </div>
            </div>
            `;
        	

        CPElemParent.addComp({
            cptype: CPRadio.CP_TYPE
            , cpid: this.CP_ID
            , template: template
            , vwtemplate: CPRadio.getAttrView()
            , cp_attr_set_fn: CPRadio.setAttItemHtml
        });

    }
    ,
    selectComp(prop) {

        this.CP_ID = prop.cpid;

        CPElemParent.selectComp({
            cptype: CPRadio.CP_TYPE
            , cpid: this.CP_ID
            , vwtemplate: CPRadio.getAttrView()
            , cp_attr_set_fn: CPRadio.setAttItemHtml
            , data_attr: prop.data_attr
        });
        

    }
    ,
    addBtnEvt(prop) {

        let nidx = Math.floor(Math.random() * 1000);

        //attr 속성 텍스트 추가.
        htm = CPRadio.createAttrLi({
            idx: nidx
            , val: prop.val
            , name: prop.name
            , placehold: prop.placehold
        });
        
        //빌더폼 텍스트 컴포 추가.
        htm2 = CPRadio.createCpitemRadio({
            idx: nidx
            , val: prop.val
            , name: prop.name
            , placehold: prop.placehold
        })
            ;

        
        $(document).on('keyup', '#cp_txradio' + nidx, function(e){

            let cpid = $(e.target).attr('cpid');
            let idx = $(e.target).attr('idx');
            
            $("#pv_" + cpid + "_" + idx).find('span').text($(e.target).val());

            CPElemParent.applyAttrToElem(e);

        });
        
        GB_PROPS.attview.find('ul.radioAddList').append($(htm));
        $('#pvdiv_' + GB_CUR_STATE.CP_ID).append(htm2);
        

    }
    ,
    fnAddExec(e){
    	this.addBtnEvt({ 
            name: CPRadio.CP_ITEM_TITLE
            ,placehold: '입력'
            ,val: '입력'
        });

        
        CPElemParent.changeAttrViewHandler(e);
    }
    ,
    fnDelExec(picidx){
    	this.delBtnEvt(picidx);

        CPElemParent.applyAttrToElem();
    }
    ,
    delBtnEvt(idx) {

        $(document).off('click', '#dltBtn' + idx);
        $(document).off('click', '#addBtn' + idx);
        $(document).off('keyup', '#cp_txradio' + idx );

        $('#cp_txradio' + idx).parent('div').parent('li').remove();
        $("#pv_" + GB_CUR_STATE.CP_ID + "_" + idx).remove();

        CPCommon.console.log('delBtnEvt!!!!!!!!!!!!!', idx);
    }

    ,
    setAttItemHtml(data_attr) {

        let htm = '';
        let itemCnt = 0;
        
    	$('#pvdiv_' + GB_CUR_STATE.CP_ID).html('');

        if (data_attr && data_attr.length > 0) {

            let attrJson = CPElemParent.parseDataAttrToJson(data_attr);
            let keys = Object.keys(attrJson); //키를 가져옵니다. 이때, keys 는 반복가능한 객체가 됩니다.

            itemCnt = keys.length;


            $(keys).each((idx, key) => {

                if(key != '') {

                    CPRadio.delBtnEvt(idx);

                    CPRadio.addBtnEvt({
                        name: attrJson[key]
                        ,placehold: '입력'
                        ,val: attrJson[key]
                    });

                }

            });

        }
        else{
 
            //라디오 신규 추가시 기본옵션 하나 생성.
            //또는 신규 추가후 신규상태 그대로 일 경우.

            CPRadio.addBtnEvt({
                name: CPRadio.CP_ITEM_TITLE
                ,placehold: '입력'
                ,val: '입력'
            });
        }
        
    }
    ,
    createAttrLi(prop) {

        return `<li>
                    <div class="radioAdd">
                        <input id="cp_txradio${prop.idx}" idx="${prop.idx}" cpid="${this.CP_ID}"  name="" style="width:100%;" class="k-textbox" type="text" maxlength="${CPRadio.MAX_LEN}" value="${prop.val}" placeholder="${prop.placehold}">
                        <button type="button" id="dltBtn${prop.idx}" cpid="${this.CP_ID}" idx="${prop.idx}" class="k-button dltBtn" onclick="CPRadio.fnDelExec(${prop.idx})"></button>
                    </div>
                    <button type="button" id="addBtn${prop.idx}"  idx="${prop.idx}" class="k-button addBtn" onclick="CPRadio.fnAddExec(event)"></button>
                </li>`
    }
    ,
    createCpitemRadio(prop) {
        
    	 return `
         <label id="pv_${GB_CUR_STATE.CP_ID}_${prop.idx}" >
             <input  type="radio" id="pv_rdo_${GB_CUR_STATE.CP_ID}_${prop.idx}" name="pv_rdo_${GB_CUR_STATE.CP_ID}" />
             <span>${prop.val}</span>
         </label>`;     
       /* return `
                <label id="pv_${GB_CUR_STATE.CP_ID}_${prop.idx}" for="pv_rdo_${GB_CUR_STATE.CP_ID}_${prop.idx}">
                    <input  type="radio" id="pv_rdo_${GB_CUR_STATE.CP_ID}_${prop.idx}" name="pv_rdo_${GB_CUR_STATE.CP_ID}" />
                    <span>${prop.name}</span>
                </label>`;     */
        
    }    
    ,
    createCpid(){

        return CPRadio.CP_TYPE + "_" + Math.floor(Math.random() * 10000);

    }

}
