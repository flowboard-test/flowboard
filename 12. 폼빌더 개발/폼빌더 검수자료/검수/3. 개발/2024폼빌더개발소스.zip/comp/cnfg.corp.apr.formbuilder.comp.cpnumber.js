/**
 * 폼빌더 컴포넌트.
 * 
 * 타이틀 컴포넌트
 * 
*/
let CPNumber = {

    CP_ID : null
    ,
    CP_TYPE : "CPNumber"
    ,
    CP_ITEM_TITLE : "숫자"
    ,
    
    MAX_INPUT : 20 
    	
    ,
    getAttrView(prop){

        let vwid = "att_tle";
        let template = `<div id="div_${vwid}" class="formbdTitle"><span>숫자 속성</span></div>
                        <ul id="ul_${vwid}" class="formbdMenu">
                            <li>
                                <p class="formbdMenuTit">필수입력</p>
                                <div class="formbdMenuCon">
                                    <div class="btnWrap">
                                        <label  for="toggle" class="toggleSwitchBtn off">
                                            <span id="cp_rdrequired" class="togglebtn"></span>
                                        </label>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <p class="formbdMenuTit disInline vM">입력 가능 최대 글자 수</p>
                                <span class="formbdicon_Question vM mB10"><p class="formbd_notes_wrap"></p></span>
                                <div class="formbdMenuCon">
                                    <input id="cp_txmaxlength" name="cp_txmaxlength" style="width:100%;" class="k-textbox" type="number" value="${CPNumber.MAX_INPUT}">
                                    
                                </div>
                            </li>
                            
                            
                            <li>
                                <p class="formbdMenuTit">입력 너비</p>
                                <div class="formbdMenuCon">
                                    <div class="dropdownArea">
                                        <span  title="" class="k-widget k-dropdown k-header formbd_drop" unselectable="on" role="listbox" aria-haspopup="true" aria-expanded="false" tabindex="1" aria-owns="" aria-disabled="false" aria-busy="false" aria-activedescendant="b9638adf-c13e-4791-9aa7-7e060777ee7b" style="width: 60px;"><span unselectable="on" class="k-dropdown-wrap k-state-default">
                                        <span unselectable="on" class="k-input">%</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span></span>
                                        <input id="cp_txwidthUnit" style="width: 60px; display: none;" class="formbd_drop" name="formbd_drop" type="text" value="" data-role="dropdownlist"></span>
                                    </div>
                                    <input id="cp_txwidth" maxlength="3" name="" style="width:150px;" class="k-textbox mL5" type="number" value="100" >
                                    
                                </div>
                            </li>
                            <!--li>
                                <p class="formbdMenuTit">연산식 입력</p>
                                <div class="formbdMenuCon">
                                    <input id="cp_txcalc" name="" style="width:100%;" class="k-textbox" type="text"  value="" placeholder="">
                                </div>
                            </li-->
                            <li>
                                <p class="formbdMenuTit">안내문구 (placeholder)</p>
                                <div class="formbdMenuCon">
                                    <input id="cp_txplacehold" name="" style="width:100%;" class="k-textbox" type="text"  value="" placeholder="" disabled>
                                </div>
                            </li>
                            
                        </ul>`;

        let $templ = $(template);
        
        $templ.find('#cp_txmaxlength').on('input',function (e) {
        	
        	CPView.pvTypeMaxSizeCheckAndAlert(this, CPNumber.MAX_INPUT);

            
        });
        //이벤트 연결
        /*
        let fntradio = $templ.find('#cp_rdrequired');

        fntradio.on('click',function (e) {
            if($(e.target).parent('label').hasClass('off')){
                $(this).parent('label').removeClass('off');

                $('#cp_txplacehold').attr('placeholder','필수값 입니다.');
                $(this).attr('value','');
            }
            else{
                $(this).parent('label').addClass('off');

                $('#cp_txplacehold').attr('placeholder','');
                $(this).attr('value','off');
            }

            CPElemParent.changeAttrViewHandler(e);
        });
        
        $templ.find('#cp_txwidth').on('keyup',function (e) {
            
            CPElemParent.changeAttrViewHandler(e);
        });

        var data = [
            { text: "%", value: "%" },
            { text: "px", value: "px" },
            //{ text: "em", value: "2" },
        ];
        $templ.find("#cp_txwidthUnit").kendoDropDownList({
            dataTextField: "text",
            dataValueField: "value",
            dataSource: data,
            index: 0
        });
    	*/
        return $templ;                
    }
    ,
    addCompo(prop){

        let template = this.getCpHtml(prop);
        
        let $attrview = CPNumber.getAttrView()
        let fntselect = $attrview.find('#cp_cbfont-family');                    

        CPElemParent.addComp({
            cptype: CPNumber.CP_TYPE
            ,cpid: this.CP_ID
            ,template: template
            ,vwtemplate: $attrview
        });                    
        
    }
    ,
    selectComp(prop){

        let $attrview = CPNumber.getAttrView()

        CPElemParent.selectComp({
            cptype: CPNumber.CP_TYPE
            ,cpid: prop.cpid
            ,vwtemplate: $attrview
            ,data_attr: prop.data_attr
        });                   
        
    }
    ,
    getCpHtml(prop){

        let cpid = null;

        if(prop && prop.cpid){
            cpid = prop.cpid;
        }else{
            cpid = this.createCpid();
        }
        
        this.CP_ID = cpid;
        
        return  `
        <div class="${this.CP_TYPE} previewoff tblformbdCon" id="${cpid}"><span>${CPNumber.CP_ITEM_TITLE}</span> <button type="button" class="k-button dltBtn groupTrash"></button></div>
        <div class='${this.CP_TYPE} previewon splitWrap' data-id="${cpid}"> 
            <div class="splitBlock">          

                <!-- 스크립트 입력 -->
                <input id="pv_${cpid}"  name="숫자" class="formbdMenuCon" class="fb-view-tx-df" type="number"  value="" maxlength="${CPNumber.MAX_INPUT}" placeholder="" />

            </div>
        </div>

        `;

    }
    ,
    createCpid(){

        return CPNumber.CP_TYPE + '_' + Math.floor(Math.random() * 10000);

    }
    
}
