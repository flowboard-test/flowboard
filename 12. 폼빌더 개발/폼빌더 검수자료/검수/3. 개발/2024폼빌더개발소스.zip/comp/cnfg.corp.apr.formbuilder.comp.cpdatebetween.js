/**
 * 폼빌더 컴포넌트.
 * 
 * 타이틀 컴포넌트
 * 
*/

let CPDateBetween = {

    CP_ID: null
    ,
    CP_TYPE: 'CPDateBetween'
    ,
    CP_ITEM_TITLE : '기간'
    ,
    getAttrView(prop) {

        let vwid = "att_tle";
        let template = '';

        let $templ = $(template);

        return $templ;
    }
    ,
    addCompo(prop) {
    	
    	 let cpid = this.CP_ID = this.createCpid();
         let cptitle = this.CP_ITEM_TITLE;
         
         let template = `
             <div class="${this.CP_TYPE} previewoff tblformbdCon" id="${cpid}"><span>${cptitle}</span> <button type="button" class="k-button dltBtn groupTrash"></button></div>
             <div class='${this.CP_TYPE} previewon splitWrap' data-id="${cpid}"> 
                 <div class="splitBlock" id="pvdiv_${cpid}">          

                     <!-- preview area -->
                     
        	 		<input id="${cpid}_sDate" class="pview-kendo-date"  type="text" id="pv_${this.CP_ID}" />
        	 		<span class="iconfrom">~</span>
        	 		<input id="${cpid}_eDate" class="pview-kendo-date"  type="text" id="pv_${this.CP_ID}" />

                 </div>
             </div>
             `;
         
        CPElemParent.addComp({
            cptype: CPDateBetween.CP_TYPE
            , cpid: this.CP_ID
            , template: template
            , vwtemplate: CPDateBetween.getAttrView()
        });



    }
    ,
    selectComp(prop) {

        this.CP_ID = prop.cpid;

        CPElemParent.selectComp({
            cptype: CPDateBetween.CP_TYPE
            , cpid: this.CP_ID
            , vwtemplate: CPDateBetween.getAttrView()
            , cp_attr_set_fn: CPDateBetween.setAttItemHtml
            , data_attr: prop.data_attr
        });

    }
    ,
    addPreviewCpitem(prop) {
    
        return `<input type="text" class="kendo-date" id="pv_${this.CP_ID}" />`;     
        
    }    
    ,
    createCpid(){

        return CPDateBetween.CP_TYPE + "_" + Math.floor(Math.random() * 10000);

    }

}
