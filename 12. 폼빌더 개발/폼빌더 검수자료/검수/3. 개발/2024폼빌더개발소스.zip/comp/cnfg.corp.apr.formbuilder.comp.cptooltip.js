//
let CPToolTip = {

    msg : {
        "noToolTipData" : "{{title}} 속성을 설정해 주세요.",
    }

    ,

    showPopToolTip(){

        const CP_TargetObj = $(`#${GB_CUR_STATE.CP_ID}`);

        if(CP_TargetObj.length == 0 ) return;      

        const tooltip = CP_TargetObj.find(".formbdtooltip");

        if(tooltip.length == 0 ) return;

        const attr = CP_TargetObj.attr('data_attr');        
        let attrJson = CPElemParent.parseDataAttrToJson(attr);
        let tooltipBack = tooltip.attr('data-msg');
        let tooltipMsg = "";

        $( Object.keys(attrJson) ).each((_,atr)=>{
           
            if(  atr.substring(0, 3) == "cp_"){
                
                if(tooltipMsg == "") tooltipMsg = tooltipBack;

                if( $(`#${atr}`).attr('type') == "checkbox" ){
                    tooltipMsg = tooltipMsg.replaceAll(atr,($(`#${atr}`).is(":checked")?$(`label[for='${atr}']`).text():""));
                }else{
                    tooltipMsg = tooltipMsg.replaceAll(atr, (attrJson[atr] =="undefined"||attrJson[atr]==""?"기본값":attrJson[atr]));
                }
                
            }   
        });


        if(tooltipMsg =="") $(tooltip).html(CPToolTip.msg.noToolTipData);
        else                $(tooltip).html(tooltipMsg);

    }

    ,
    setToolTipLayout(prop){

        const title = eval(`${prop.cptype}.CP_ITEM_TITLE`);

        //tooltip(1/2)
        let attr = [];
        let msg = [];
        $(prop.vwtemplate).find("li").each((_,_li)=>{     
             
            const _ids = $(_li).find("input[id],select[id]"); 
            const _title = $(_li).find(".formbdMenuTit").text();
            let _id_txt = "";
            _ids.each((_,itm)=>{   
                if( itm.id.substring(0, 3) == "cp_" ){
                    attr.push(itm.id);
                    _id_txt += itm.id + " "; 
                }
            });
 
            if( _id_txt != "" ) msg.push( `${_title} : ${_id_txt}`); 
        });

         
        const formObj = new DOMParser().parseFromString(prop.template, 'text/html');
        const _previewoff = $(formObj).find(".previewoff");
        if( _previewoff.length > 0 &&  $(_previewoff).find(".formbdtooltip").length == 0 ){
            $(_previewoff).append(`<div class="formbdtooltip ${msg.length == 0?"dn":""}" data-msg="${msg.join("/ ")}">${CPToolTip.msg.noToolTipData.replace("{{title}}",title)}</div>`);
            prop.template = formObj.body.innerHTML;   
        }

    }


}