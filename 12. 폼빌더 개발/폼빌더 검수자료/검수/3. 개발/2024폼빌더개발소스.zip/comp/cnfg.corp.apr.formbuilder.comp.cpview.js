/**
 *
 * 
 */

var CPView = {

    GB_DOC_INFO: {
        formTitle: '',
        apprDocSeq: 0,
        formBuilderSeq: 0
    },

    url: {
        //결제선 데이터 
        apprlist: "/cnfg/apr/formbuilder/apprlist/{{apprId}}.json"
        ,
        //doc결제선 데이터 
        apprdoclist: "/cnfg/apr/formbuilder/apprDoclist/{{apprId}}.json"
        ,
        //매크로 데이터
        macrolist: "/cnfg/apr/formbuilder/previewEditMacroTagChange.json"
    }
    ,

    macro: {
       "pv_CT_DRFT_USR_NM": { txt: "기안자", code:"$CT_DRFT_USR_NM$"} ,
       "pv_CT_DRFT_USR_DEPT": { txt: "기안부서", code:"$CT_DRFT_USR_DEPT$"},
       "pv_CT_DRFT_USR_EMAIL": { txt: "기안자이메일", code:"$CT_DRFT_USR_EMAIL$"},
       "pv_CT_DRFT_USR_POS": { txt: "직위", code:"$CT_DRFT_USR_POS$"},
       "pv_CT_DRFT_USR_EMPY_NO": { txt: "사번", code:"$CT_DRFT_USR_EMPY_NO$"},
       "pv_CT_DRFT_USR_HP_NO":  { txt: "휴대폰번호", code:"$CT_DRFT_USR_HP_NO$"},
       "pv_CT_CORP_TEL_NO": { txt: "회사대표번호", code:"$CT_CORP_TEL_NO$"} ,
       "pv_CT_DRFT_DATE": { txt: "기안일", code:"$CT_DRFT_DATE$"} ,
       "pv_CT_DRFT_CORP_TEL_NO":  { txt: "기안자직통번호", code:"$CT_DRFT_CORP_TEL_NO$"},
       "pv_CT_CORP_FAX_NO":  { txt: "회사팩스번호", code:"$CT_CORP_FAX_NO$"},
       "pv_CT_CORP_LOGO": { txt: "회사로고", code:"$CT_CORP_LOGO$"},
       "pv_AP_KEEP_YY":  { txt: "보존연한", code:"$AP_KEEP_YY$ $AP_KEEP_MM$"},
       "pv_AP_IMPO_CD": { txt: "중요도", code:"$AP_IMPO_CD$"},
       "pv_AP_SEC_APPR_YN": { txt: "보안등급", code:"$AP_SEC_APPR_YN$"},
       "pv_AP_OPEN_CD_LOCALE_NAME": { txt: "공개여부", code:"$AP_OPEN_CD_LOCALE_NAME$"},
 
    }
    
    

    ,

    //사용자,부서 관련 팝업 ID

    _curOrgPopId: null

    ,

    rootObj: null

    ,

    targetHtml: null

    ,
    
    namoEditorSetBodyValueloadDelay: 1000
    ,

    formloadDelay: 500
    ,

    formTarget: null

    ,

    editorSlot: {}

    ,
    
    previewCopyArea : null
    ,

    /*
     * editview : 순수 에디트된 결과물
     * editviewbasic : namo에디터 같은 추가되는 스크립트를 text로 치환 된 결과물
     * view : 일부 태그(input, textarea, namo에디터 )가 text로 치환 된 결과물
     */
    viewType: 'editView' //editview | editviewbasic | view

    ,

    isDoc: false

    ,
    init(setting) {

        //form 다중 에디터 객체 관리.
        editorSlot = {};

        if (setting.target === null || typeof (setting.target) !== 'object') {
            alert('CPView - 타겟이 연결되지 않았습니다.');
            return;
        }



        /**
         * 
         */
        this.rootObj = setting.target;


        /**
         * 
         */
        if (setting.html)
            this.targetHtml = setting.html;


        /**
         * 
         */
        if (setting.type)
            this.viewType = setting.type;

        /**
         * isDoc = true 기안에서 사용
         * isDoc = false 관리자 폼빌더 작성
         */
        if (setting.isDoc)
            this.isDoc = setting.isDoc;

        if (setting.formTarget)
            this.formTarget = setting.formTarget;
        
        
        if (setting.namoEditorSetBodyValueloadDelay)
            this.namoEditorSetBodyValueloadDelay = setting.namoEditorSetBodyValueloadDelay;

        if (setting.formloadDelay)
            this.formloadDelay = setting.formloadDelay;
        if (setting.apprDocSeq)
            this.GB_DOC_INFO.apprDocSeq = setting.apprDocSeq;
        
        if (setting.previewCopyArea){
        	
        	this.previewCopyArea = setting.previewCopyArea;
        }
        else{
        	
        	this.previewCopyArea = $('#editorArea');
        }
        
        this.docStatus = setting.docStatus;

        this.load();         
       
        this.listener(); 

        this.rootObj.show();
        
    }
    ,
    load() {

        if (this.targetHtml == null) return;
        	
    	this.rootObj.html(this.targetHtml);
    	
        //load html data
        if (this.targetHtml != null)
            this.rootObj.html(this.targetHtml);
        
        this.rootObj.find("form").each(function (){
			$(this)
			.remove();
			
		});
    	this.rootObj.find("input.pview-kendo-date").each(function (){
			$(this)
			.attr('style', '');
			
		});	
        
        //doc complete
        if (this.docStatus == "9") {

            CPView.GB_DOC_INFO.apprDocSeq = CPView.GB_DOC_INFO.apprDocSeq != undefined ? CPView.GB_DOC_INFO.apprDocSeq : 0;

            if (CPView.GB_DOC_INFO.apprDocSeq != 0) {
                CPView.getAprDoc(
                    0,
                    CPView.GB_DOC_INFO.apprDocSeq)
                    .then(function (data) {

                        CPView.setDocInfoComp(data);

                    });
            }
            
        	//return;
        }

        if (this.viewType == 'view') {
            //this.appendPrintButton();
        }

        // 날짜 컴포넌트 미리보기 실행함수
        this.rootObj.find('input.pview-kendo-date').each((_, itm) => {
            $(itm).kendoDatePicker({
                format: 'yyyy-MM-dd',
                value: abcDtime.getTodayClient()
            });
        });

        //load 결재선, 멀티컴포넌트,  합의 결재선, 수신 결재선
        this.loadGroupA();

        /**
         * 
         * 사용자 기안, 수정 시 입력컨트롤 초기화.
         * 
         * */
        if (this.viewType == 'editview') {
            //load 사용자 추가

            this.initOragnizeUserTree(this.rootObj.parent());

            //load 부서추가
            this.initOragnizeDeptTree(this.rootObj.parent());

            //load webeditor
            
            this.rootObj.find(".CPWebeditor").each((_, itm) => {
                let id = $(itm).attr('data-id');
                this.creatNamoEditor({ $target: $(itm), editorIframeName: `namo_${id}`, iframeHeight: 400 });
            });

            //load multi-webeditor
            this.rootObj.find(".CPMultiWebeditor").each((_, itm) => {
                let id = $(itm).attr('data-id');
                this.creatNamoEditor({ $target: $(itm), editorIframeName: `namo_${id}`, iframeHeight: 400 });
            });

            this.rootObj.find("#pv_CT_CORP_LOGO img").each((_, itm) => {
                $(itm).css({ "width": "130px", "height": "30px" });
            });
            
            
            /***
             * 사용자 입력 길이 제한 처리.
             * 
             * */
            
            this.rootObj.find("[id^=pv_CPInput]").each((_, itm) => {
                $(itm).attr("oninput", "CPView.pvTypeMaxLengthCheck(this, 'text', 20)");
            });
            this.rootObj.find("[id^=pv_CPTextArea]").each((_, itm) => {
                $(itm).attr("oninput", "CPView.pvTypeMaxLengthCheck(this, 'text', 150)");
            });
            this.rootObj.find("[id^=pv_CPCurrency]").each((_, itm) => {
                $(itm).attr("oninput", "CPView.pvTypeMaxLengthCheck(this, 'text', 20)");
            });
            
            this.rootObj.find("[id^=pv_CPNumber]").each((_, itm) => {
                $(itm).attr("oninput", "CPView.pvTypeMaxLengthCheck(this, 'number', 20)");
            });
            
        }
        
        
        //기안페이지 미리보기 처리용
        /*
        if( this.previewCopyArea && this.previewCopyArea.length > 0){
        	
        	let clonehtml = $(this.targetHtml).clone();
        	
        	setTimeout(function(){
        		
        		$('#formbuilderViewRes').remove();
        		CPView.previewCopyArea.append($('<div style="display:none" id="formbuilderViewRes"></div>'));
        		
        		clonehtml.find("input[type=radio]").each(function (){
        			$(this)
        			.attr('name', "re" + $(this).attr('name'));
        			
        		});
        		
        		$('#formbuilderViewRes').html(clonehtml);	//copy
        		
        		
        	}, 500);
        }
        */

        //임시 css file 로 이동시 제거
        if ($('#builderContArea').hasClass('horizontal')) {
            $('#builderContArea').css('width', '297mm');
        }

    }
    ,
    /**
	 * 탭이동시 에디터 재활성처리 작업중.
	 * 
	 * */
    reloadWebeditorComp(){
    	
    	//console.log('reloadWebeditorComp exec.....');
    	
    	if(this.rootObj != null){
    		
	    	this.rootObj.find("iframe").each((_, itm) => {
	            $(this).remove();
	        });
	    	
	    	this.rootObj.find(".CPWebeditor").each((_, itm) => {
	            let id = $(itm).attr('data-id');
	            this.creatNamoEditor({ $target: $(itm), editorIframeName: `namo_${id}`, iframeHeight: 400 }, true);
	        });
	
	        //load multi-webeditor
	        /*this.rootObj.find(".CPMultiWebeditor").each((_, itm) => {
	            let id = $(itm).attr('data-id');
	            this.creatNamoEditor({ $target: $(itm), editorIframeName: `namo_${id}`, iframeHeight: 400 });
	        });*/
	        
    	}
    }
    ,
    reload() {

        //console.log('CPView reload');

        //load 결재선, 멀티컴포넌트,  합의 결재선, 수신 결재선
        this.loadGroupA();

    }
    ,
    flush() {

        //console.log('CPView flush');

    }
    ,
    listener() {


        //CPCalculator 멀티로우    
        this.cpcalculatormultirow();

        this.cpcalculatorlistenItem();

        ///사용자, 부서 컴포 
        this.organViewInit();
        //양식명
        this.setPvFormTitle();

        //item 삭제요청시 
        this.rootObj.parent().on("click", ".itemdel", function (e) {
            $(e.target).parent().hide();
        });

        ////jbkim 1023 통화컴포 .CPCurrency input
        this.cpcurrencyViewInit();

        //
        if( $("#formbuilder_view").length > 0 ){

            function innertlistenerFunction(e){            	                

                //input 동적값 설정.
                if( $(e.target).prop("tagName") == "INPUT"){                	
                	
                	if( $(e.target).attr("type") == "checkbox" || 
                		$(e.target).attr("type") == "radio"
                	){
                		
                		const _name = $(e.target).attr('name');
                		
                		if ($(e.target).is(':checked')) {
                			
                			if( _name != undefined && _name != ''){
                				
                        		$(`input[name=${_name}]`).each(function(_,item){   
                        			if( e.target == item )
                            			$(item).attr('checked', 'checked');
                            		else
                            			$(item).removeAttr('checked');                    		
                            	}); 
                        		
                        	}else{
                        		
                        		$(e.target).attr('checked', 'checked');                            		
                        		
                        	}
                			
                		}else{                			
                			$(e.target).removeAttr('checked');                 			
                		}
                		
                	}else{    
                		$(e.target).attr('value', $(e.target).val());   
                	}               	             
                    
                    
                }else if( $(e.target).prop("tagName") == "TEXTAREA"){                	
                	//$(e.target).attr('value', $(e.target).val()); 
                	e.target.innerHTML = $(e.target).val();                	
                }
                                

            }

            //listen
            this.rootObj.on("keyup", "input", (e) => innertlistenerFunction(e));
            this.rootObj.on("click", "input", (e) => innertlistenerFunction(e));
            this.rootObj.on("keyup", "textarea", (e) => innertlistenerFunction(e));
            
        }

    }
    ,
    /*
        결재선 관련 묶음
    */
    async loadGroupA() {
    	
    	//doc id 가 있을시 결재선 데이터를 가져 온다.	
    	if (this.isDoc && this.GB_DOC_INFO.apprDocSeq){    		
    		await this.loadApprDocData(this.GB_DOC_INFO.apprDocSeq);
    	};
    	

    	
        //load 합의 결재선
        let _singleAddCPA = this.rootObj.find(".CPApprovalline.singleAdd");

        //load 수신 결재선
        let _finalCPA = this.rootObj.find(".CPApprovalline.final");


        //load 결재선
        this.rootObj.find(".CPApprovalline").not(".singleAdd,.final").each((_, itm) => {
            //this.load_CPApprovalline($(itm));

            // 합의 결재선 선처리
            if (_singleAddCPA.length > 0) {
                this.load_CPApprovalline($(_singleAddCPA.get(0)));
                _singleAddCPA.splice(0, 1);
            }

            // 수신 결재선 선처리
            if (_finalCPA.length > 0) {
                this.load_CPApprovalline($(_finalCPA.get(0)));
                _finalCPA.splice(0, 1);
            }

            //결재선 후처리
            this.load_CPApprovalline($(itm));

        });


        //load 합의 결재선 end
        while (_singleAddCPA.length > 0) {
            this.load_CPApprovalline($(_singleAddCPA.get(0)));
            _singleAddCPA.splice(0, 1);
        }

        //load 수신 결재선 end
        while (_finalCPA.length > 0) {
            this.load_CPApprovalline($(_finalCPA.get(0)));
            _finalCPA.splice(0, 1);
        }



        //load 수신 결재선
        /*
        this.rootObj.find(".CPApprovalline.final").each((_, itm)=> {
            this.load_CPApprovalline($(itm));
        }); 
        */
    }
    ,
    /**
     * 결재선 관련 데이터를 가져온다.
     * 
     */
    async load_CPApprovalline(obj = null) {

        /**
         * 
         * 
         * 
         * 2^1^40115345^김정배^폼빌더 개발^부장^jbkimjerry^16633^88^미승인^
         * 
         * 
         * 
         */

        let targetObj = obj.find(".splitBlock");

        if (targetObj == null) {
            return;
        }


        let _style = "main"; //결재선, 멀티컴포넌트
        let _approvallineInforTable = "approvallineInforTable"; //결재정보 ID


        //합의결제의 경우 최 상단의 editor_form_appr_line를 가져온다.
        if (obj.hasClass("singleAdd") === true) _style = "singleAdd";//합의결재선
        else if (obj.hasClass("final") === true) _style = "final";//수신결재선
        else if (obj.hasClass("singleTypeB") === true) _style = "singleTypeB";//대외공문결재선



        let _editor_form_appr_line = obj.find("#editor_form_appr_line").val();
        let _editor_form_appr_add_line = obj.find("#editor_form_appr_add_line").val();
        const _editor_form_appr_title = obj.find("#editor_form_appr_title").val();
        const _editor_form_appr_table_aglin = obj.find("#editor_form_appr_table_aglin").val();
        const _editor_form_appr_add_table_aglin = obj.find("#editor_form_appr_add_table_aglin").val();




        //합의 결재선
        if (_style == "singleAdd") {

            /*
             * 합의결제의 경우 최 상단의 editor_form_appr_line를 가져온다.
             */

            /*
             * init 
             * 데이터 없을때 표를 숨길경우  
             * _editor_form_appr_line = undefined;
            */
            _editor_form_appr_line = '';
            this.rootObj.find("#editor_form_appr_line").each(function (_, item) {
                if ($(item).val() != "finished") {
                    _editor_form_appr_line = $(item).val();
                    return false;
                }
            });


        }//수신 결재선
        else if (_style == "final") {

            /*
             * init 
             * 데이터 없을때 표를 숨길경우  
             * _editor_form_appr_line = undefined;
            */
            _editor_form_appr_line = '';
            this.rootObj.find("#editor_form_appr_line").each(function (_, item) {
                if ($(item).val() != "finished") {
                    _editor_form_appr_line = $(item).val();
                    return false;
                }
            });
            /*
            _editor_form_appr_line = '';
            if(
                $("#editor_aprDocEditApprLine").val() != undefined && 
                $("#editor_aprDocEditApprLine").val().length > 0  
            ){   
                _editor_form_appr_line = $("#editor_aprDocEditApprLine").val();   
            }
            */

        }



        //
        if (_editor_form_appr_line == undefined) return;


        //
        if (_editor_form_appr_line == "finished") return;





        //초기화시 부모 쪽에 데이터가 있으면 부모 데이터를 따라간다.
        if (            
            _editor_form_appr_line == '' &&
            $("#aprDocEditApprLine").val() != undefined &&
            $("#aprDocEditApprLine").val().length > 0
        ) {

            _editor_form_appr_line = $("#aprDocEditApprLine").val();

        } else if (_editor_form_appr_line == '' &&
            $("#form_appr_line").val() != undefined &&
            $("#form_appr_line").val().length > 0
        ) {
        	
            _editor_form_appr_line = $("#form_appr_line").val();

        }


        
        //data backup
        if( obj.find("#editor_form_appr_line").val() == '' && _editor_form_appr_line != '' )
        	obj.find("#editor_form_appr_line").attr('value', _editor_form_appr_line );





        const db = [];
        _editor_form_appr_line.split(",").forEach((item) => {
            const innerDB = [];
            item.split("^").forEach((_item) => {
            	
            	//remove
            	if(_item=="undefined") _item ="";            	
                innerDB.push(_item);
            });
            db.push(innerDB);
        });


        

        //console.log(db);





        /*
            # this.isDoc = 상신시(true) | 폼빌더시(false)

            # main = 결재선
            # singleAdd = 합의결재선
            # final = 수신결재선
            # singleTypeB = 대외공문결재선
        */

        /**
            * 양식편집기의 미리보기시에 임시로 기안자의 정보를 보여 준다.
        */
        //change macro data
        let addMainAddDataMacro = false;

        //직위 , 기안자 , 기안일
        let basicData = "$CT_DRFT_USR_POS$,$CT_DRFT_USR_NM$,";
        if ((_style == "main" || _style == "singleTypeB") && this.isDoc == false && (db.length <= 1 || (db.length > 2 && db[1][1] != 0))) {
            await $.ajax({
                url: CPView.url.macrolist,
                type: "post",
                data: [{ "name": "cont", "value": basicData }],
                success: function (res) {
                    if (res.cont) {
                        basicData = res.cont.split(",");
                        addMainAddDataMacro = true;
                    }
                }
            });
        }



        const DBA = [];
        let _TD_Group = 1; //테이블의 생성 그룹
        while (_TD_Group <= 4) {
            const innerDBA = [];

            if (_style == "main" && addMainAddDataMacro) {

                //default title
                if (_TD_Group == 1)
                    innerDBA.push(basicData[0]);
                if (_TD_Group == 2)
                    innerDBA.push(`<p class="apprtxt">${basicData[1]}</p><p class="txtRed">기안</p>`);//이름 + 상태
                if (_TD_Group == 3)
                    innerDBA.push(""); //날짜   

            //대외공문결재선은 그룹이 다르다.
            } else if (_style == "singleTypeB" && addMainAddDataMacro) {

                //default title
                if (_TD_Group == 1)
                    innerDBA.push(basicData[0]);
                if (_TD_Group == 2)
                    innerDBA.push(basicData[1]);
                if (_TD_Group == 3)
                    innerDBA.push("기안");//상태    
                if (_TD_Group == 4)
                    innerDBA.push(""); //날짜    

            }



            

            db.forEach((item) => {
                if (item.length > 5) {
                    /*
                    item[1] = {
                        0=기안
                        1=승인 
                        2=필수합의(순차) 
                        3=필수합의(병렬) 
                        4=선택합의(순차) 
                        5=선택합의(병렬)
                        6=수신부서
                    }                    
                    */                   
                    if (
                        ((_style == "main" || _style == "singleTypeB") && (item[1] == 0 || item[1] == 1))
                        ||
                        (_style == "singleAdd" && item[1] != 0 && item[1] != 1 && item[1] != 6)
                        ||
                        (_style == "final" && item[1] == 6)
                    ) {


                        //group01
                        if (_TD_Group == 1)
                            innerDBA.push(item[5]);//직위,직책


                        
                        //group02
                        if (_TD_Group == 2 && _style != "singleTypeB") {
                            
                            let _msg_9 = '';

                            //상신시 상태코드 = item[9]
                            if (this.isDoc && item[9] != 'N') {
                                _msg_9 = item[9];
                            }

                            innerDBA.push(`<p class="apprtxt">${item[3]}</p><p class="txtRed">${_msg_9}</p>`);
                        } else if (_TD_Group == 2 && _style == "singleTypeB") {

                            //이름
                            innerDBA.push(item[3]);

                        }



                        //group03
                        if (_TD_Group == 3 && _style != "singleTypeB") {

                            //날짜
                            let _msg_10 = '';

                            //상신시 상신날짜
                            if (this.isDoc && item[10]) {

                                const year = item[10].substring(0, 4);
                                const month = item[10].substring(4, 6);
                                const day = item[10].substring(6, 8);
                                
                                if( year && month && day )
                                _msg_10 = month + "/" + day;
                            }

                            innerDBA.push(_msg_10);

                        
                        } else if (_TD_Group == 3 && _style == "singleTypeB") {

                            let _msg_9 = '';

                            //상태
                            if (this.isDoc) {
                                _msg_9 = item[9];
                            }

                            innerDBA.push(_msg_9);
                        }



                        //추가!! 대외공문결재선
                        //group04
                        if (_TD_Group == 4 && _style == "singleTypeB") {

                            //날짜
                            let _msg_10 = '';

                            if (this.isDoc && item[10]) {

                                const year = item[10].substring(0, 4);
                                const month = item[10].substring(4, 6);
                                const day = item[10].substring(6, 8);

                                _msg_10 = year + "." + month + "." + day;
                            }

                            innerDBA.push(_msg_10);

                        }

                    }
                }

            });
            DBA.push(innerDBA);
            _TD_Group++;
        }

        


        //
        const addDb = [];
        let addDbFlush = false;
        if (_editor_form_appr_add_line != undefined) {
        	
        	
        	
        	
        	//폼빌더 생성시 매크로 자동 치환시 치환되지 않아야 할 코드도 같이 치환됨 다시 생성한다.
        	if ( 
        			CPView.isDoc &&
        			this.viewType == 'editview' &&
        			_editor_form_appr_add_line != '' && 
        			_editor_form_appr_add_line.includes("$CT_") == false ) {
        		
        		let tmp_replace_appr_add_line_array = [];
        		_editor_form_appr_add_line.split(",").forEach((item) => {
        			
                    let _tmp_tem = item.split("^");   
                    
                    if( _tmp_tem[0].includes("pv_CT_") && this.macro[_tmp_tem[0]] ){                    	
                    	_tmp_tem[1] = this.macro[_tmp_tem[0]].code;                    	
                    	addDbFlush = true;
                    }else if( _tmp_tem[0].includes("pv_AP_") && this.macro[_tmp_tem[0]] && targetObj.find(`#${_tmp_tem[0]}`).length > 0  ){
                    	_tmp_tem[1] = targetObj.find(`#${_tmp_tem[0]}`).html();                    	
                    	addDbFlush = true;
                    }
                    
                    if(_tmp_tem.length == 2 )
                    	tmp_replace_appr_add_line_array.push(_tmp_tem.join("^"));
                    
                    if( tmp_replace_appr_add_line_array.length > 0 ) 
                    	_editor_form_appr_add_line = tmp_replace_appr_add_line_array.join(",");
                    
        		});
        		
        	}

            
        	
        	//자동 처리 구간        	
        	if (_editor_form_appr_add_line != '' &&
                (
                    _editor_form_appr_add_line.includes("$CT_") 
                )
            ) {

                let _data = [{ "name": "cont", "value": _editor_form_appr_add_line }];

                //doc area
                /*
                if (this.isDoc && this.GB_DOC_INFO.apprDocSeq)
                    _data.push({ "name": "appr_doc_seq", "value": this.GB_DOC_INFO.apprDocSeq });
                    */

                //change macro data
                await $.ajax({
                    url: CPView.url.macrolist,
                    type: "post",
                    data: _data,
                    success: function (res) {
                        if (res.cont) {
                            _editor_form_appr_add_line = res.cont;

                            //    doc area = 실제 기안을 하는 것으로 판단.
                            //    변환된 데이터로 수정.                            
                            if (CPView.isDoc)
                                obj.find("#editor_form_appr_add_line").attr('value', res.cont);
                            //obj.find("#editor_form_appr_add_line").val(res.cont);
							
                            
                            //AP_ 계열은 기안완료 후에 생성 됨, 생성 이전에는 숨김처리 해 준다. 
                            if (_editor_form_appr_add_line.includes("$AP_")) {
                                $(Object.keys(CPView.macro)).each((_, itm) => {
                                    if (CPView.macro[itm]['code'].includes("$AP_")) {
                                        _editor_form_appr_add_line = _editor_form_appr_add_line.replace(CPView.macro[itm]['code'], '');
                                    }
                                });
                            }
                            


                        }
                    }
                });

            }
        	
        	
        	//자동 처리 구간 end
            





            _editor_form_appr_add_line.split(",").forEach((item) => {
                const innerDB = [];
                item.split("^").forEach((_item,_idx,_arr) => {
                    if (_item.length > 0){
                    	if(_idx == 0 ){
                    		
                    		if(CPView.macro[_item] && CPView.macro[_item]['txt'])
                    			innerDB.push(CPView.macro[_item]['txt']);
                    		
                    		innerDB.push("<span id='"+_item+"'>"+_arr[1]+"</span>");                    		
                    	}
                    }

                });

                if (innerDB.length > 0) addDb.push(innerDB);
            });

        }
        
        
        
        //console.log(addDb);





        let row = 3;
        let col = $.isNumeric(DBA[0].length) && DBA[0].length > 0 ? DBA[0].length : 1;

        let title = $.trim(_editor_form_appr_title);


        if (title) col++;


        let widthClassA = "68px";
        let widthClassB = "132px";
        let widthClassC = "100px";

        //add
        let addrow = addDb.length;
        let addcol = 2;

        //set min length
        //if(addrow > 0 && addrow < 5 ) addrow= 5;

        let _table_add = null;

        //결재정보 테이블 이전 데이터가 존재 하는지 확인
        const ___approvallineInforTable = targetObj.find(`table#${_approvallineInforTable}`)

        if (addDbFlush == false && addrow > 0 && ___approvallineInforTable.length > 0 ) {

            _table_add = ___approvallineInforTable[0];

        }else if (addrow > 0) {

            //결재정보 테이블 생성
            _table_add = this.setTableAppLine({
                tableID : _approvallineInforTable,
                row: addrow,
                col: addcol,
                title: '',
                addTitleClass: '',
                titleWidth: [widthClassA, widthClassB],
                titleWidthStyle: "fixed",
                useBlank: "n",
                db: addDb,
                replaceName: 'add_',
                addTRClass: '',
                bold: 'col'
            });
        }

        let _table = null;

        //table 라인, 제목이 없는 결재선
        if (_style == "singleTypeB") {

            _table = this.setTableAppLineTypeB({
                split: 5,
                db: DBA
            });

        } else {
        	
        	
        	
        	

        	_table = this.setTableAppLine({
                row: row,
                col: col,
                title: title,
                split : addrow > 0 ? 8 : 11,
                addTitleClass: ((addrow > 0 && col < 5) || (col < 11) ? '' : 'txtVertical'),
                titleWidth: [widthClassC],
                titleWidthStyle: "auto",
                useBlank: "y",
                db: DBA,
                replaceName: 'apr_',
                addTRClass: 'line',
                bold: 'row'
            });
        	
        	
        	/*
		  	합의 결재선 singleAdd		
		  	수신 결재선 final
		  	*/
        	//상신시 데이터가 없다면 숨긴다.
		  	if( ( _style == "singleAdd" ) && this.viewType == "view" && DBA[0].length == 0 && DBA[1].length == 0 ){		  		
		  		_table = "";		  		
		  	}
		  	

        }




        if (_table_add != null) {

            const _div = document.createElement('div');
            $(_div).addClass(_editor_form_appr_table_aglin);
            //$(_div).addClass( "fit" );
            //_div.classList.add("fit");

            if (_editor_form_appr_add_table_aglin == "left") {
                _div.appendChild(_table_add);
                _div.appendChild(_table);
            } else if (_editor_form_appr_add_table_aglin == "right") {
                _div.appendChild(_table);
                _div.appendChild(_table_add);
            } else {
                _div.appendChild(_table);
            }

            targetObj.empty().append(_div);

        } else {

            targetObj.addClass(_editor_form_appr_table_aglin);
            targetObj.empty().append(_table);

        }



        if (_style == "main") {

            //결재선이 한줄 이상인 경우
            if ($(_table).hasClass('multiline')) {

                targetObj.children('div:eq(0)').addClass("top");

                if (_table_add != null)
                    $(_table_add).addClass('multiline')
            }



            //flush
            /*
            if(           
            $("#form_appr_line").val() != undefined && 
            $("#form_appr_line").val().length > 0  
            ){
                $("#form_appr_line").val(_editor_form_appr_line);
            }
            */

            //flush
            if (CPView.isDoc)
            	obj.find("#editor_form_appr_line").val("finished");            
        }

    }
    , setTableAppLine(setting) {

        const row = setting.row ? setting.row : 1;
        const col = setting.col ? setting.col : 1;
        const split = setting.split ? setting.split : 9;
        const title = setting.title ? setting.title : null;
        const titleWidth = setting.titleWidth ? setting.titleWidth : ['120px'];
        const titleWidthStyle = setting.titleWidthStyle ? setting.titleWidthStyle : 'auto';
        const DB = setting.db;
        const addTitleClass = setting.addTitleClass ? setting.addTitleClass : '';
        const replaceName = setting.replaceName ? setting.replaceName : 'replaceName';
        const bold = setting.bold ? setting.bold : 'row';
        const addTRClass = setting.addTRClass ? setting.addTRClass : '';
        const useBlank = setting.useBlank ? setting.useBlank : 'y';
        const tableID = setting.tableID ? setting.tableID : null;

        //
        if (DB.length == 0) return;

        let rowSpanIdx = 0;
        const _wrap = document.createElement('table');

        //
        if( tableID != null ) _wrap.id = tableID;


        let addRow = 1;
        if (title && col > split) addRow = Math.ceil((col - split) / (split - 1)) + 1;
        else if (col > split) addRow = Math.ceil(col / split);

        //const addRow = Math.ceil(col / (title?split-1:split)) != col ? Math.ceil(col / (title?split-1:split)) : 1; 
        //const addRow = Math.ceil((col - split) / (title?split-1:split)) + 1 != col ? Math.ceil((col - split) / (title?split-1:split)) + 1: 1; 
        //const addRow = Math.ceil(col / split) != col ? Math.ceil(col / split) : 1; 
        const addCol = addRow > 1 ? (title ? split : split) : col;

        if (addRow > 1) _wrap.classList.add("multiline");

        //console.log("table" , col , split , addRow  , Math.ceil(col / (title?split-1:split)) );

        let _count = [row];
        for (let r = 0; r < row; r++) {
            _count[r] = 0;
        }

        for (let r = 0; r < row * addRow; r++) {

            const _idx = r % row;
            const _tr = document.createElement("tr");

            if (addTRClass)
                _tr.classList.add(addTRClass + _idx);

            for (let c = 0; c < addCol; c++) {

                let _tdh = document.createElement("td");

                if (title && r == 0 && c == rowSpanIdx) {

                    _tdh.classList.add("bold");
                    _tdh.classList.add("formbuildertableTitle");

                    if (addTitleClass) _tdh.classList.add(addTitleClass);
                    _tdh.rowSpan = row * addRow;
                    _tdh.innerHTML = title;

                } else if (title && c == rowSpanIdx) {
                    continue;
                } else {

                    if ((bold == 'row' && _idx == 0) || (bold == 'col' && c == 0))
                        _tdh.classList.add("bold");

                    let innerMsg = '';

                    if (DB[_idx][_count[_idx]] == undefined) {
                        if (useBlank == 'y') _tdh.classList.add("blank");
                    } else {
                        innerMsg = DB[_idx][_count[_idx]];
                        _count[_idx]++;
                        _tdh.innerHTML = innerMsg;
                    }

                }

                _tr.appendChild(_tdh);

            }

            _wrap.appendChild(_tr);

        }

        //
        const colgroup = document.createElement('colgroup');

        for (let c = 0; c < addCol; c++) {
            let _col = document.createElement('col');
            let addText = titleWidth[0];
            if (title) {
                if (c == rowSpanIdx) {
                    _col.classList.add("formbuildertableTitle");
                    if (addTitleClass) _col.classList.add(addTitleClass);
                }

                addText = `${c == rowSpanIdx ? titleWidth[0] : '*'}`;
            } else {
                addText = `${(title && titleWidth[c]) || (titleWidthStyle == 'fixed' && titleWidth[c]) ? titleWidth[c] : '*'}`;
            }

            //
            _col.setAttribute("width", addText);
            colgroup.appendChild(_col);
        }

        _wrap.insertAdjacentElement('afterbegin', colgroup);

        return _wrap;

    }

    , setTableAppLineTypeB(setting) {

        const split = setting.split ? setting.split : 5;
        const DB = setting.db;

        //
        if (DB.length == 0) return;

        const _wrap = document.createElement('table');

        const col = 3;
        let row = Math.ceil(DB[0].length / split);
        let _count = 0;

        for (let r = 0; r < row; r++) {

            const _tr = document.createElement("tr");
            const __tr = document.createElement("tr");

            for (let i = 0; i < split; i++) {

                let __tdh = document.createElement("td");
                __tdh.colSpan = col;
                __tdh.classList.add("col3");
                __tdh.classList.add("blank");

                let innerMsg = '';
                if (DB[3][_count] != undefined) {
                    innerMsg = DB[3][_count];

                    __tdh.innerHTML = innerMsg;
                }

                __tr.appendChild(__tdh);

                for (let c = 0; c < col; c++) {

                    let _tdh = document.createElement("td");
                    _tdh.classList.add("col" + c);
                    _tdh.classList.add("blank");

                    let innerMsg = '';

                    if (DB[c][_count] != undefined) {
                        innerMsg = DB[c][_count];
                        _tdh.innerHTML = innerMsg;
                    }
                    _tr.appendChild(_tdh);
                }

                _count++;

            }

            _wrap.appendChild(_tr);
            _wrap.appendChild(__tr);

        }

        return _wrap;

    }
    ,
    /**  
     * prop : {$target, editorIframeName, iframeHeight}
     * 
     * */
    creatNamoEditor(prop, isTab) {
        
        function appendHiddenInput(prop) {

            var input2 = document.createElement('input');
            // set attribute (input)
            input2.setAttribute("type", "hidden");
            input2.setAttribute("id", prop._id);
            input2.setAttribute("name", prop._name);
            input2.setAttribute("value", prop._value);

            prop.targetForm.appendChild(input2);
        }
        

        $('iframe#'+ prop.editorIframeName ).remove();
        $('form[target='+ prop.editorIframeName +  ']').remove();

        
        let submitFrame = `<iframe id="${prop.editorIframeName}" name="${prop.editorIframeName}" 
                frameborder="0" scrolling="no" style="width:100%; height:${prop.iframeHeight}px;"></iframe>`

        var newForm = document.createElement('form');
        // set attribute (form) 
        newForm.name = "editorIframSubmitForm";
        newForm.method = 'post';
        newForm.action = '/common/editor/namoeditor/editor';
        newForm.target = prop.editorIframeName;
        
        
        appendHiddenInput({
            targetForm: newForm
            , _id: 'readonly'
            , _name: 'readonly'
            , _value: 'false'
        });
        appendHiddenInput({
            targetForm: newForm
            , _id: 'toolbar'
            , _name: 'toolbar'
            , _value: 'true'
        });
        appendHiddenInput({
            targetForm: newForm
            , _id: 'height'
            , _name: 'height'
            , _value: prop.iframeHeight
        });
        appendHiddenInput({
            targetForm: newForm
            , _id: 'editorIframeName'
            , _name: 'editorIframeName'
            , _value: prop.editorIframeName
        });
        appendHiddenInput({
            targetForm: newForm
            , _id: 'editorObjectName'
            , _name: 'editorObjectName'
            , _value: prop.editorIframeName + ".editor"	//생성된 editor 객체 참조값이 셋팅될 이름.
        });

        let formAppendTarget = null;
        if (this.formTarget){
        	formAppendTarget = this.formTarget;
        	this.formTarget.append(newForm);
        }
        else{
        	formAppendTarget = prop.$target;
        	prop.$target.append(newForm);
        }
        
        prop.$target.append($(submitFrame));
        
        CPView.readSavedContent(prop.editorIframeName, isTab);

        setTimeout(function () {

        	newForm.submit();

        }, this.formloadDelay);

        return;

    }
    ,
    /**
     * editor가 1개일 경우만 현재 구현되어 있음. 
     * 1. 재기안시 저장되어있는 컨텐츠 로딩.
     * 2. 탭이동시 작성중일때는 내부 작성중 html저장소에서 editor로 html불러와 셋팅됨.
     * */
    readSavedContent(editorIframeName, isTab){
    	
    	let readContdiv = $("iframe[name=" + editorIframeName + "]").parent().parent();
        
        if(readContdiv && readContdiv.find("div[name=editorHideContent]").length == 0){
        	
        	readContdiv.append('<div class="dispNone" id="editorHideContent" name="editorHideContent" />');
        }
        
      //미리 저장된 파일이 있다면 추가
        const _html = CPView.rootObj.find(".CPWebeditor #_html");
        if( _html.length > 0 ){
	        if(isTab != true){
	    		//editor 최초 로딩시 저장값 로드.
	        	//console.log('readCont', _html.html());      
	    		readContdiv.find("div[name=editorHideContent]").html(_html.html());
	    		
	    		$("#_html").remove();
	    	}
        }

    }

    /**
     * 조직도 트리 그리기. 부서레벨
     * 
     * idtarget : 트리데이터 연결될 div selector idcntlSelectEl : 클릭이벤트 연결될 요소, select
     * or button
     * 
     * idtarget div css setting : #treeContainer {display:none;
     * position:absolute; top:67px; left:440px; width:250px;
     * height:550px;z-index:1000; overflow:auto;background:#EEEEEE; border:1px
     * solid #CCCCCC; padding:5px;}
     * 
     * 사용법 : isdisplayUser : 사용자보임, 숨김, idtarget : 트리연동 div, idcntlSelectEl :
     * 선택이벤트 연결 요소, ideptnm : 트리선택시 이름보일 요소 setTimeout(function(){
     * CPView.paintOrganizeTree('false', '#deptTreeDiv', function(){},
     * '#deptTreeDropdown', '#deptName'); }, 1);
     * 
     */
    ,
    initOragnizeUserTree(thisObj) {

        let dtree = '.treeUserArea';

        if (thisObj.length > 0) {

            thisObj.append($(`<div style="display:none" class="treeUserContainer treeContainer">
    				<a class="itemdel" style="float:right;font-weight:bold;">X</a>
    				<div class="treeUserArea"></div></div>`));

        } else {

            $('body').append($(`<div style="display:none" class="treeUserContainer treeContainer"><a class="itemdel" style="float:right;font-weight:bold;">X</a>
    				<div class="treeUserArea"></div></div>`));
        }

        function createTree() {
            var tree = new UserOrganization({
                treeId: "treeUser",
                options: "department.virtual=false&user.displayed=true",
                callback: function (node) {


                    if (node.hasChildren) {
                        return;
                    }

                    let curApplyInput = "#" + CPView._curOrgPopId + "_input";
                    let curApplyvals = "#" + CPView._curOrgPopId + "_hidd";

                    let dispVal = thisObj.find(curApplyvals).prop('value');

                    if (dispVal && dispVal.indexOf(node.key) > -1) {

                        return;
                    }

                    let beforestr = thisObj.find(curApplyInput).val();
                    let beforevals = thisObj.find(curApplyvals).val();

                    if (beforestr && beforestr.length > 0) {
                        //$('#previewArea').find(curApplyInput).val( beforestr + "," + node.text );
                        CPView.labelWithDelButton(thisObj.find(curApplyInput), beforestr + "," + node.text);
                        thisObj.find(curApplyvals).val(beforevals + "," + node.key);
                    }
                    else {
                        //$('#previewArea').find(curApplyInput).val(node.text);
                        CPView.labelWithDelButton(thisObj.find(curApplyInput), node.text);

                        thisObj.find(curApplyvals).val(node.key);

                    }
                    //$(idtarget).fadeToggle();
                }
            });

            tree.paint($(dtree));

        }

        setTimeout(function () {

            createTree();

            $('#treeUser').css('height', '500px');

        }, 10);

    }
    ,
    initOragnizeDeptTree(thisObj) {

        let dtree = '.treeDeptArea';

        if (thisObj.length > 0) {

            thisObj.append($(`<div style="display:none" class="treeDeptContainer treeContainer">
    				<a class="itemdel" style="float:right;font-weight:bold;">X</a>
    				<div class="treeDeptArea"></div></div>`));

        } else {

            $('body').append($(`<div style="display:none" class="treeDeptContainer treeContainer"></div>`));
        }


        function createTree() {

            var tree = new UserOrganization({
                treeId: "treeDept",
                options: "department.virtual=false&user.displayed=false",
                callback: function (node) {

                    //console.log('dept click', node);


                    let curApplyInput = "#" + CPView._curOrgPopId + "_input";
                    let curApplyvals = "#" + CPView._curOrgPopId + "_hidd";


                    let dispVal = thisObj.find(curApplyvals).prop('value');

                    if (dispVal && dispVal.indexOf(node.key) > -1) {

                        return;
                    }
                    //하위값을 가진 부서는 트리가 펼쳐진 상태에서만 값을 클릭으로 선택가능.
                    if (!node.expanded && node.hasChildren) {

                        return;
                    }

                    let beforestr = thisObj.find(curApplyInput).val();
                    let beforevals = thisObj.find(curApplyvals).val();

                    if (beforestr && beforestr.length > 0) {

                        //$('#previewArea').find(curApplyInput).val( beforestr + "," + node.text );
                        CPView.labelWithDelButton(thisObj.find(curApplyInput), beforestr + "," + node.text);
                        thisObj.find(curApplyvals).val(beforevals + "," + node.key);
                    }
                    else {

                        //$('#previewArea').find(curApplyInput).val(node.text);
                        CPView.labelWithDelButton(thisObj.find(curApplyInput), node.text);

                        thisObj.find(curApplyvals).val(node.key);
                    }

                    //$(idtarget).fadeToggle();
                }
            });

            //$(treeId).data("kendoTreeView")\

            tree.paint($(dtree));

        }

        setTimeout(function () {

            createTree();
            $('#treeDept').css('height', '500px');

        }, 100);

    }
    ,
    ///사용자, 부서 컴포 
    organViewInit() {

        function getxy(e) {

        	let x = parseInt(e.clientX) - 200;
            let y = parseInt(window.scrollY) ;

            //사용자환경 오차.
            if (CPView.isDoc) {

                y = y - 500 ;
            }

            //console.log(`버튼의 정확한 좌표: event=${e.clientX}, y=${window.scrollY}`);
            //console.log(`버튼의 정확한 좌표: x=${x}, y=${y}`);

            return { "x": x, "y": y }
        }

        $(document).off('click', this.rootObj.parent());
        $(document).on('click', this.rootObj.parent(), function (e) {

            if ($(e.target).attr('id') == 'previewArea'
                || $(e.target).attr('id') == 'formbuilder_view'
            ) {

                $('.treeContainer').hide();
            }
        });


        //사용자 팝업 보임 숨김
        this.rootObj.find('.CPOrganize .pv_user').each(
            function (i, itm) {

                $(itm).off('click');

                $(itm).on('click', function (e) {

                    $('.treeDeptContainer').hide();

                    CPView._curOrgPopId = $(e.target).attr('id');

                    $('.treeUserContainer').css({ "left": getxy(e).x, "top": getxy(e).y });

                    $('.treeUserContainer').show();
                });

            }

        );

        //부서 보임 숨김
        this.rootObj.find('.CPOrganize  .pv_dept').each(
            function (i, itm) {

                $(itm).off('click');

                $(itm).on('click', function (e) {

                    $('.treeUserContainer').hide();

                    CPView._curOrgPopId = $(e.target).attr('id');

                    $('.treeDeptContainer').css({ "left": getxy(e).x, "top": getxy(e).y });

                    $('.treeDeptContainer').show();
                });

            }
        );

        //수신자 팝업 보임 숨김
        this.rootObj.find('.CPOrganize .pv_recipient ').each(
            function (i, itm) {

                $(itm).off('click');

                $(itm).on('click', function (e) {

                    $('.treeDeptContainer').hide();

                    CPView._curOrgPopId = $(e.target).attr('id');

                    $('.treeUserContainer').css({ "left": getxy(e).x, "top": getxy(e).y });

                    $('.treeUserContainer').show();
                });

            }

        );

    }
    ,
    ////jbkim 1023 통화컴포 .CPCurrency input
    cpcurrencyViewInit() {

        this.rootObj.find('.CPCurrency input').each(
            function (i, itm) {

                $(itm).off('keyup');

                $(itm).on('keyup', function (e) {

                    let thisval = $(this).val();

                    $(this).val(CPView.moneyFormatter(thisval,2));
                });

            }

        );
    }
    ,
    ////jbkim 1023 양식명 컴포 .
    setPvFormTitle() {

        this.rootObj.find('.CPFormTitle .titleName').each(
            function (i, itm) {

                $(itm).val(CPView.GB_DOC_INFO.formTitle);

            }

        );
    }
    ,
    /**
     * 123,124,124,141
     * 
     * */
    moneyFormatter(num , max = 0) {

        try {

        	if (num && typeof num != 'number' ) {
                num = num.replace(/,/g, '');
                num = num.replace('NaN', '');
            }

            num = Number(num).toLocaleString('ko-KR', { maximumFractionDigits: max });

        } catch (e) {

            num = '0';
        }

        return num;
    }
    ,
    labelWithDelButton($target, text) {

        $target.append($(`<button class="mailsendBtn mL5"><span class="oranText">${text}</span>&nbsp;<a class='itemdel' onclick='$(this).parent().remove()'>X</a></button>`));

    }
    ,
    calculator(db = '') {

    	let counter = 0;
        let calculatorIDX = 0;
        let onGroupCount = 0;
        let offGroupCount = 0;
        let parenthesisCounter;
        let finalParenthesis;
        let toLoop = false;
        let dbArray = db.split("");        

        //
        const targetString = "e";
        if(db.includes(targetString)){
            dbArray.forEach((itm,idx,array)=>{
                if( itm == targetString && array[idx+1] != undefined && (array[idx+1] == "+"||array[idx+1] == "-") ){
                    array[idx] += array[idx+1];
                    array[idx+1] = "";
                }
            });
            
            dbArray = dbArray.filter((element, i) => element != '');
        }

        //checkExpo();


        uniteCharacter();

        for (let i = 0; i < dbArray.length; i++) {
            if (isNaN(parseFloat(dbArray[i])) === false) {
                dbArray[i] = parseFloat(dbArray[i])
            }
        }

        while (dbArray.includes("(")) {

            solveMultiplicationAndDivisionInParenthesis();

            solveAdditionsAndSubtractionInParenthesis();

            if (dbArray.includes(NaN)) {
                throw new Error(`calculator-error "${db}"`); 
            }

            for (let i = 0; i < dbArray.length; i++) {
                if (dbArray[i] === "(") {
                    onGroupCount++;
                    calculatorIDX = i;
                }
                if (dbArray[i] === ")") {
                    offGroupCount++;
                }
            }
            
            if (
                onGroupCount !== offGroupCount || 
                (onGroupCount === offGroupCount && dbArray[calculatorIDX + 1] === ")")
            ) {
                throw new Error(`calculator-error "${db}"`); 
            }

        }

        while ( 
                (
                dbArray.includes("*") || 
                dbArray.includes("/") || 
                dbArray.includes("+") || 
                dbArray.includes("-") || 
                dbArray.some(x => x < 0) 
                )
                && 
                dbArray.length !== 1) {
            solveMultiplicationAndDivision();
            solveAdditionsAndSubtraction();
        }

        return dbArray[0];

        
        function uniteCharacter() {
            let counter = 0
            while (dbArray[counter + 1] !== undefined) {
                try {
                    if (isNaN(parseFloat(dbArray[counter])) && dbArray[counter] !== "-") {
                        counter++;
                    }
                    else if (isNaN(parseFloat(dbArray[counter])) === false || dbArray[counter] === "-") {
                        if (isNaN(parseFloat(dbArray[counter + 1])) === false || dbArray[counter + 1] === ".") {
                            let numberCounter = counter;
                            while (isNaN(parseFloat(dbArray[numberCounter + 1])) === false || dbArray[counter + 1] === ".") {
                                dbArray[numberCounter] += dbArray[numberCounter + 1];
                                dbArray.splice(numberCounter + 1, 1);
                            }
                        }
                        else {
                            counter++;
                        }
                    }

                } catch (e) {
                    counter--;
                    break
                }
            }

            dbArray[dbArray.length - 1] = dbArray[dbArray.length - 1].replaceAll('undefined', '');
        }

        function solveMultiplicationAndDivisionInParenthesis() {
            do {
                for (let j = dbArray.length; j > 0; j--) {
                    if (dbArray[j] === ")") {
                        finalParenthesis = j;
                    }
                }
                for (let i = 0; i < dbArray.length; i++) {
                    if (dbArray[i] === "(" && i < finalParenthesis) {
                        parenthesisCounter = i;
                        counter = parenthesisCounter + 1;
                    }
                }
                for (let i = parenthesisCounter; i < finalParenthesis; i++) {
                    if (dbArray[i] === "*" || dbArray[i] === "/") {
                        toLoop = true;
                        break;
                    }
                    else {
                        toLoop = false;
                    }
                }

                while (counter < finalParenthesis) {
                    counter++;
                    for (let operatorChecker = parenthesisCounter + 1; operatorChecker < finalParenthesis; operatorChecker++) {
                        multiplyDivide(operatorChecker);
                    }
                }
            } while (toLoop === true && dbArray.includes("(") && dbArray.includes(")"))
        }

        function multiplyDivide(operatorChecker) {
            while (dbArray[operatorChecker - 1] !== ")" && dbArray[operatorChecker] === "*" && dbArray[operatorChecker + 1] !== "(" && dbArray.includes("(")) {
                dbArray[operatorChecker - 1] *= dbArray[operatorChecker + 1];
                dbArray.splice(operatorChecker, 2);
            }
            while (dbArray[operatorChecker - 1] !== ")" && dbArray[operatorChecker] === "/" && dbArray[operatorChecker + 1] !== "(" && dbArray.includes("(")) {
                dbArray[operatorChecker - 1] /= dbArray[operatorChecker + 1];
                dbArray.splice(operatorChecker, 2);
            }
            while (dbArray[operatorChecker - 1] !== ")" && dbArray[operatorChecker] === "*" && dbArray[operatorChecker + 1] !== "(" && dbArray.includes("(")) {
                dbArray[operatorChecker - 1] *= dbArray[operatorChecker + 1];
                dbArray.splice(operatorChecker, 2);
            }
            for (let i = 0; i < dbArray.length; i++) {
                if (dbArray[i - 1] === "(" && isNaN(parseFloat(dbArray[i])) === false && dbArray[i + 1] === ")") {
                    dbArray.splice(i - 1, 1);
                    i--;
                    dbArray.splice(i + 1, 1);
                    i--;
                }
            }
        }

        function solveAdditionsAndSubtractionInParenthesis() {
            do {
                for (let j = dbArray.length; j > 0; j--) {
                    if (dbArray[j] === ")") {
                        finalParenthesis = j;
                    }
                }
                for (let i = 0; i < dbArray.length; i++) {
                    if (dbArray[i] === "(" && i < finalParenthesis) {
                        parenthesisCounter = i;
                        counter = parenthesisCounter + 1;
                    }
                }
                for (let i = parenthesisCounter; i < finalParenthesis; i++) {
                    if (dbArray[i] === "+" || dbArray[i] === "-") {
                        toLoop = true;
                        break;
                    }
                    else {
                        toLoop = false;
                    }
                }


                while (counter < finalParenthesis) {
                    counter++;
                    for (let operatorChecker = parenthesisCounter + 1; operatorChecker < finalParenthesis; operatorChecker++) {
                        sumSubtract(operatorChecker);
                    }
                }
            } while (toLoop === true && dbArray.includes("(") && dbArray.includes(")"))
        }

        function sumSubtract(operatorChecker) {
            while (dbArray[operatorChecker - 1] !== ")" && dbArray[operatorChecker] < 0 && dbArray[operatorChecker - 1] !== "(" && dbArray.includes("(")) {
                dbArray[operatorChecker - 1] += dbArray[operatorChecker];
                dbArray.splice(operatorChecker, 1);
            }
            while (dbArray[operatorChecker - 1] !== ")" && dbArray[operatorChecker] === "+" && dbArray[operatorChecker + 1] !== "(" && dbArray.includes("(")) {
                dbArray[operatorChecker - 1] += dbArray[operatorChecker + 1];
                dbArray.splice(operatorChecker, 2);
            }
            while (dbArray[operatorChecker - 1] !== ")" && dbArray[operatorChecker] === "-" && dbArray[operatorChecker + 1] !== "(" && dbArray.includes("(")) {
                dbArray[operatorChecker - 1] -= dbArray[operatorChecker + 1];
                dbArray.splice(operatorChecker, 2);
            }

            for (let i = 0; i < dbArray.length; i++) {
                if (dbArray[i - 1] === "(" && isNaN(parseFloat(dbArray[i])) === false && dbArray[i + 1] === ")") {
                    dbArray.splice(i - 1, 1);
                    i--;
                    dbArray.splice(i + 1, 1);
                    i--;
                    finalParenthesis = parenthesisCounter;
                    toLoop = false;
                }
            }
        }

        function solveAdditionsAndSubtraction() {
            for (let i = 0; i < dbArray.length; i++) {
                if (dbArray[i] === "+") {
                    dbArray[i - 1] += dbArray[i + 1];
                    dbArray.splice(i, 2);
                }
                if (dbArray[i - 1] !== undefined && dbArray[i] < 0) {
                    dbArray[i - 1] += dbArray[i];
                    dbArray.splice(i, 1);
                }
            }
        }


        function solveMultiplicationAndDivision() {
            for (let i = 0; i < dbArray.length; i++) {
                if (dbArray[i] === "*") {
                    dbArray[i - 1] *= dbArray[i + 1];
                    dbArray.splice(i, 2);
                }
                if (dbArray[i] === "/") {
                    dbArray[i - 1] /= dbArray[i + 1];
                    dbArray.splice(i, 2);
                }
                if ((i === dbArray.length - 1 && dbArray.includes("*")) || dbArray.includes("/")) {
                    i = 0;
                }
            }
        }


    }
    ,
    cpcalculatorlistenItem() {

        /*
        function numIDXtoFix(x) {

            if (Math.abs(x) < 1.0) {
              var e = parseInt(x.toString().split('e-')[1]);
              if (e) {
                  x *= Math.pow(10,e-1);
                  x = '0.' + (new Array(e)).join('0') + x.toString().substring(2);
              }
            } else {
              var e = parseInt(x.toString().split('+')[1]);
              if (e > 20) {
                  e -= 20;
                  x /= Math.pow(10,e);
                  x += (new Array(e+1)).join('0');
              }
            }
            return x;
        }    
        */    

        function innertFunction(e) {

            //
            const numberLimit = 14; //숫자 최대 결과 값의 범위 설정 
            const addValueDumChar = '@';
            const failVal = 'nil';
            const _table = e.target.closest(`table`);
            const _tr = e.target.closest(`tr`);
            const _td = e.target.closest(`td`);

            if( e.target.id != undefined && e.target.id.includes("CPNumber")){
                if( e.target.value.toString().length > numberLimit ){

                    layCmn.alert({
                        msg: `(계산 범위 초과) 계산기는 '${numberLimit}'자리 까지 계산이 가능 합니다.`,
                        callback: function (e) { }
                    }); 

                    return;
                }
            }

            
            const _CPNumber = e.target.closest(`.CPNumber`);
            const _CPCalculatorID = _CPNumber.dataset.rowTarget;
            const _CPCalculatorColID = _CPNumber.dataset.colTarget;

            let _calculatortotal = $(_tr).find(".CPCalculator.calculatortotal").attr("data-total-target");
            let _calculatorglobaltotal = $(_table).find(".CPCalculatortotal.calculatorglobaltotal").attr("data-global-target");

            let _failMsg = "";
            let preText = "<b>= </b>";
            CPView.rootObj.find(".CPCalculator").each((_, _cal) => {
            	
            	

                const CP_STYLE = $(_cal).attr('data-style');

                if (CP_STYLE == "col" && _CPCalculatorColID != undefined) {

                    //flush
                    if (_calculatortotal == undefined)
                        _calculatortotal = $(_table).find(".CPCalculator.calculatortotal").attr("data-total-target");


                    let _tdIDX = null;
                    let _func = $(_table).find(`#pv_${_CPCalculatorColID}data`).val();
                    let _sum = $(_table).find(`#pv_${_CPCalculatorColID}calSum`);

                    $(_table).find('tr').each(function (_, tr) {
                        if (tr == _tr) {
                        	let countIdx = 0;
                            $(tr).find('td').each(function (idx, td) {
                            	countIdx += td.colSpan;
                                if (td == _td) {
                                    _tdIDX = countIdx; 
                                    return false;
                                }
                            });
                            return false;
                        }
                    });

                    let sum = {};
                    if (_tdIDX != null && _func != undefined) {

                        $(_table).find('tr').each(function (_, tr) {
                        	let countIdx = 0;
                            $(tr).find('td').each(function (idx, td) {
                            	countIdx += td.colSpan;
                                if (countIdx != _tdIDX) return true;

                                //
                                $(td).find(".CPNumber.calculator").each((__, _itm) => {
                                    const _id = $(_itm).attr("data-id");
                                    if (sum[_id] == undefined) sum[_id] = 0;

                                    const _number = $(_itm).find(`#pv_${_id}`);
                                    const _val = _number.val().trim(); 
                                    $(_number).attr('value',_val);

                                    sum[_id] = Number(sum[_id]) + Number(_val);
                                });
                            });
                        });
                    }

                    $(Object.keys(sum)).each((_, _id) => {  
                        _func = _func.replaceAll(addValueDumChar + _id + addValueDumChar, sum[_id] );
                    });

                    //
                    if (_func.includes(addValueDumChar)) {
                        $(_sum).html(preText+failVal);
                    } else {

                        let _tmpSum = 0;

                        try { 
                        	// eslint-disable-next-line
                            _tmpSum = new Function('return ' + _func)();
                            //_tmpSum = CPView.calculator(_func);
                        } catch (e) {
                            _failMsg = { error: e, msg: _func };
                            _tmpSum = preText+failVal;
                        } finally {
                            $(_sum).html("<p>"+preText+CPView.moneyFormatter(_tmpSum,2)+"</p>");

                            /*
                            if( _tmpSum.toString().length > numberLimit ){
                                _failMsg = { msg: '', code: 'numberLimit' };
                                $(_sum).html(failVal);
                            }else{
                                $(_sum).html("<p>"+CPView.moneyFormatter(_tmpSum,2)+"</p>");
                            } 
                            */
                        }

                    }

                } else {

                    for (const tr of _table.querySelectorAll('tr')) {
                        if (tr == _tr) {

                            let _func = $(tr).find(`#pv_${_CPCalculatorID}data`).val();
                            let _sum = $(tr).find(`#pv_${_CPCalculatorID}calSum`);

                            if (_func == undefined) break;

                            //
                            $(tr).find(".CPNumber.calculator").each((__, _itm) => {
                                const _id = $(_itm).attr("data-id");
                                const _number = $(_itm).find(`#pv_${_id}`);
                                const _val = _number.val().trim();  
                                $(_number).attr('value',_val);
                                if (_val == '') return false;

                                _func = _func.replaceAll(addValueDumChar + _id + addValueDumChar, _val);

                            });


                            //
                            if (_func.includes(addValueDumChar)) {
                                $(_sum).html(preText+failVal);
                            } else {

                                let _tmpSum = 0;

                                try {
                                	// eslint-disable-next-line
                                    _tmpSum = new Function('return ' + _func)();
                                    //_tmpSum = CPView.calculator(_func);
                                } catch (e) {
                                    _failMsg = { msg: e, code: _func };
                                    _tmpSum = preText+failVal;
                                } finally {

                                    $(_sum).html("<p>"+preText+CPView.moneyFormatter(_tmpSum,2)+"</p>");

                                    /*
                                    if( _tmpSum.toString().length > numberLimit ){
                                        _failMsg = { msg: '', code: 'numberLimit' };
                                        $(_sum).html(failVal);
                                    }else{
                                        $(_sum).html("<p>"+CPView.moneyFormatter(_tmpSum,2)+"</p>");
                                    } 
                                    */                               	
                                }

                            }

                            break;
                        }
                    }

                }

            });


           


            //
            if (_failMsg){

                //alert(`수식을 확인해 주세요. ( ${_failMsg.code} )\r\n${_failMsg.msg}`);
                layCmn.alert({
                    msg: `수식을 확인해 주세요. ( ${_failMsg.code} )\r\n${_failMsg.msg}`,
                    callback: function (e) { }
                }); 

            } 


            //CPCalculatortotal            
            if (_calculatortotal != undefined) {

                let _calculatortotalsum = 0;
                CPView.rootObj.find(".CPCalculator.calculatortotal").each((_, _sum) => {

                    if (_calculatortotal != $(_sum).attr("data-total-target")) return true;

                    const _calculatorid = $(_sum).attr("data-id");

                    if (_calculatorid) {

                        const _calsum = $(_sum).find(`#pv_${_calculatorid}calSum`).html().replace(/[^0-9\-]/g, "");

                        if ($.isNumeric(_calsum))
                            _calculatortotalsum += Number(_calsum);

                    }

                });

                //total sum
                CPView.rootObj.find(`#pv_${_calculatortotal}calSum`).html("<p>"+preText+CPView.moneyFormatter(_calculatortotalsum,2)+"</p>");

            };


            //CPCalculatorglobaltotal
            if (_calculatorglobaltotal != undefined) {

                let _calculatorglobaltotalsum = 0;
                CPView.rootObj.find(".CPCalculatortotal.calculatorglobaltotal").each((_, _sum) => {

                    if (_calculatorglobaltotal != $(_sum).attr("data-global-target")) return true;

                    const _calculatorid = $(_sum).attr("data-id");

                    if (_calculatorid) {

                        const _calsum = $(_sum).find(`#pv_${_calculatorid}calSum`).html().replace(/[^0-9\-]/g, "");

                        if ($.isNumeric(_calsum))
                            _calculatorglobaltotalsum += Number(_calsum);

                    }

                });

                //total sum
                CPView.rootObj.find(`#pv_${_calculatorglobaltotal}calSum`).html("<p>"+preText+CPView.moneyFormatter(_calculatorglobaltotalsum,2));

            }

        }



        //listen
        this.rootObj.on("keyup", ".CPNumber.calculator", (e) => innertFunction(e));
        this.rootObj.on("click", ".CPNumber.calculator", (e) => innertFunction(e));

    }
    ,
    cpcalculatormultirow() {    	
    	

        //listen
        this.rootObj.on("click", ".btn_cpcalculator_add , .btn_cpcalculator_del", function (e) {

            //
            const _table = e.target.closest(`table`);
            const _tbody = e.target.closest(`tbody`);
            const _tr = e.target.closest(`tr`);
            const _calculatorItem = e.target.closest(`.CPCalculator`);
            const type = $(e.target).hasClass("btn_cpcalculator_add") ? "add" : "del";


            //only use IN Table 
            if (_table == null) return console.log("fail-table");
            if (_tbody == null) return console.log("fail-tbody");
            if (_tr == null) return console.log("fail-tr");
            if (_calculatorItem == null) return console.log("fail-calculator");


            _table.querySelectorAll('tr').forEach((tr) => {

                if (type == "add") {

                    _tbody.appendChild(tr);

                    if (tr == _tr) {

                        //
                        const copy = tr.cloneNode(true);
                        
                        /*
                        const _msg = $(copy).find(".CPCalculator .alertmsg").html(); 
                        if ( _msg ) { 
                        	layCmn.alert({
                	            msg: _msg,
                	            callback: function (e) { }
                	        });                        	
                            return;
                        }
                        */

                        //change
                        const copyBtn = $(copy).find(".btn_cpcalculator_add");
                        copyBtn.removeClass("btn_cpcalculator_add");
                        copyBtn.addClass("btn_cpcalculator_del");
                        copyBtn.html("-");

                        //remove                        
                        $(copy).find(".pv_table_id").remove();
                        $(copy).find(".alertmsg").remove();
                        $(copy).find(".required").remove();
                        $(copy).find(".calFrom").remove();


                        //
                        _tbody.appendChild(copy);

                    }

                } else if (type == "del") {

                    if (tr == _tr) tr.remove();
                    else _tbody.appendChild(tr);
                }


            });



            //flush
            let _td = [_tr.length];
            $(_table).find('tr').each(function (_, tr) {
                $(tr).find('td').each(function (idx, td) {
                    const itm = $(td).find(".CPNumber.calculator");
                    if (itm.length > 0 && _td[idx] == undefined) itm.click();
                });
            });


        });


    }
    ,
    getAprDoc(formBuilderSeq = 0, apprDocSeq = 0) {

        return new Promise((resolve, reject) => {

            $.ajax({
                url: '/cnfg/apr/formbuilder/getaprdoc',
                type: "post",
                data: {
                    "formBuilderSeq": formBuilderSeq,
                    "apprDocSeq": apprDocSeq
                },
                success: function (result) {
                    resolve(result);
                },
                error: function (response, status, error) {
                    reject(error);
                }
            });

        });

    }
    ,
    setDocInfoComp(docjson) {

        if (docjson) {

            let keys = Object.keys(docjson);

            keys.map((key) => {

                CPView.rootObj.find("#pv_" + key).each(function () {
                    $(this).html(docjson[key]);
                });

            });
        }

    }
    ,
    requiredInputValidate() {
    	
    	let rtn = true;

    	$("#formbuilder_view").find("input[id^=pv_]").each(function () {

            if (
                $(this).attr("required") == 'required'
                && ($(this).val() == '' || $(this).val() == undefined)) {

                let _thisobj = $(this);
                let _thisname = $(this).attr('name');

                /*layCmn.alert({
                    msg: _thisname + '(은)는 필수입력 항목입니다.',
                    callback: function (result) {

                        _thisobj.focus();
                        if (!result) return;
                    }
                });
*/                
                layCmn.msg(_thisname + '(은)는 필수입력 항목입니다.');
                _thisobj.focus();
                rtn = false;
            }

        });

        return rtn;
    }
    ,
    changeViewMode() {
    	
    	//console.log('changeViewMode start...')
    	
    	//init preview
    	let clonehtml = CPView.rootObj.clone();
    	$('#formbuilderViewRes').remove();
    	CPView.previewCopyArea.append($('<div style="display:none" id="formbuilderViewRes"></div>'));
		
		clonehtml.find("input[type=radio]").each(function (){
			$(this)
			.attr('name', "re" + $(this).attr('name'));
			
		});
		
		$('#formbuilderViewRes').html(clonehtml);	//copy
		
    	

        let fbviewcssNm = "fb-view-tx-df";		//폼빌더 미리보기 텍스트형  default css

        let _srcViewAreaId = CPView.rootObj;
        let _resultViewAreaId = $('#formbuilderViewRes');

        if (!this.requiredInputValidate()) {

            return false;
        }
        
        _srcViewAreaId.find("input").each(function () {
        	
        	//결재선 관련 input값은 삭제에서 제외
        	if( $(this).attr("id").includes("editor_") ) return true;

        	_resultViewAreaId.find("#"+ $(this).attr("id")).attr('value', $(this).val());
        });
 
        _resultViewAreaId.find("#pv_APPR_DOC_TIT").each(function () {
        	$(this).html( $('#appr_doc_tit').val() );
        });
        
        
        //CPApprovalline insert input data
        _srcViewAreaId.find(".CPApprovalline").not(".singleAdd,.final").each(function () {
        	
        	const _id = $(this).attr('data-id');
        	const _editor_form_appr_line = $(this).find('#editor_form_appr_line').val();
        	
        	_resultViewAreaId.find(".CPApprovalline").each(function () {        		
        		if( _id == $(this).attr('data-id') ){        			
        			$(this).find('#editor_form_appr_line').val(_editor_form_appr_line);
        			return false;        			
        		}        		
        	});
        });

        /**
         * 각 컴포넌트의 값을 읽어 태그 밖으로 빼주는 변환처리.
         * 
         * */
        //텍스트 .
        _srcViewAreaId.find(".CPInput input[type=text],.CPNumber input[type=text],.CPCurrency input[type=text]").each(function () {
        	
        	let _id = $(this).attr('id');
        	if(_id.indexOf('CPInput') > 0){
        		
        		_resultViewAreaId.find('#' + $(this).attr('id')).before('<span id="'+ $(this).attr('id') +'" style=" ' + $(this).attr('style') + '" ><p>' + $(this).val() + '</p></span>');
        	}
        	//스타일 적용의 차이.
        	else{
            	_resultViewAreaId.find('#' + $(this).attr('id')).before('<span id="'+ $(this).attr('id') +'" class="'+ fbviewcssNm +'" ><p>' + $(this).val() + '</p></span>');

        	}
        	_resultViewAreaId.find('#' + $(this).attr('id') + ':not(:first-child)').remove();
        });
        
        //멀티텍스트 .
        _srcViewAreaId.find("textarea").each(function () {
        	_resultViewAreaId.find('#' + $(this).attr('id')).parent().html('<span style=" ' + $(this).attr('style') + ' "><p>' + $(this).val().replace(/</g, "&lt;").replace(/\r\n|\n/g, "<br>") + '</p></span>');
        });
        
        //날짜 .
        _srcViewAreaId.find(".CPDateBox").each(function () {
            
        	let _id = $(this).attr('data-id'); 
        	
            //_resultViewAreaId.find('#pvdiv_' + _id).html('<span id="pv_'+ $(this).attr('id') +'" class="'+ fbviewcssNm +'" style="' + $('#pv_'+_id).attr('style') + ' "><p>' + $('#pv_'+_id).val() + '</p></span>');
        	//_resultViewAreaId.find('#' + $(this).attr('id') + ':not(:first-child)').remove();
        });
        //기간 . 
        
        _srcViewAreaId.find(".CPDateBox,.CPDateBetween,.CPDateTime").each(function () {
        	let _id = $(this).attr('data-id'); 
        	
        	if($(this).hasClass('CPDateBetween'))
        	{
        		_resultViewAreaId.find('#pvdiv_' + _id).html(
            			'<span  class="'+ fbviewcssNm +'" style="' + $('#'+_id+'_sDate').attr('style') + ' "><p>' + $('#'+_id+'_sDate').val() + ' ~ '  + $('#'+_id+'_eDate').val() + '</p></span>'
            		);
        	}
        	else if($(this).hasClass('CPDateTime'))
        	{
        		_resultViewAreaId.find('#pvdiv_' + _id).html(
            			'<span  class="'+ fbviewcssNm +'"  ><p>' 
            			+ $('#pv_'+_id+'_hr').val() 
            			+ '시 '  + $('#pv_'+_id+'_min').val() + '분</p></span>');

        		
        	}
        	else if($(this).hasClass('CPDateBox'))
        	{
        		_resultViewAreaId.find('#pvdiv_' + _id).html(
        				'<span class="'+ fbviewcssNm +'" style="' + $('#pv_'+_id).attr('style') + ' "><p>' 
        				+ $('#pv_'+_id).val() + '</p></span>');
        		
        	}
        	
        	//_resultViewAreaId.find('#' + $(this).attr('id') + ':not(:first-child)').remove();
        });
        //드롭박스 .
        _srcViewAreaId.find(".CPSelectBox select").each(function (){
        	_resultViewAreaId.find('#' + $(this).attr('id')).before('<span id="'+ $(this).attr('id') +'" class="'+ fbviewcssNm +'" style="' + $(this).attr('style') + ' "><p>' + $(this).find("option:selected").text() + '</p></span>');
        	_resultViewAreaId.find('#' + $(this).attr('id') + ':not(:first-child)').remove();
        	//let _t = _resultViewAreaId.find('#' + $(this).attr('id'));
        	//_t.parent().attr('class', fbviewcssNm);
        	//_t.parent().html($(this).find("option:selected").text());

        });
        
        //라디오 .
        _srcViewAreaId.find("input:checked").each(function (){
        	_resultViewAreaId.find("#" + $(this).attr('id') ).attr("checked","checked");
        });
        _resultViewAreaId.find("input[type=radio],input[type=checkbox]").each(function (){
        	$(this).attr("disabled", "disabled");
        	$(this).parent().removeAttr("for");
        });
        
        let orguser = "", orgdept = "", orgrecipt = "";
        //사용자 .
        _srcViewAreaId.find(".CPOrganize.user").each(function (){
        	
        	$(this).find('.oranText').map((i, itm) => { orguser = orguser.concat(",", $(itm).text()); });
        	_resultViewAreaId.find('[data-id='+ $(this).attr('data-id') +'] .splitBlock').html(
                    `<span ><p class="${fbviewcssNm}">${orguser.replace(',', '')}</p></span>`
                );

        });
        
        
        //부서.
        _srcViewAreaId.find(".CPOrganize.dept").each(function (){
        	
        	$(this).find('.oranText').map((i, itm) => { orgdept = orgdept.concat(",", $(itm).text()); });
        	_resultViewAreaId.find('[data-id='+ $(this).attr('data-id') +'] .splitBlock').html(
                    `<span ><p class="${fbviewcssNm}">${orgdept.replace(',', '')}</p></span>`
                );

        });

        //수신자 .
        _srcViewAreaId.find(".CPOrganize.recipient").each(function (){
        	
        	$(this).find('.oranText').map((i, itm) => { orgrecipt = orgrecipt.concat(",", $(itm).text()); });
        	_resultViewAreaId.find('[data-id='+ $(this).attr('data-id') +'] .splitBlock').html(
                    `<span ><p class="${fbviewcssNm}">${orgrecipt.replace(',', '')}</p></span>`
                );

        });
        
        //본문내용 .$('div[name=editorHideContent').html();
        _srcViewAreaId.find(".CPWebeditor").each(function () {

        	let _id = $(this).attr('data-id');
            let _eid = 'namo_' + $(this).attr('data-id');	//에디터 객체값.
            let _editorValue = "";
            
            //사이트 속도가 느릴때 실패가 가끔 생긴다.
            try{
            	_editorValue = window[_eid].editor.GetBodyValue();
            }catch(e){
            	alert("fail namoEditor get body value " +  e);
            }
            
            
            /*
             * 
            //namo data backup     
            _resultViewAreaId.find(".CPWebeditor").each(function () {  
            	console.log( "!!test" , _id , $(this).attr('data-id') );
        		if( _id == $(this).attr('data-id') ){      
        			
        			      
                    if( $(this).find("#_html").length > 0 ){
                    	$(this).find("#_html").html(_editorValue);                      	
                    }else{
                    	$(this).append("<div id='_html'>"+_editorValue+"</div>");  
                    }
                    
        			return false;        			
        		}        		
        	});   
             *
             */
            
            //namo data backup           
            if( $(this).find("#_html").length > 0 ){
            	$(this).find("#_html").html(_editorValue);  
            	
            }else{
            	$(this).append("<div id='_html'>"+_editorValue+"</div>");  
            }
            
            /*$('div[name=editorHideContent]').remove();
            _srcViewAreaId.append('<div name="editorHideContent" />');
            $('div[name=editorHideContent]').html(window[_eid].editor.GetBodyValue());*/
            
            //_resultViewAreaId.find("#" + _eid).before('<div id="'+ _eid +'" style=" ' + $(this).attr('style') + ' "><p>' + window[_eid].editor.GetBodyValue() + '</p></div>');
            //_resultViewAreaId.find('#' + _eid + ':not(:first-child)').remove();
            
            _resultViewAreaId.find('[data-id=' + $(this).attr('data-id') + ']').html( _editorValue );

        });
        _srcViewAreaId.find(".CPMultiWebeditor").each(function () {

            /**
             * 멀티에디터 공통처리 탭이동시 값보관 구현이후 
             * 처리보류.
             * 
             * */

        });
        
        /**
        _resultViewAreaId.find('#pv_AP_ADD_FILES').each(function () {
            $(this).html($('.fileName.F_12_black').text());
        });
        _resultViewAreaId.find('#pv_AP_REFERENCE_INPUT').each(function () {
            let refstr = $('.form-referencer-user.present-area').text();
            refstr = refstr.replace(/\\n|\\t/g, '');
            $(this).html(refstr);
        });
		**/
        
        //45gram
        //CPNumber
        _srcViewAreaId.find(".CPNumber input[type=number]").each(function () {
        	_resultViewAreaId.find('#' + $(this).attr('id')).before('<span id="'+ $(this).attr('id') +'" style=" ' + $(this).attr('style') + '" >' + CPView.moneyFormatter($(this).val()) + '</span>');
        	_resultViewAreaId.find('#' + $(this).attr('id') + ':not(:first-child)').remove();
        });
        
        
        //멀티텍스트 .
        _srcViewAreaId.find(".CPTextArea textarea").each(function () {
        	_resultViewAreaId.find('#' + $(this).attr('id')).before('<span id="'+ $(this).attr('id') +'" style=" ' + $(this).attr('style') + '" >' + $(this).val() + '</span>');
        	_resultViewAreaId.find('#' + $(this).attr('id') + ':not(:first-child)').remove();
        });
        
        
        
        
        
        /**
         * 각 컴포넌트의 불필요한 태그 정리.
         * 
         *
         */
        _resultViewAreaId.find(".alertmsg").each(function () {
            $(this).html('');
        });
        _resultViewAreaId.find("button").each(function () {
            $(this).remove();
        });

        _resultViewAreaId.find("input[type=hidden]").each(function () { 
        	
        	//결재선 관련 input값은 삭제에서 제외
        	if( $(this).attr("id").includes("editor_") ) return true;
            
        	$(this).remove();
        });
        _resultViewAreaId.find("button").each(function () {
            $(this).remove();
        });
        _resultViewAreaId.find("[aria-label=select]").each(function () {
            $(this).remove();
        });
        
        
        
        
        //CPCalculator 
        //계산식, 계산명 삭제
        _resultViewAreaId.find(".CPCalculator .calFrom, .CPCalculator .pv_table_id").each(function () {            	
        	$(this).remove();
        });

        _resultViewAreaId.find(".CPCalculatortotal .calFrom, .CPCalculatortotal .pv_table_id").each(function () {            	
        	$(this).remove();
        });

        _resultViewAreaId.find(".CPCalculatorglobaltotal .calFrom, .CPCalculatorglobaltotal .pv_table_id").each(function () {            	
        	$(this).remove();
        });

        _resultViewAreaId.find(".calculatorWrap #calSumWrap #preText").each(function () {            	
        	$(this).remove();
        });
        
        //계산식 <b>= </b> 볼드 태그 삭제
        _resultViewAreaId.find(".calculatorWrap .calSum > p > b").each(function () {            	
        	$(this).remove();
        });
        
        

        //CPCalculator 
        //add class
        _resultViewAreaId.find(".CPNumber.calculator , .CPCalculator , .CPCalculatortotal , .CPCalculatorglobaltotal").each(function () {            	
        	$(this).addClass(fbviewcssNm);
        });
        
        //기안일이 결재요청시 저장일로 변환될 수 있도록 대체변수 설정.
        _resultViewAreaId.find("#pv_CT_DRFT_DATE").each(function () {
        	$(this).html( "$CT_DRFT_DATE$" );
        });
        
        
        return _resultViewAreaId.html() ;

    }
    ,
    
    loadFileList: function () { // 연결된 첨부 파일 리스트 출력

        return new Promise((resolve, reject) => {

            let appr_doc_seq = CPView.GB_DOC_INFO.apprDocSeq;

            // #2217 취약점 관련 (첨부파일 조회 seq 암호화) start ----------------------------------------  
            let encApprDocSeq = approvalAtchFile.encryptSeq(appr_doc_seq);
            $.ajax({
                type: "POST",
                async: false,
                url: "/apr/docatchfilemap/atch",
                data: { "atch_seq": encApprDocSeq },
                success: function (data) {
                    var html = "";
                    for (var i = 0; i < data.length; i++) {
                        html += `<li>${abcUploadFileForm.convertIcon(data[i].atch_file_nm)}</li>`;
                    }
                    $("#aprShowFileMap").html(html);

                    resolve(html);
                }
            });
            // #2217 취약점 관련 (첨부파일 조회 seq 암호화) end ----------------------------------------
        });


    }
    ,
    revokeEditPreview() {

        this.target.html(CPView.targetHtml);
    }
    ,
    appendPrintButton() {

        $('#frmPrintArea').remove();

        $('.formbuilder_editedview ').before(
            `<h2 id="frmPrintArea"><span  id="formNm"></span>
			<button type="button" class="k-button" style="float:right" onclick="CPView.previewHtmlPrint()"><span class="o-icon o-i-print">인쇄</span></button>
		</h2>`
        );
    }
    ,
    previewHtmlPrint: function () {
        var previewHtml = $("#formbuilder_view").html();

        //폼빌더용 인쇄 페이지 전환위치.
        var test = window.open("/apr/doc/bfrAprPrint.jstl", "bfrAprPrint", "width=900, height=700, scrollbars=yes", "_blank");
        var frmObj = $('<form>', { 'id': 'frmPreview', 'action': '/apr/doc/bfrAprPrint.jstl', 'method': 'POST', 'target': 'bfrAprPrint', 'style': 'diplay:none' });
        var inpObj = $('<input>', { 'id': 'previewHtml', 'name': 'previewHtml', 'value': previewHtml, 'style': 'diplay:none' });
        frmObj.append(inpObj);
        $(document.body).append(frmObj);
        $('#frmPreview').submit();

        $('#frmPrintArea').remove();
    }
    ,
    async loadApprDocData(apprDocID=''){
    	
    	if(apprDocID == "") return false;    	
    	
    	let hiddenVal = "";
		
		await $.ajax({
        url: CPView.url.apprdoclist.replace("{{apprId}}",apprDocID),
        type: "get",
        data: [],
        success : function(res) {  	
			
            try {

                const obj = res;
                //const obj = JSON.parse( res );                
                
                if( obj.count > 0 ){                	
                	hiddenVal = obj.aprApprLine;                	
                	$("#editor_form_appr_line").val(obj.aprApprLine);                 	
                }               

                return true;
            } catch (e) {
                return false;
            } 
			
		}
			
        });
        
        return hiddenVal;
    
    }
    
    ,
    /**
     * 입력항목별 정규식 체크 및 최대길이 제한. 
     * text유형은 maxlength로도 기본 제한가능하지만 number는 길이 체크가 되지않음.
     * 아래 함수로 이벤트 처리해야되서..
     * 
     * 또한 항목에 따라 type이름으로 구분하여 정규식체크가 필요한 항목의 정규식을 추가해서 사용.
     * 
     * */
    pvTypeMaxLengthCheck(object, type, maxlendigit){
    	
    	if($(object) == undefined) return;
    	
    	if(type == undefined) type = 'text';
    	
    	let maxlen = null;
    	

        /***
         * 모의해킹 처리.
         * 
         * */
        
    	if(maxlendigit){
    		maxlen = maxlendigit;
    	}else{
    		maxlen = $(object).attr('maxlength');
    	}

        /***
         * 점검후 적용.
         * 관리자에서 적용한 값우선 체크.
         * 
    	if(maxlendigit){
    		maxlen = $(object).attr('maxlength');
    	}else{
    		maxlen =  maxlendigit;
    	}*/
    	/////////////////////////////////////////
    	
    	let thisobjval = $(object).val();
    	
    	if(type == 'number'){
    		//$(object).val( thisobjval.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1') );
    		$(object).val( thisobjval.replace(/[^0-9]/g, '') );
    	}
    	else if(type == 'currency'){
    		$(object).val( thisobjval.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '') );
    	}
    	
    	
        if ( thisobjval.length > maxlen){
          //object.maxLength : 매게변수 오브젝트의 maxlength 속성 값입니다.
        	
			layCmn.alert({
		        msg: `가능값을 초과했습니다. ${maxlen} 이하로 입력하세요.`,
		        callback: function (e) { 
		        	object.value = object.value.slice(0, maxlen);
		        }
		    });
          
        }    
      }
    
    ,
    /**
     * 입력 최대크기 제한 얼럿. 
     * 오직 숫자만 체크.
     * 
     * */
    pvTypeMaxSizeCheckAndAlert(object, maxsizedigit){
    	
    	if($(object) == undefined) return;
    	
    	let maxlen = null;
    	
    	let thisobjval = $(object).val();
    	CPCommon.console.log("pvTypeMaxSizeCheckAndAlert", $(object).attr('id') + " " + thisobjval);
    	
    	//only number
    	$(object).val( thisobjval.replace(/[^0-9]/g, '') );
    	
    	if(thisobjval == '') thisobjval = 0;
    	
    	if(!$.isNumeric(thisobjval)){
    		$(object).val(maxsizedigit);
    		return;
    	}
    	
    	
        if ( Number(thisobjval) > maxsizedigit){
        
        	layCmn.alert({
                msg: `가능값을 초과했습니다. ${maxsizedigit} 이하로 입력하세요.`,
                callback: function (e) { 
                	$(object).val(maxsizedigit);
                }
            });
           
        }
        
        
      }
}

