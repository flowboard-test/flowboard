let builderDocList = {
	pageSize : 10,
	currentPage : 1,
	popup_id :	'openDocPopup',	
	grid_outter :	'openDocGridOutter',
	getContentCheck: null,
	
	_oldContentLen : 0,
	
	initTemplate(){
		/*
		let htm = `<div id="openDocPopup" class="k-widget k-window" data-role="draggable" 
				    		style="scroll:auto; display:none;padding-top: 44px; min-width: 90px; min-height: 50px; width: 550px; top: 84.5px; left: 134.5px; touch-action: none; z-index: 50000; opacity: 1; transform: scale(1);">
				        <div class="k-window-titlebar k-header" style="margin-top: -44px;">
				            &nbsp;<span class="k-window-title" id="">기존양식 불러오기</span>
				            <div class="k-window-actions">
				                <a role="button" id="openDocPopClose" ><span class="k-icon k-i-close"></span></a>
				            </div>
				        </div>
						
				        <div id="openDocGridOutter" style="" data-role="window" class="layerpopup k-window-content k-content" tabindex="0" role="dialog" aria-labelledby="" >

			            <!-- 기본양식 불러오기 -->
			            
			
			            <!-- //기본양식 불러오기 -->
			
			        </div>
			    </div>`;
		
		$('#openDocPopup').remove();
		$('.formbdContainer').append($(htm));
		**/
	}
	,	
	onReady() {
		
		//this.initTemplate();
		
		CPCommon.cmmBlindOpen();

		builderDocList.initGrid();
		
		$('#openDocPopClose').on('click', function(e){
			
			builderDocList.close();

			CPCommon.cmmBlindClose();
			
		});
		
		let widowW = ($(window).width() / 2) - 100;
		
		$('#openDocPopup').css('top', 70 + 'px');
		$('#openDocPopup').css('left', widowW + 'px');
		$('#openDocPopup').show();
		$('#openDocPopup').draggable();
	},
	
	close(){
		
		$("#"+builderDocList.grid_outter).empty();
		$('#openDocPopClose').off('click');
		$('#openDocPopup').hide();
		
		CPCommon.cmmBlindClose();
	}
	,
	getURL(options) {

		url = "/cnfg/corp/apr/formbuilder/formlist.json?";
		
		if (typeof (options.data.sort) != "undefined" && options.data.sort.length > 0)
			url += "&sortField=" + options.data.sort[0].field + "&sortDirection=" + options.data.sort[0].dir;
		else{
			url += "&sortField=&sortDirection="
		}
		
		return url;
	},
	initGrid() {
		$("#"+this.grid_outter).empty();
		$("#"+this.grid_outter).html("<div id='goingDocGrid'></div>");
		
		gridDataSource = new kendo.data.DataSource({
			transport : {
				read : function(options) {
					$.ajax({
						url : builderDocList.getURL(options),
						data : options.data,
						contentType : "application/json",
						success : function(result) {
							var strResult = JSON.stringify(result);
							options.success(JSON.parse(abcValidCheck.getUnEscapeData(strResult)));
						},
						error : function(response, status, error){
							CPCommon.ajaxError(response, status, error);
						}
					});
				}
			},
			pageSize : builderDocList.pageSize,
			page : builderDocList.currentPage,
			serverPaging : true,
			serverSorting : true,
			schema : {
				data : "list",
				total : "count",
				model : {
					id : "formSeq",
					fields : {
						formSeq : {editable : false, nullable : true}
						,formTitle : {editable : false, nullable : true}
					}
				}
			}
		});
			
		appr_proc_cd_sortable = false;
		
		$("#goingDocGrid").kendoGrid({
			dataSource : gridDataSource,
			selectable : "row",
			sortable : true,
			resizable : true,
			scrollable : true,
			height: "636px",
			pageable : {
				refresh : true,
				pageSizes : [10, 15, 20, 25, 50 ,100],
				messages : {
					empty : $.i18n_json("PC.SCR.CMN_CM_H_001",0),//총 0건",
					display : $.i18n_json("PC.SCR.CMN_CM_H_002","{2}","{0}","{1}"),//총 {2}건 중 {0}-{1} 표시",
					itemsPerPage : ""
				},
				change : function(e) {
					var pager = $("#goingDocGrid").data("kendoGrid").pager;
					builderDocList.currentPage = pager.page();
					abcHashManager.setValue("page", builderDocList.currentPage);
					abcHashManager.setHash();
				}
			},
			columns : [
				
				{
					field : "formTitle",
					title : $.i18n_json("PC.SCR.CMN_C3_H_077"),//양식명",
					width : 200,
					headerAttributes : {style : "text-align: center; background-color: #f7f7f7; border-bottom: 1px solid #e1e1e1"},
					attributes : {style : "text-align: left" },
					template : '<a href="javascript:void(0);" onClick="builderDocList.getLoadContent(#=formSeq#)"> #=formTitle#</a>',
					sortable : true
				}
				,
				{
					field : "",
					width : 150,
					title : "선택",
					headerAttributes : {style : "text-align: center; background-color: #f7f7f7; border-bottom: 1px solid #e1e1e1"},
					template : `<div class="btn_wrap" style="margin-top:0px;" >
									<button class="k-button" onClick="builderDocList.getListPreview(#=formSeq#)">양식보기</button>
									<button class="mailsendBtn mL5" onClick="builderDocList.getLoadContent(#=formSeq#)">선택</button>
								</div>`,
					sortable : false
				}
				
			],
			dataBound : function(e) {
			}
		});
		
	}
	,
	getContent(formSeq){
		
		return new Promise((resolve, reject)=>{

			formSeq = CPCommon.encryptData(formSeq);
			//formSeq = encodeURIComponent(formSeq);
			
				
			$.ajax({
				type: "POST",
				url : '/cnfg/corp/apr/formbuilder/getformcont' ,
				
				data: {"id": formSeq},
				success : function(result) {
					resolve(result);
				},
				error : function(response, status, error){
					reject(error);
				}
			});
			
		});
		
	}
	,
	getLoadContent(formSeq){

		//45gram
		builderDocList.getContentCheck = "pending";
		
		//formSeq = CPCommon.encryptData(formSeq);
		
		builderDocList.getContent(formSeq)
		.then(function(strResult){
			
			//CPCommon.console.log("getContent result", strResult);
			
			if(strResult){

				CPElemParent.newDoc();
				CPCommon.createDocHorizon(GB_PROPS.bdview);
				
				let formC = $(strResult.formContent);
				
				GB_PROPS.bdview.append(formC);
				
				if(formC != null)
					builderDocList._oldContentLen = GB_PROPS.bdview.html().length;
				
				GB_CUR_STATE.DOC_ID = strResult.formSeq;

				CPView.GB_DOC_INFO.formBuilderSeq = strResult.formBuilderSeq;
				CPElemParent.setDocTitle(strResult.formTitle);
				
				//필수
				GB_CUR_STATE.docNo = strResult.docNoForm;
				GB_CUR_STATE.keepYy = strResult.keepYy;
				GB_CUR_STATE.keepMm = strResult.keepMm;
				GB_CUR_STATE.formNm = strResult.formTitle;
				GB_CUR_STATE.formDivCdSeq = strResult.formDivCdSeq;
				
				
				//45gram
				builderDocList.getContentCheck = "finished";
				
				builderDocList.close();
				
			}
			else{
				
				CPElemParent.checkAndGetDocInfo();
			}
			
		})
		.catch(function(error){ 
			
			let logerr = error;
			layCmn.alert({
                msg: "오류가 발생하였습니다.",
                callback: function (e) {}
        	});
			
		})
		;
		
	}
	,
	getRefLoadContent(formSeq){

		//45gram
		builderDocList.getContentCheck = "pending";
		
		this.getContent(formSeq)
		.then(function(strResult){
			
			//CPCommon.console.log("getContent result", strResult);
			
			if(strResult){

				CPElemParent.newDoc();
				CPCommon.createDocHorizon(GB_PROPS.bdview);
				
				let formC = $(strResult.formContent);
				
				GB_PROPS.bdview.append(formC);
				
				//45gram
				builderDocList.getContentCheck = "finished";
				
				builderDocList.close();
				
			}
			
		})
		.catch(function(error){ 
			
			let logerr = error;
			
		})
		;
		
	}
	,
	getListPreview(formSeq){
		
		//formSeq = CPCommon.encryptData(formSeq);
		
		this.getContent(formSeq)
		.then(function(strResult){
			
			CPCommon.console.log("getContent result", strResult);
			
			if(strResult){

				CPCommon.loadPreviewPopup(strResult.formContent);
				
			}
			
		})
		.catch(function(error){
			
			let logerr = error;
		})
		.finally(function(){ 
			
		})
		;
	}
};
