/**
 * 폼빌더 컴포넌트.
 * 
 * 여백 컴포넌트
 * 속성 : 높이
*/
let CPHeightGap = {

    CP_ID : null
    ,
    CP_TYPE : "CPHeightGap"
    ,
    CP_ITEM_TITLE : "여백"
    	
    ,
    MAX_SIZE : 200

    ,
    getAttrView(prop){

        let vwid = "att_tle";
        let template = `<div id="div_${vwid}" class="formbdTitle"><span>여백컴포넌트 속성</span></div>
                        <ul id="ul_${vwid}" class="formbdMenu">
                            
                            <li>
                                <p class="formbdMenuTit">여백 크기</p>
                                <div class="formbdMenuCon">
                                    
                                    <input id="cp_txheight" maxlength="${CPHeightGap.MAX_SIZE}" data-id="${this.CP_ID}" name="" style="width:70%;" class="k-textbox mL5" type="number" value="200" >
                                    <span>&nbsp;&nbsp;px</span>
                                    
                                </div>
                            </li>
                            
                        </ul>`;

        let $templ = $(template);

        $templ.find('#cp_txheight').on('input', function(txe){
        	
        	CPCommon.console.log('CPHeightGap input');
        	
        	CPView.pvTypeMaxSizeCheckAndAlert(this, CPHeightGap.MAX_SIZE)
        });

        return $templ;                
    }
    ,
    addCompo(prop){

        let template = this.getCpHtml(prop);
        
        let $attrview = CPHeightGap.getAttrView()

        CPElemParent.addComp({
            cptype: CPHeightGap.CP_TYPE
            ,cpid: this.CP_ID
            ,template: template
            ,vwtemplate: $attrview
        });                    
        
    }
    ,
    selectComp(prop){
        
        let $attrview = CPHeightGap.getAttrView()

        CPElemParent.selectComp({
            cptype: CPHeightGap.CP_TYPE
            ,cpid: prop.cpid
            ,vwtemplate: $attrview
            ,data_attr: prop.data_attr
        });                  
        
    }
    ,
    getCpHtml(prop){

        let cpid = null;

        if(prop && prop.cpid){
            cpid = prop.cpid;
        }else{
            cpid = this.createCpid();
        }
        
        this.CP_ID = cpid;
        
        return  `
        <div class="${this.CP_TYPE} previewoff tblformbdCon" id="${cpid}"><span>${CPHeightGap.CP_ITEM_TITLE}</span> <button type="button" class="k-button dltBtn groupTrash"></button></div>
        <div class='${this.CP_TYPE} previewon splitWrap' data-id="${cpid}"> 
            <div class="splitBlock">          

                <!-- 스크립트 입력 -->
                <div id="pv_${cpid}" style="width:100%;height:5px;" />


            </div>
        </div>
        `;

    }
    ,
    createCpid(){

        return CPHeightGap.CP_TYPE + '_' + Math.floor(Math.random() * 10000);

    }
    
    
}
