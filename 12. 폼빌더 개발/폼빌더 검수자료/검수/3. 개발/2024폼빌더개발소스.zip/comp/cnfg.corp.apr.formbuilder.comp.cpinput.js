/**
 * 폼빌더 컴포넌트.
 * 
 * 타이틀 컴포넌트
 * 
 * CPTitle = Input
 * 
*/
let CPInput = {

    CP_ID : null
    ,
    CP_TYPE : "CPInput"
    ,
    CP_ITEM_TITLE : "텍스트"

    ,
    MAX_LEN : 50
    ,
    getAttrView(prop){

        let vwid = "att_tle";
        let template = `<div id="div_${vwid}" class="formbdTitle"><span>텍스트 속성</span></div>
                        <ul id="ul_${vwid}" class="formbdMenu">
                            <li>
                                <p class="formbdMenuTit">필수입력</p>
                                <div class="formbdMenuCon">
                                    <div class="btnWrap">
                                        <label  for="toggle" class="toggleSwitchBtn off">
                                            <span id="cp_rdrequired" class="togglebtn"></span>
                                        </label>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <p class="formbdMenuTit">안내문구 (placeholder)</p>
                                <div class="formbdMenuCon">
                                    <input id="cp_txplacehold" maxlength="50" name="" style="width:100%;" class="k-textbox" type="text"  value="" placeholder="" disabled>
                                </div>
                            </li>
                            <li class="formbdTitle"></li>
                            <li>
                                <p class="formbdMenuTit">헤더</p>
                                <div class="formbdMenuCon">
                                    <div class="btnWrap">
                                        <label  for="toggle" class="toggleSwitchBtn cp_rdheaderToggle off">
                                            <span id="cp_rdheader"  data-id="${this.CP_ID}" class="togglebtn"></span>
                                        </label>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <p class="formbdMenuTit">헤더 입력값</p>
                                <div class="formbdMenuCon">
                                    <input id="cp_txheaderval" maxlength="${CPInput.MAX_LEN}" name="" data-id="${this.CP_ID}" disabled="disabled" style="width:100%;" class="k-textbox" type="text" value="">
                                </div>
                            </li>
                            <li>
                                <p class="formbdMenuTit">입력 가능 최대 글자 수</p>
                                <div class="formbdMenuCon">
                                    <input id="cp_txmaxlength" maxlength="3" name="cp_txmaxlength" style="width:100%;" class="k-textbox" type="number" value="${CPInput.MAX_LEN}">
                                    
                                </div>
                            </li>
                            <li>
                                <p class="formbdMenuTit">입력 너비</p>
                                <div class="formbdMenuCon">
                                    <div class="dropdownArea">
                                        <span  title="" class="k-widget k-dropdown k-header formbd_drop" unselectable="on" role="listbox" aria-haspopup="true" aria-expanded="false" tabindex="1" aria-owns="" aria-disabled="false" aria-busy="false" aria-activedescendant="b9638adf-c13e-4791-9aa7-7e060777ee7b" style="width: 60px;"><span unselectable="on" class="k-dropdown-wrap k-state-default">
                                        <span unselectable="on" class="k-input">%</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span></span>
                                        <input id="cp_txwidthUnit" style="width: 60px; display: none;" class="formbd_drop" name="formbd_drop" type="text" value="" data-role="dropdownlist"></span>
                                    </div>
                                    <input id="cp_txwidth" maxlength="3" name="" style="width:150px;" class="k-textbox mL5" type="number" value="100" >
                                    

                                    
                                    
                                </div>
                            </li>
                            
				        	<li>
				        	<p class="formbdMenuTit">경고문구</p>
				        	<div class="formbdMenuCon">
				        	<input id="cp_txalertmsg" maxlength="50" name="" style="width:100%;" class="k-textbox" type="text"  value="" placeholder="경고문구를 입력하세요.">
				        	</div>
				        	</li>
                            <li>
                                <p class="formbdMenuTit">글꼴</p>
                                <div class="formbdMenuCon">
                                    <span title="" class="k-widget k-dropdown k-header" style="width:100%;">
                                        <span unselectable="on" class="k-dropdown-wrap k-state-default">
                                            <span id="disp_cp_cbfont-family" unselectable="on" class="k-input">선택</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span>
                                        </span>
                                        <select id="cp_cbfont-family" data-role="dropdownlist" style="display: none;">
                                        </select>
                                    </span>
                                </div>
                            </li>
                            <li>
                                <p class="formbdMenuTit">정렬</p>
                                <div class="formbdMenuCon">
                                    <span title="" class="k-widget k-dropdown k-header" style="width:100%;">
                                        <span unselectable="on" class="k-dropdown-wrap k-state-default">
                                            <span id="disp_cp_cbtext-align" unselectable="on" class="k-input">왼쪽정렬</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span>
                                        </span>
                                        <select id="cp_cbtext-align" data-role="dropdownlist" style="display: none;">
                                            <option value="left" selected="selected">왼쪽정렬</option>
                                            <option value="center">가운데정렬</option>
                                            <option value="right">오른쪽정렬</option>
                                        </select>
                                    </span>
                                </div>
                            </li>
                            <li>
                                <p class="formbdMenuTit">글꼴 크기</p>
                                <div class="formbdMenuCon">
                                    <span title="" class="k-widget k-dropdown k-header" style="width:100%;">
                                        <span unselectable="on" class="k-dropdown-wrap k-state-default">
                                            <span id="disp_cp_cbfont-size" unselectable="on" class="k-input">18</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span>
                                        </span>
                                        <select id="cp_cbfont-size" data-role="dropdownlist" style="display: none;">
                                            <option value="12" selected="selected">12</option>
                                            <option value="14">14</option>
                                            <option value="16">16</option>
                                            <option value="18" >18</option>
                                            <option value="20">20</option>
                                            <option value="24">24</option>
                                        </select>
                                    </span>
                                </div>
                            </li>
                            
                        </ul>`;

        let $templ = $(template);
        
        $templ.find('#cp_txmaxlength').on('input',function (e) {
        	
        	CPView.pvTypeMaxSizeCheckAndAlert(this, CPInput.MAX_LEN);
            
        });
        
        return $templ;                
    }
    ,
    addCompo(prop){

        let template = this.getCpHtml(prop);
        
        let $attrview = CPInput.getAttrView()
        let fntselect = $attrview.find('#cp_cbfont-family');                    

        CPElemParent.getFontFamilySelect()
        .then((elem)=>{
            //console.log(elem)
            fntselect.append( elem );

            fntselect.kendoDropDownList();

            CPElemParent.addComp({
                cptype: CPInput.CP_TYPE
                ,cpid: this.CP_ID
                ,template: template
                ,vwtemplate: $attrview
            });
        });                    
        
    }
    ,
    selectComp(prop){

        let template = this.getCpHtml();
        
        let $attrview = CPInput.getAttrView()
        let fntselect = $attrview.find('#cp_cbfont-family');                    

        CPElemParent.getFontFamilySelect()
        .then((elem)=>{
            //console.log(elem)
            fntselect.append( elem );

            fntselect.kendoDropDownList();

            CPElemParent.selectComp({
                cptype: CPInput.CP_TYPE
                ,cpid: prop.cpid
                ,template: template
                ,vwtemplate: $attrview
                ,data_attr: prop.data_attr
            });
        });                    
        
    }
    ,
    getCpHtml(prop){

        let cpid = null;

        if(prop && prop.cpid){
            cpid = prop.cpid;
        }else{
            cpid = this.createCpid();
        }
        
        this.CP_ID = cpid;
        
        return  `
        <div class="${this.CP_TYPE} previewoff tblformbdCon" id="${cpid}"><span>${CPInput.CP_ITEM_TITLE}</span> <button type="button" class="k-button dltBtn groupTrash"></button></div>
        <div class='${this.CP_TYPE} previewon splitWrap' data-id="${cpid}"> 
            <div class="splitBlock">          

                <!-- 스크립트 입력 -->
                <input id="pv_${cpid}" name="텍스트" class="formbdMenuCon" maxlength="${CPInput.MAX_LEN}" style="width:100%;font-family:굴림;font-size:12px;" type="text" value="" placeholder=""  />
                <span id="pv_${cpid}alertmsg" class="alertmsg"/>


            </div>
        </div>
        `;

    }
    ,
    createCpid(){

        return CPInput.CP_TYPE + '_' + Math.floor(Math.random() * 10000);

    }
    
    
}
