/**
 * 폼빌더 컴포넌트.
 * 
 * 
*/
let CPDocInfo = {

    ALIAS_MAP : null
	,	
	MacroKeyNameMap : {
			
		//신규 개발 getaprdoc으로 조회되는 정보들.	
		AP_APPR_COMP_DTIME : { title: "완료일", varb: "" }
		,AP_FORM_NM : { title: "양식명", varb: "$AP_FORM_NM$" }
		,AP_DOC_NO_FORM : { title:"문서번호", varb: "" }
		,AP_OPEN_CD_LOCALE_NAME : { title:"공개여부", varb: "$AP_OPEN_CD_LOCALE_NAME$" }
		,AP_KEEP_YY : { title:"보존연한", varb: "$AP_KEEP_YY$ $AP_KEEP_MM$" }
			
		,AP_REFERENCE_INPUT : { title:"참조자", varb: "" }
		,AP_ADD_FILES : { title:"첨부파일"		, varb: "" }
		,AP_VIEWER_INPUT : { title:"조회자"		, varb: "" }
	}
	,
	init(prop){

		CPDocInfo.ALIAS_MAP = {};
		
        this.CP_MACRO_ALIAS = prop.alias;

	}
	,
    CP_ID : null
    ,
    CP_TYPE : "CPDocInfo"
    ,
    CP_ITEM_TITLE : null
    ,
    CP_MACRO_ALIAS : null 
    ,
    getAttrView(prop){

        let vwid = "att_tle";
        let template = '';

        let $templ = $(template);

        return $templ;                
    }
    ,
    addCompo(prop){

        this.init(prop);
        
        this.CP_ITEM_TITLE = CPDocInfo.MacroKeyNameMap[ prop.alias].title;

        let template = this.getCpHtml(prop);
        
        let $attrview = CPDocInfo.getAttrView()

        CPElemParent.addComp({
            cptype: CPDocInfo.CP_TYPE
            ,cpid: this.CP_ID
            ,template: template
            ,vwtemplate: $attrview
        });                    
        
    }
    ,
    selectComp(prop){

        this.init(prop);
        
        if(prop.cpid){
        	
        	let _ids = prop.cpid.split('_');
        	let _als = _ids[0].replace(this.CP_TYPE, '');
        	
        	this.CP_MACRO_ALIAS = _als;
        	prop.alias = _als;
        }
        
        let $attrview = CPDocInfo.getAttrView()

        CPElemParent.selectComp({
            cptype: CPDocInfo.CP_TYPE
            ,cpid: prop.cpid
            ,vwtemplate: $attrview
        });                  
        
    }
    ,
    getCpHtml(prop){

        let cpid = null;

        if(prop && prop.cpid){
            cpid = prop.cpid;
        }else{
            cpid = this.createCpid();
        }
        
        this.CP_ID = cpid;
        
        return  `
        <div class="${this.CP_TYPE} previewoff tblformbdCon" id="${cpid}"><span>${this.CP_ITEM_TITLE}</span> <button type="button" class="k-button dltBtn groupTrash"></button></div>
        <div class='${this.CP_TYPE} previewon splitWrap' data-id="${cpid}"> 
            <div class="splitBlock">          

                <!-- 스크립트 입력 -->
                <span id="pv_${this.CP_MACRO_ALIAS}" class="fb-view-tx-df">${ CPDocInfo.MacroKeyNameMap[ prop.alias].varb }</span>


            </div>
        </div>
        `;

    }
    ,
    createCpid(){

        return CPDocInfo.CP_TYPE + this.CP_MACRO_ALIAS + '_' + Math.floor(Math.random() * 10000);

    }
    
    
}
