/**
 * 폼빌더 컴포넌트.
 * 
 * 공통 컴포넌트
 * 
 */

const PreviewTagSet = {

    cptitle: 'div'
    , cpradio: 'radio'
}
/*
 * Macro key name map

const MacroKeyNameMap = {

	CT_DRFT_USR_NM : "기안자"
	,CT_DRFT_USR_EMAIL : "기안자이메일"
	,CT_DRFT_USR_POS : "직위"
	,CT_DRFT_USR_EMPY_NO : "사번"
	,CT_DRFT_USR_HP_NO : "휴대폰번호"
	,CT_CORP_TEL_NO : "회사연락처 직통전화"
	,CT_DRFT_DATE : "기안일"
} */

const CMM_ATTR_HTML = {

	fontFamily :`<li>
                    <p class="formbdMenuTit">글꼴</p>
                    <div class="formbdMenuCon">
                        <span title="" class="k-widget k-dropdown k-header" style="width:100%;">
                            <span unselectable="on" class="k-dropdown-wrap k-state-default">
                                <span id="disp_cp_cbfont-family" unselectable="on" class="k-input">선택</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span>
                            </span>
                            <select id="cp_cbfont-family" data-role="dropdownlist" style="display: none;">
                            </select>
                        </span>
                    </div>
                </li>`,
	textAlign : `<li>
                    <p class="formbdMenuTit">정렬</p>
                    <div class="formbdMenuCon">
                        <span title="" class="k-widget k-dropdown k-header" style="width:100%;">
                            <span unselectable="on" class="k-dropdown-wrap k-state-default">
                                <span id="disp_cp_cbtext-align" unselectable="on" class="k-input">왼쪽정렬</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span>
                            </span>
                            <select id="cp_cbtext-align" data-role="dropdownlist" style="display: none;">
                                <option value="left" selected="selected">왼쪽정렬</option>
                                <option value="center">가운데정렬</option>
                                <option value="right">오른쪽정렬</option>
                            </select>
                        </span>
                    </div>
                </li>`,
	fontColor : `<li>
                    <p class="formbdMenuTit">글꼴 크기</p>
                    <div class="formbdMenuCon">
                        <span title="" class="k-widget k-dropdown k-header" style="width:100%;">
                            <span unselectable="on" class="k-dropdown-wrap k-state-default">
                                <span id="disp_cp_cbfont-size" unselectable="on" class="k-input">18</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span>
                            </span>
                            <select id="cp_cbfont-size" data-role="dropdownlist" style="display: none;">
                                <option value="12" selected="selected">12</option>
                                <option value="14">14</option>
                                <option value="16">16</option>
                                <option value="18" >18</option>
                                <option value="20">20</option>
                                <option value="24">24</option>
                            </select>
                        </span>
                    </div>
                </li>`
};

let CPElemParent = {
		

    _treeDlbActionDELAY : 200, 
    _treeDlbActionTimer : null, 
    _treeDlbActionClickCnt : 0,
    
    _headerDefaultColor: '#f4f4f4',
    _bgDefaultColor: '#fff',
        	
    /**
	 * return $(element)
	 * 
	 * 기본 text input html
	 * 
	 * $(element)
	 */
    getInputElement(prop) {

        let $elem = $('<input />');

        // type require
        if (prop.type) {

            $elem.attr('type', prop.type);

            if (prop.pattern) {
                $elem.attr('pattern', prop.pattern);
            }
        }

        return $elem;
    }
    /**
	 * return $(element)
	 * 
	 * 기본 label html
	 * 
	 * $(element)
	 */
    ,
    getTitleElement(prop) {

        let $elem = $('<label />');

        // name require
        if (prop.name) {

            $elem.html(prop.name);

        }

        return $elem;
    }
    /**
	 * return promise then 구조의 데이터 처리필요.
	 * 
	 * 비동기 리턴 글꼴 데이터가 설정된 셀렉트
	 * 
	 * $(element)
	 */
    ,
    async getFontFamilySelect() {

        let selem = '';

        const res = await this.fetchFontData();

        const data = await res.json();

        // CPCommon.console.log('getFontFamilySelect', data);

        if (Array.isArray(data.fonts)) {

            data.fonts.map((item) => {

                selem = selem.concat(`<option value="${item.english}">${item.korean}</option>`);

            });
        }

        return selem;
    }
    ,
    fetchFontData() {

        return fetch('/resources/abc/js/cnfg/corp/comp/font.family.js');
    }
    ,
    validatorByType(chkval) {

        CPCommon.console.log('validatorByType chkval', chkval);
    }
    ,

    /**
	 * 공통 addComp 좌메뉴 클릭시
	 * 
	 */
    addComp(prop) {

        // 45gram
        const _CPTableAppend = CPTable.append(prop);
        if (_CPTableAppend.result == true) {

            if (_CPTableAppend.msg == "noEmpty" || _CPTableAppend.msg == "focusOut") {
                CPTable.alert(_CPTableAppend.msg);

                // @important
                return;
            }

        } else {

            GB_PROPS.bdview.append($(CPTable.templateWrap(prop)));
        }

        // GB_PROPS.bdview.append($(prop.template));

        this.setState(prop);
        
        CPCommon.checkAndExpandDoc(prop.cpid);
    }
    ,
    /***************************************************************************
	 * 
	 * 컴포넌트 신규, 선택시 실행
	 * 
	 * 1. 속성 뷰 생성
	 * 2. 속성 뷰에 컴포넌트 속성값 셋팅.
	 * 3. 속성뷰에서 선택한 값 컴포넌트에 적용처리 이벤트 연동.
	 * 
	 **************************************************************************/
    setState(prop) {
    	
        // 선택 컴포넌트 속성탭 셋팅.
        // 속성탭 변경 이벤트 처리.
        // 이전 속성이벤트 제거
        if (prop.initHander) prop.initHander();


        // 컴포넌트 추가전 초기화 및 이벤트 정리.
        CPElemParent.findElemAndRemoveEvent();

        GB_PROPS.attview.html('');


        GB_CUR_STATE.ATTR_VIEW_TYPE = prop.cptype;

        // 가로세로 컨트롤 공통뷰.
        CPCommon.createDocHorizon(GB_PROPS.bdview);
        // 배율 컨트롤 공통뷰.
        // CPCommon.targetDivZoom( GB_PROPS.attview, GB_PROPS.bdview)

        GB_PROPS.attview.append(prop.vwtemplate);
        
        if(prop.cmmattrarr)
        	this.commonAttrHtmlAppender(prop.cmmattrarr);

        GB_CUR_STATE.vwtemplate = prop.vwtemplate;

        // 선택 컴포넌트 아이디 셋팅.
        GB_CUR_STATE.CP_ID = prop.cpid;

        let curObj = $('#' + prop.cpid);

        // 선택상태 설정
        if (curObj) {
            // 45gram 퍼블변경으로 수정
            GB_PROPS.bdview.find('*').removeClass('on');
            curObj.addClass('on');
            /*
			 * GB_PROPS.bdview.find('*').removeClass('formbdOn');
			 * curObj.addClass('formbdOn');
			 */
        }
        
        // exist 속성뷰
        if(prop.vwtemplate != undefined 
        	&& prop.vwtemplate.html() != undefined) {}
        else{
        	GB_CUR_STATE.attrPropJson = {};
        	return;
        }
        
        /**
         * 속성 패널에 추가되는 태그가있는 처리는 
         * 
         * prop.vwtemplate.on('change' 전에 실행해야 변경이벤트를 처리할수있음.
         * color picker load
         * */
        if(prop.cptype == 'CPTitle'
        	|| prop.cptype == 'CPFormTitle'
        	|| prop.cptype == 'CPTitle'
        	|| prop.cptype == 'CPInput'
        	|| prop.cptype == 'CPTextArea'
        		|| prop.cptype == 'CPLabel'
                	
        ){
        	
        	CPElemParent.creatColorPicCmnButton();
        }
        if(prop.cptype == 'CPTitle'
        	|| prop.cptype == 'CPInput'
        	|| prop.cptype == 'CPTextArea'
        	|| prop.cptype == 'CPCurrency'
        	|| prop.cptype == 'CPNumber'	
        	|| prop.cptype == 'CPLabel'	
        		|| prop.cptype == 'CPMacro'	
        	){
        	
        	CPElemParent.commonAttrEventHandler(prop);
        }


        // CPElemParent.applyAttrToElem();
        if (prop.cp_attr_set_fn) {
            prop.cp_attr_set_fn(prop.data_attr);
        }
        else {

            //prop.vwtemplate.on('change', function (e) {
        	$(document).on('change', '.formbd_outBdr', function (e) {

        		CPCommon.console.log('변경점', e.target);
        		
                CPElemParent.changeAttrViewHandler(e);
            });

            this.applyElemToAttrView(prop);
        }
        
        //현재 속성뷰에 설정된 값을 json으로 저장.
        GB_CUR_STATE.attrPropJson = this.findElemAttrDataToJson();
        
        
        if(CPCommon.console.mode == 'debug'){
        	
        	CPCommon.console.log('this._headerDefaultColor', this._headerDefaultColor);
        	CPCommon.console.log('this.attrPropJson', GB_CUR_STATE.attrPropJson);
        }

        // test
        // CPElemParent.findElemAttrDataToJson();
        // CPElemParent.applyElemToAttrView('cp_txlength:100;cp_txfont-size:20;cp_cbalign:right;');
        // attr view data ==> setting element style

        // ///////////////////////////////////////

    }
    ,
    /***************************************************************************
	 * 
	 * 속성탭에서 선택한 값을 각 스타일 포맷으로 변환 컴포넌트에 적용.
	 * 
	 **************************************************************************/
    applyAttrToElem() {

        if (GB_CUR_STATE.CP_ID != null && GB_CUR_STATE.CP_ID != '') {

            let $target = $("#" + GB_CUR_STATE.CP_ID);
            let curAttrViewData = this.findElemAttrDataToJson();
            
            if (curAttrViewData) {

                let styleStr = this.convertAttrValsToStr(curAttrViewData);

                CPCommon.console.log("$target", $target)

                if ($target && $target.length > 0) {
                    // $target.attr('style',
					// this.trimNonStyleCharacter(styleStr));
                    CPElemParent.setStyleFromJson(curAttrViewData);
                    $target.attr('data_attr', styleStr);

                }
            }

        }

    }
    ,
    /***************************************************************************
	 * 
	  * json format data 읽어서 컴포넌트 미리보기 태그에 적용.
	 * 우측 속성탭에서 액션시 여기코드가 실행.
	 * 각 속성 아이디를 체크해서 스타일을 적용. 
	 * 
	 **************************************************************************/
    setStyleFromJson(json) {

        CPCommon.console.log('setStyleFromJson....json', json);
        
        this.defaultStyleApply();

        let keys = Object.keys(json); // 키를 가져옵니다. 이때, keys 는 반복가능한 객체가 됩니다.
        keys.map((key) => {

            let nm = CPElemParent.trimNonStyleCharacter(key);

            if ( nm != 'length' ) {

                let val = json[key];
                //val = this.validateStyleValue(key, val);

                let CPID = GB_CUR_STATE.CP_ID;
                let widthunit = 0;
                
                /**
                 * 매크로의 아이디에서 뒤의 숫자삭제후 앞의 치환이름만 사용.
                 * 
                 * **/
                if( CPID.includes('CPMacro') ){

                    let _CPID = CPID.replace("CPMacro","").split("_");

                    _CPID.pop();

                    CPID =  Array.isArray(_CPID)? _CPID.join("_"):_CPID;
                }

                switch(nm){
                    case 'width' : 
                            widthunit = $('#cp_txwidthUnit').val();
                            if (widthunit && widthunit.length > 0) {
                                val = val + widthunit;
                            }
                            break;
                    case 'height' : 
	                    	widthunit = $('#cp_txheightUnit').val();
	                    	if (widthunit && widthunit.length > 0) {
	                            val = val + widthunit;
	                        }
	                        break;        
                    case 'font-size' : 
                            val = val + 'px'; 
                            break;
                    case 'placehold' : 
                            $("#pv_" + CPID).attr('placeholder', val);
                            break;
                    case 'alertmsg' : 
                            
                    		if(val != '')
                    			$("#pv_" + CPID + "alertmsg").html('<span class="infomsg">*'  + val + '</span>');
                    		else
                    			$("#pv_" + CPID + "alertmsg").html('');
                            
                            break;
                    case 'header' : 
                    	
                    	 if (json.cp_rdheader == "on" || !CPCommon.isNotNull(json.cp_rdheader) ) {
                    		 
                    		// 헤더 CSS 적용.
                    		 
                    		 if(GB_CUR_STATE.ATTR_VIEW_TYPE == 'CPTextArea'){ 
                    			 $("#pv_" + CPID).html(json.cp_txheaderval);
                    		 }	
                    		 else{
                    			 $("#pv_" + CPID).attr("value", json.cp_txheaderval);
                    		 }	 
                    		
                    		
                    		$("#pv_"+ CPID).css({"border":"none", "background": this._headerDefaultColor});
                    		$("#pv_"+ CPID).parent().css( {"background": this._headerDefaultColor} );

                    		
                    	 }else{
                    		$("#pv_" + CPID).attr("value", "");
                    		$("#pv_"+ CPID).css({"border-width":"1", "background":	json['cp_cbbackground'] });
                    		//
                    		$("#pv_"+ CPID).parent().css( {"background": '#fff'} );
                    		
                    		
                    	 }
                            break;
                            
                    case 'required' : 
                        
                		if(val == 'required'){
                			
                			$("#pv_" + CPID).attr('required','on');
                			
                		}
                		else{
                			
                			$("#pv_" + CPID).removeAttr('required');

                		}
                        
                        break;
                    case 'maxlength' : 
                        
	            			$("#pv_" + CPID).attr('maxlength', val);
	                    
	                    break; 
                    case 'hmargin' : 
                        
                			$("#pv_" + CPID).css({"margin-top": val+"px", "margin-bottom": val+"px"});
                        
                        break;
                    default:
                            break;                                
                }
              
                /**
                 * 헤더옵션 on이면 헤더기본색상으로 고정해야하므로
                 * 글자배경색은 적용시키지 않는다.
                 * 
                 * **/
                if( $('.cp_rdheaderToggle').length > 0 
                	&& !$('.cp_rdheaderToggle').hasClass('off') && nm == 'background'){
                	//skip
                }
                else
                	$("#pv_" + CPID).css(nm, val);
            }

        });

    }
    ,
    defaultStyleApply(){
    	
    	$( '#pv_' + GB_CUR_STATE.CP_ID ).css({"width": "100%"});
    }
    ,
    /***************************************************************************
	 * 
	 * 저장된 속성값 json 불러와 
	 * 컴포넌트 속성뷰에 해당값은 셋팅.
	 * 
	 * 예) length:100px;width:150px;align:right;
	 * 
	 * 
	 ***********************************************************/
    applyElemToAttrView(prop) {
    	
    	CPCommon.console.log('applyElemToAttrView....prop', prop);

        let attrStr = prop.data_attr;

        if (attrStr == undefined || attrStr == '') return;

        // 컴포넌트쪽에서 보내준 처리함수가 있으면
        // cp_attr_set_fn 컴포넌트 개별 속성값처리 함수. 특이처리시.

        if (attrStr && attrStr.length > 0) {
        	
        	/**
        	 * 속성뷰에 읽어온 값셋팅이 먼저 이루어져야한다.
        	 * */

            attrStr.split(';').map((itm) => {

                if (itm && itm.length > 0) {
                    let itm2 = itm.split(':');

                    // itm2[0] = id, itm2[1] = value
                    let tobj = GB_PROPS.attview.find('#' + itm2[0]);

                    tobj.find('option').removeAttr('selected');

                    if (itm2[0] == 'cp_cbcolor') {
                    	$('#cp_cbcolor' ).attr( 'value', itm2[1] );
        				$('#cp_cbcolor' ).css( 'color', itm2[1] );
        				$('#cp_cbcolor' ).parent().parent().css( 'color', itm2[1] );
                    }
                    else if (itm2[0] == 'cp_cbbackground') {
                    	
                    	$('#cp_cbbackground' ).attr( 'value', itm2[1] );
        				$('#cp_cbbackground' ).parent().parent().css( 'background', itm2[1] );
                    
                    }
                    else if (itm2[0] == 'cp_txlabelval') {
                    	
                    	$('#cp_txlabelval' ).attr( 'value', itm2[1] );
                    	
                    }
                    else if (itm2[0] == 'cp_txhmargin') {
                    	
                    	$('#cp_txhmargin' ).attr( 'value', itm2[1] );
                    	
                    }
                    else if (itm2[0] == 'cp_txheightUnit' || itm2[0] == 'cp_txwidthUnit') {
                    	
                    	if('%' == itm2[1])
                    		$("#" + itm2[0]).data("kendoDropDownList").select(0);
                    	else
                    		$("#" + itm2[0]).data("kendoDropDownList").select(1);
                    }
                    else if ($(tobj).prop('tagName') == 'INPUT') {

                        tobj.val(itm2[1]);
                    }
                    else if ($(tobj).prop('tagName') == 'TEXTAREA') {

                        tobj.html(itm2[1]);
                    }
                    else if ($(tobj).prop('tagName') == 'SELECT') {

                        let choopt = tobj.find('option[value=' + itm2[1] + ']');
                        choopt.attr("selected", "selected");

                        $('#disp_' + itm2[0]).html(choopt.text());
                    }
                    
                }

            });

            if (attrStr.indexOf('cp_rdrequired') > -1) { }
            else { GB_PROPS.attview.find('#cp_rdrequired').parent('label').addClass('off'); }
            
            /**
        	 * 속성뷰에 값셋팅후 
        	 * 후처리
        	 * 먼저 셋팅된 값을 기반으로 액션이 필요한 컨트롤만 후처리.
        
        	 * */
            attrStr.split(';').map((itm) => {

                if (itm && itm.length > 0) {
                    let itm2 = itm.split(':');

                    if (itm2[0] == 'cp_rdheader') {

                        if (itm2[1] == 'off') {

                        	CPElemParent.attrHeaderOptionOnOff('off');

                        }
                        else {

                        	CPElemParent.attrHeaderOptionOnOff('on');

                        }
                    }
                    else if (itm2[0] == 'cp_rdheader') {

                        if (itm2[1] == 'off') {

                        	CPElemParent.attrHeaderOptionOnOff('off');

                        }
                        else {

                        	CPElemParent.attrHeaderOptionOnOff('on');

                        }
                    }
                    
                }

            });
            
        }

    }
    ,
    /***************************************************************************
	 * 
	 * 속성뷰 변경시 발생 이벤트 처리기.
	 * 태그종류별 체크.
	 * 
	 ***********************************************************/
    changeAttrViewHandler(e) {

    	CPCommon.console.log('changeAttrViewHandler')

        let $target = $(e.target);
        let elid = $target.attr("id");

        
        CPElemParent.applyAttrToElem();


        // 45gram
        CPTable.listenPareantChangeData($target);
        
      //변경된 속성뷰에 설정된 값을 json으로 저장.
        GB_CUR_STATE.attrPropJson = this.findElemAttrDataToJson();

    }
    ,
    /***************************************************************************
	 * 
	 * 헤더옵션 on/off 클릭시 처리기.
	 * 
	 ***********************************************************/
    attrHeaderOptionOnOff(act){
    	
    	if(act == 'on' ){
    	
    		$('#cp_rdheader').parent('label').removeClass('off');
    		
    		//헤더 옵션을 on하면 필수옵션은 off시켜야 함. 동시적용할 수 없음.
            //$('#cp_rdrequired').parent('label').addClass('off');
    		
    		GB_PROPS.attview.find('#cp_txplacehold').addClass('disabled');
            GB_PROPS.attview.find('#cp_txplacehold').attr('disabled', 'disabled');

            GB_PROPS.attview.find('#cp_txheaderval').removeAttr('disabled');
            GB_PROPS.attview.find('#cp_txheaderval').removeClass('disabled');
            
            $("#headerOnlyMsg").show();
            
            $("#pv_"+ GB_CUR_STATE.CP_ID).css({"border":"none"});
            
    		$('#pv_'+ GB_CUR_STATE.CP_ID ).css("background",	this._headerDefaultColor);
    		$('#pv_'+ GB_CUR_STATE.CP_ID ).parent().css({"border":"none", "background":	this._headerDefaultColor});
    		$('#pv_'+ GB_CUR_STATE.CP_ID ).parent().parent().addClass('header');
    		
    		$('#pv_'+ GB_CUR_STATE.CP_ID ).attr('disabled', 'disabled');
            
            $('#cp_rdheader').attr('value', "on");
            
            if(GB_CUR_STATE.ATTR_VIEW_TYPE == 'CPTextArea'){
            	
            	//$("#pv_"+ GB_CUR_STATE.CP_ID).html($('#cp_txheaderval').val());
            	$("#pv_"+ GB_CUR_STATE.CP_ID).html($('#cp_txheaderval').html());
            }
            else{
            	
            	$("#pv_"+ GB_CUR_STATE.CP_ID).attr('value',$('#cp_txheaderval').val());
            }
            
    	}
    	else{
    		//off
    		$('#cp_rdheader').parent('label').addClass('off');
    		
    		//GB_PROPS.attview.find('#cp_txplacehold').removeClass('disabled');
            //GB_PROPS.attview.find('#cp_txplacehold').removeAttr('disabled');

            GB_PROPS.attview.find('#cp_txheaderval').attr('disabled','disabled');
            GB_PROPS.attview.find('#cp_txheaderval').addClass('disabled');
            
            $("#headerOnlyMsg").hide();
            
            $("#pv_"+ GB_CUR_STATE.CP_ID).css({"border":"1px solid #ddd"});

    		$('#pv_'+ GB_CUR_STATE.CP_ID ).css("background",	GB_CUR_STATE.attrPropJson['cp_cbbackground']);
    		$('#pv_'+ GB_CUR_STATE.CP_ID ).parent().css({"border":"none", "background":	'#fff'});
    		$('#pv_'+ GB_CUR_STATE.CP_ID ).parent().parent().removeClass('header');

    		$('#pv_'+ GB_CUR_STATE.CP_ID ).removeAttr('disabled');
            
            $('#cp_rdheader').attr('value', "off");
            
            if(GB_CUR_STATE.ATTR_VIEW_TYPE == 'CPTextArea'){
            	
            	$("#pv_"+ GB_CUR_STATE.CP_ID).html('');
            }
            else{
            	
            	$("#pv_"+ GB_CUR_STATE.CP_ID).val('');
            }
    	}
    }
    ,
    /***************************************************************************
	 * 
	 * 필수옵션 on/off 클릭시 처리기.
	 * 
	 ***********************************************************/
    attrRequireOptionOnOff(act){
    	
    	if(act == 'on'){
    		
    		$('#cp_rdrequired').parent('label').removeClass('off');
    		
    		$('#cp_txplacehold').attr('placeholder','필수값 입니다.');
    		$('#pv_' + GB_CUR_STATE.CP_ID ).attr('placeholder','필수값 입니다.');
    		$('#cp_rdrequired').attr('value','on');
    		
    		$("#pv_"+ GB_CUR_STATE.CP_ID + "alertmsg").val('<span class="infomsg">*필수항목입니다.</span>');
    		//$("#cp_txalertmsg").val('필수항목입니다.');
    		
    		$('#cp_txplacehold').removeClass('disabled');
            $('#cp_txplacehold').removeAttr('disabled', 'disabled');
    	}
    	else{
    		//off
    		$('#cp_rdrequired').parent('label').addClass('off');
    		
            $('#cp_txplacehold').attr('placeholder','');
            $('#pv_' + GB_CUR_STATE.CP_ID ).attr('placeholder','');
            $('#cp_rdrequired').attr('value','off');
            
            $("#pv_"+ GB_CUR_STATE.CP_ID + "alertmsg").val('');
            //$("#cp_txalertmsg").val('');
            
            $('#cp_txplacehold').addClass('disabled');
            $('#cp_txplacehold').attr('disabled', 'disabled');
    	}
    }
    ,
    commonAttrHtmlAppender(cmmAttrArr ){
    	
    	if(Array.isArray( cmmAttrArr )){
    		
    		$(cmmAttrArr).each(function(i, itm){
    			
    			$('#ul_att_tle').append(CMM_ATTR_HTML[itm]);
    		});
    		
    	}
    	
    }
    ,
    /***************************************************************************
	 * 
	 * 속성뷰 이벤트 공통 초기화 및 처리기.
	 * 
	 ***********************************************************/
    commonAttrEventHandler(prop){
    	
    	let $templ = GB_PROPS.attview;
    	
    	/**
    	 * 라디오 속성 핸들러
    	 * **/
    	$(document).on('click', 'label.toggleSwitchBtn', function (e) {
           
    		/**
        	 *	헤더옵션 속성 핸들러
        	 * **/
    		if($(this).children('span').attr('id') == 'cp_rdheader'){
    			
    			if(	$(this).hasClass('off')){
                	
    				CPElemParent.attrHeaderOptionOnOff('on');
                    CPElemParent.attrRequireOptionOnOff('off');

                }
                else{

                    CPElemParent.attrHeaderOptionOnOff('off');
                    
                }
    			
    			//$('#cp_rdheader').trigger( 'change' );
    		}
    		/**
        	 * 필수옵션 속성 핸들러
        	 * **/
    		else if($(this).children('span').attr('id') == 'cp_rdrequired'){
    			
    			if( $(this).hasClass('off')){
                    
    				CPElemParent.attrRequireOptionOnOff('on');
    				CPElemParent.attrHeaderOptionOnOff('off');
                    
                }
                else{

                    CPElemParent.attrRequireOptionOnOff('off');
                }
    			
    			//$('#cp_rdrequired').trigger( 'change' );
    			
    		}
    		
    		
        });
    	/**
    	 * 헤더입력 속성 핸들러
    	 * **/
        $(document).on( 'keyup', '#cp_txheaderval',function(txe){

            let txcpid = $(txe.target).attr('data-id');

            let inputval = $(txe.target).val();
            let maxlen = Number( $('#cp_txmaxlength').val());
            if(inputval ){

                CPCommon.console.log('key event header text..11..', inputval);
                CPCommon.console.log('leng text....', inputval.length);
                CPCommon.console.log('find text....', $('#cp_txheaderval').length);

                if(inputval.length > maxlen){

                    let restr = inputval.substr(0, maxlen);
                    
                    if(GB_CUR_STATE.ATTR_VIEW_TYPE == 'CPTextArea'){
                    	$('#cp_txheaderval').html(restr);
                    }
                    else{
                    	
                    	$('#cp_txheaderval').val(restr);
                    }
                    

                    layCmn.alert({
                        msg: "입력가능 최대 글자 수 이하로 입력하세요.",
                        callback: function (e) { }
                    });

                   
                    return;
                }

                //$("#"+GB_CUR_STATE.CP_ID).html($(e.target).val());
                //45gram
                $("#pv_" + txcpid).removeAttr("value");
                
                if(prop.cptype == 'CPTextArea'){
                	
                	$("#pv_"+ prop.cpid).html(inputval);
                }
                else{
                	
                	$("#pv_"+ prop.cpid).attr( "value", inputval);
                }
            }
            
            CPElemParent.changeAttrViewHandler(txe);
            
        });
    	
    	/**
    	 * 너비 속성 핸들러
    	 * **/
        $(document).on( 'keyup', '#cp_txwidth',function (e) {
            
            CPElemParent.changeAttrViewHandler(e);
        });
        
        /**
    	 * 경고문구 속성 핸들러
    	 * **/
        $(document).on( 'keyup', '#cp_txalertmsg',function(txe){

            let inputval = $(txe.target).val();
            let maxlen = Number( $(this).val());
            if(inputval ){

                if(inputval.length > 100){

                    let restr = inputval.substr(0, 100);
                    
                    $(this).val(restr);
                    

                    layCmn.alert({
                        msg: "입력가능 최대 100 글자 수 이하로 입력하세요.",
                        callback: function (e) { }
                    });

                   
                    return;
                }

                
            }

            
        });
        
        $(document).on( 'change', '#cp_txwidthUnit',function(txe){
            CPElemParent.checkNumberLimit();
        });

        $(document).on( 'keyup', '#cp_txwidth',function(txe){
            CPElemParent.checkNumberLimit();
        });

        $(document).on( 'click', '#cp_txwidth',function (e) {
            CPElemParent.checkNumberLimit();
        });


        let fntselect2 = $templ.find('#cp_cbfont-size');
        let fntselect3 = $templ.find('#cp_cbtext-align');

        fntselect2.kendoDropDownList();
        fntselect3.kendoDropDownList();
        
        var data = [
            { text: "%", value: "%" },
            { text: "px", value: "px" },
            //{ text: "em", value: "2" },
        ];
        /**
    	 * 단위 속성 핸들러
    	 * **/
        $templ.find("#cp_txwidthUnit").kendoDropDownList({
            dataTextField: "text",
            dataValueField: "value",
            dataSource: data,
            index: 0
        });
        $templ.find("#cp_txheightUnit").kendoDropDownList({
            dataTextField: "text",
            dataValueField: "value",
            dataSource: data,
            index: 0
        });
    	
    }
    ,
    /***************************************************************************
	 * 
	 * 입력 너비가 %인 경우 100을 넘지 못하게 한다.
	 * 
	 ***********************************************************/
     checkNumberLimit(){

         const _cp_txwidth = $("#cp_txwidth");
         const _cp_txwidthUnit = $("#cp_txwidthUnit");
         const _limit = 100;

         if( _cp_txwidth.length > 0 && 
             _cp_txwidthUnit.length > 0 && 
             _cp_txwidthUnit.val() =='%' && 
             $.isNumeric(_cp_txwidth.val()) && 
             Number(_cp_txwidth.val()) > _limit
         ){

             layCmn.alert({
                 msg: `입력 너비의 단위가 퍼센트('%')인 경우에는 ${_limit}%를 넘을 수 없습니다.`,
                 callback: function (e) { }
             });

             _cp_txwidth.val(_limit);
         }
     }
     ,
     /***************************************************************************
 	 * 
	 * 공통 selectComp 이미 배치된 컴포넌트 선택시
 	 * 
 	 ***********************************************************/
    selectComp(prop) {

        // 45gram
        CPTable.updatelistener(prop);

        this.setState(prop);

    }
    ,
    /***************************************************************************
 	 * 
	 * 편집완료
 	 * 
 	 ***********************************************************/
    clickSaveBtn(isCloseExec) {

        if(!this.validateSave()){

            return;
        }
        
        function saveExec() {

            let title = CPElemParent.getDocTitle();
            let content = CPCommon.collectRreviewHtml();
            
            let buildCont = GB_PROPS.bdview.html();
            let formSeq = GB_CUR_STATE.DOC_ID;
            
            formSeq = CPCommon.encryptData( formSeq );
            
            let data = { 
            		"formDivCdSeq": GB_CUR_STATE.formDivCdSeq
            		,"formSeq": formSeq
            		
            		,"docNo": GB_CUR_STATE.docNo
            		,"keepYy": GB_CUR_STATE.keepYy
            		,"keepMm": GB_CUR_STATE.keepMm
            		, "formContent": encodeURIComponent(buildCont)
            		, "previewCont": encodeURIComponent(content)
//            		, "formContent": encodeURIComponent(`<div onload="alert(1);" onclick="alert(1);" onkeydown="alert(1);" onmouseover="alert(1);">TESTSETSEETSETSETSETSET</div>`)
//            		, "previewCont": encodeURIComponent(`<div onload="alert(1);" onclick="alert(1);" onkeydown="alert(1);" onmouseover="alert(1);">TESTSETSEETSETSETSETSET</div>`)

            		, "formTitle": title };
            
            $.ajax({
                type: "POST",
                url: "/cnfg/corp/apr/formbuilder/save",
                data: data,
                success: function (result) {
                    if ('SUCCESS' == result.result) {
                    	
                    	GB_CUR_STATE.DOC_ID = result.data.formSeq;
                        CPView.GB_DOC_INFO.formBuilderSeq = result.data.formBuilderSeq;	//cpview

                        layCmn.alert({
                            msg: "저장되었습니다.",
                            callback: function (e) {
                            	
                            	builderDocList._oldContentLen = buildCont.length;
                            	
                            	//부모창이 존재할 경우만.
                            	if(GB_PROPS.canReadParent){
                            		
                            		// 부모 수정페이지로 리로딩해줌.
                            		if( parent && parent.opener && parent.opener.cnfgCorpAprHome ){
                            			parent.opener.cnfgCorpAprHome.loadHtml_tabConts(1, "/cnfg/corp/apr/form/"+ result.data.formSeq +"/edit.jstl");
                            		}
                            		if(isCloseExec){
                            			parent.window.close();
                            		}
                            	}
                            	
                            }
                        });
                    }
                    else{
                    	layCmn.alert({
                            msg: "저장이 실패하였습니다.",
                            callback: function (e) {}
                    	});    	
                    }
                }
            });
        }
        
        if(isCloseExec){
        	
        	CPElemParent.findDupFormTitle(CPElemParent.getDocTitle())
            .then(count=>{
            	
            	if(count > 0){
            		layCmn.alert({
                        msg: '다른 양식과 중복된 양식명입니다.',
                        callback: function (result) {if (!result) return;}
            		});
                        
            	}
            	else{
            		
            		saveExec();
            	}
            	
            });
        	
        	
        }
        else{
        	
        	layCmn.confirm({
                msg: '저장하시겠습니까?',
                callback: function (result) {
                    if (!result) return;
                    
                    CPElemParent.findDupFormTitle(CPElemParent.getDocTitle())
                    .then(count=>{
                    	
                    	if(count > 0){
                    		layCmn.alert({
                                msg: '다른 양식과 중복된 양식명입니다.',
                                callback: function (result) {if (!result) return;}
                    		});
                                
                    	}
                    	else{
                    		
                    		saveExec();
                    	}
                    	
                    });

                }
            });
        	
        }


    }
    ,
    /***************************************************************************
 	 * 
	 * 관리자 화면에서 취소시 임시저장상태 양식 삭제.
 	 * 
 	 ***********************************************************/
    removeFunc(formSeq) {

    	function rmExec() {

            let data = {"formSeq": formSeq};
            
            $.ajax({
                type: "POST",
                url: "/cnfg/corp/apr/formbuilder/remove",
                data: data,
                success: function (result) {
                    if ('SUCCESS' == result) {
                    	
                        layCmn.alert({
                            msg: "삭제되었습니다.",
                            callback: function (e) {
                            	parent.close();
                            }
                        });
                    }
                }
            });
        }

        layCmn.confirm({
            msg: '삭제하시겠습니까?',
            callback: function (result) {
                if (!result) return;
                
                rmExec();

            }
        });

    }
    ,
    /***************************************************************************
 	 * 
	 * 양식명 중복체크.
 	 * 
 	 ***********************************************************/
    findDupFormTitle(formTitle){
		
		return new Promise((resolve, reject)=>{
			
			let _data = {"formTitle": formTitle };
			
			if( CPCommon.isNotNull(GB_CUR_STATE.DOC_ID) ){
				
				_data.formSeq = GB_CUR_STATE.DOC_ID;
			}
				
			$.ajax({
				type: "POST",
				url : '/cnfg/corp/apr/formbuilder/findDupFormTitle',
                data: _data,
				success : function(result) {
					resolve(result);
				},
				error : function(response, status, error){
					reject(error);
				}
			});
			
		});
		
	}
    ,
    validateSave(){

        let title = $('.topSearchArea input').val();
        let content = CPCommon.collectRreviewHtml();
        let CPApprovalline = $('.formbdEditView .CPApprovalline'); 

        if(title == undefined | title.length == 0){
            
            layCmn.alert({
                msg: '양식명은 필수 입니다.',
                callback: function (e) { }
            });
    
            return false;
        }
        if(CPApprovalline.length == 0){

            layCmn.alert({
                msg: '결재선은 필수 입니다.',
                callback: function (e) { }
            });
    
            return false;
        }
        if(content == undefined | content.length == 0){
            
            layCmn.alert({
                msg: '저장할 내용이 없습니다.',
                callback: function (e) { }
            });
    
            return false;
        }
        if(GB_PROPS.bdview.find('.CPTitle').length== 0){
            
            layCmn.alert({
                msg: '제목 컴포넌트는 필수 입니다.',
                callback: function (e) { }
            });
    
            return false;
        }
        
        return true;
    }
    ,
    // 새문서, 문서기본정보모두 클리어함.
    newDoc() {

        CPElemParent.findElemAndRemoveEvent();

        GB_PROPS.bdview.html('');
        GB_PROPS.attview.html('');
        
        GB_CUR_STATE.DOC_ID = null;
		GB_CUR_STATE.docNo = null;
		GB_CUR_STATE.keepYy = null;
		GB_CUR_STATE.keepMm = null;
        
        CPView.GB_DOC_INFO = {
			formTitle : '',
			apprDocSeq : 0,
			formBuilderSeq : 0
        };
        
        this.setDocTitle('');
    }
    ,
    /***************************************************************************
 	 * 
	 * 초기화 , 문서기본정보는 클리어안함.
 	 * 
 	 ***********************************************************/
    initForm() {

        CPElemParent.findElemAndRemoveEvent();

        GB_PROPS.bdview.html('');
        GB_PROPS.attview.html('');
        
        CPCommon.createDocHorizon(GB_PROPS.bdview);
    }
    ,
    /***************************************************************************
 	 * 
	 * 속성뷰의 태그를 검색하면서 선택값을 모음.
	 * 
	 * 
 	 * 
 	 ***********************************************************/
    findElemAttrDataToJson() {

        let attrdata = {};
        let childrens = GB_PROPS.attview.find("[id^=cp_]");

        childrens.each((idx, item) => {

            let attnm = $(item).attr('id');

            if ('cp_rdrequired' == attnm) {

                attrdata[attnm] = $(item).attr('value');

            }
            else if ('cp_rdheader' == attnm) {
            	
            	attrdata['cp_rdheader'] = $(item).attr('value');
            	
            	if($(item).attr('value') == 'on'){
            	
	            	if(GB_CUR_STATE.ATTR_VIEW_TYPE == 'CPTextArea'){ 
	                	
	            		attrdata['cp_txheaderval'] = $(item).html();
	            	
	            	}
	            	else{
	            		
	            		attrdata['cp_txheaderval'] = $(item).attr('value');
	            	}
            	
            	}
            }
            else {
                // 값이 있는 속성만 수집.
                if ($(item) && $(item).val() && $(item).val().length > 0) {

                    // 45gram
                    if (attnm == "cp_cbtext-align") {
                        attrdata["cp_cbjustify-content"] = $(item).val();
                    }

                    attrdata[attnm] = $(item).val();
                }
                else {

                    attrdata[attnm] = '';
                }
            }


        });

        CPCommon.console.log(attrdata);
        return attrdata;
    }
    ,
    /***************************************************************************
	 * json -> str 선택된 컴포넌트의 속성값 파싱 각 컴포넌트의 getView prop로 사용. 예)
	 * length:100px;width:150px;align:right;
	 * 
	 * return str
	 * 
	 */
    convertAttrValsToStr(json) {

        let str = "";
        let keys = Object.keys(json); // 키를 가져옵니다. 이때, keys 는 반복가능한 객체가 됩니다.
        keys.map((key) => {

            // if (key.indexOf('font-size') > 0)
            // json[key] = json[key] + "px";

            str = str.concat(key + ":" + json[key] + ";");
        });

        CPCommon.console.log("str", str)
        return str;
    }
    ,
    parseDataAttrToJson(data_attr) {

        let json = {};

        if (data_attr && data_attr.length > 0) {

            data_attr.split(';').map((itm) => {

                let oitm = itm.split(':');
                json[oitm[0]] = oitm[1];
            });

        }
        return json;
    }

    ,
    trimNonStyleCharacter(str) {

        if (str) {
            str = str.replace(/cp_|tx|cb|rd|/g, '');
        }
        return str;
    }
    ,
    findElemAndRemoveEvent() {

        let elems = GB_CUR_STATE.vwtemplate;

        if (elems == undefined || elems == "") return;

        //elems.off('change');
        $(document).off('change', '.formbd_outBdr');
        $(document).off('click', 'label.toggleSwitchBtn');

        elems.find('[id^=cp_]').each(function (i, item) {

            $(this).off('dropdown');
            $(this).off('click');
            $(this).off('change');
            $(this).off('keyup');

            $(document).off('click', '#' + $(this).prop("id"));
            $(document).off('change', '#' + $(this).prop("id"));
            $(document).off('keyup', '#' + $(this).prop("id"));

        });

        elems.find('[id^=BTN_]').each(function (i, item) {

            CPCommon.console.log('e', item)

            $(this).off('click');

        });
    }
    ,
    treeDoubleClickAction(callback){
    	
    	let delay = CPElemParent._treeDlbActionDELAY;
    	
        var funcClick = function() {
            
            callback();
            
            CPElemParent._treeDlbActionClickCnt = 0;
        };
        
        var funcDblClick = function() {
            clearTimeout(CPElemParent._treeDlbActionTimer);
            
            CPElemParent._treeDlbActionClickCnt = 0;
        };
        
        if(CPElemParent._treeDlbActionClickCnt == 1){
        	
        	CPElemParent._treeDlbActionTimer = setTimeout( callback, delay ) ;
        	funcClick();
        }
        else{
        	funcDblClick();
        }
    }
    ,
    initOragnizeDeptDlbClickTree(idtarget){
    	
    	let curNode = null;
    	
    	function dispdata(){
    		
    		let curApplyInput = "#"+CPElemParent._curOrgPopId + "_input";
			let curApplyvals = "#"+CPElemParent._curOrgPopId + "_hidd";
			

			let dispVal = $('#previewArea').find(curApplyvals).prop('value'); 
			
			if( dispVal && dispVal.indexOf(curNode.key) > -1 ){
				
				return;
			}
			//하위값을 가진 부서는 트리가 펼쳐진 상태에서만 값을 클릭으로 선택가능.
			if( !curNode.expanded && curNode.hasChildren ){
				
				return;
			}

			let beforestr = $('#previewArea').find(curApplyInput).val();
            let beforevals = $('#previewArea').find(curApplyvals).val();
            
            if(beforestr && beforestr.length > 0){
            	$('#previewArea').find(curApplyInput).val( beforestr + "," + curNode.text );
            	$('#previewArea').find(curApplyvals).val( beforevals + "," + curNode.key );
            }
            else{
            	$('#previewArea').find(curApplyInput).val(curNode.text);
            	$('#previewArea').find(curApplyvals).val(curNode.key);
            }
            
    	}
    	
    	let dtree = '.treeDeptContainer';
    	
    	var tree = new UserOrganization({
			treeId: "treeDept", 
			options: "department.virtual=false&user.displayed=false", 
			callback: function(node){
				

		    	CPElemParent._treeDlbActionClickCnt++;

				curNode = node;
				CPElemParent.treeDoubleClickAction(dispdata) ;
				//$(idtarget).fadeToggle();
			}
		});
    	
    	//$(treeId).data("kendoTreeView")\

		tree.paint( $(dtree) );
		
		
		return tree;
    }
    /***************************************************************************
	 * 자동항목 매크로 치환 치환 api
	 * http://abcdev.onnet21.com/cnfg/corp/apr/form/previewEditMacroTagChange.json
	 * $$CT_DRFT_USR_DEPT$$CT_DRFT_USR_EMAIL$$CT_DRFT_USR_POS$$CT_DRFT_USR_EMPY_NO$$CT_DRFT_USR_HP_NO$$CT_CORP_TEL_NO$$CT_DRFT_DATE$$
	 * 
	 * 기안자이름 $CT_DRFT_USR_NM$ 기안자이메일 CT_DRFT_USR_EMAIL 기안자직위 CT_DRFT_USR_POS
	 * 기안자사번 CT_DRFT_USR_EMPY_NO 휴대폰번호 CT_DRFT_USR_HP_NO 회사연락처 CT_CORP_TEL_NO
	 * 기안일 CT_DRFT_DATE
	 * 
	 * 
	 * 
	 **************************************************************************/
    ,
    getMacroTagChangeAllHtml(cont){
    	
    	let formData = []; //
    	
        return new Promise((resolve, reject)=>{
        	
	    	formData.push({"name": "cont", "value": cont });
	    	
			function fetchParseVar(callbackFn){
				
				return $.ajax({
					type: "post",
					url: "/cnfg/corp/apr/form/previewEditMacroTagChange.json",
					data: formData,
					success: function(result) {
						
						return result.cont;
					}
				});
			}
	    	
			fetchParseVar()
			.then(data => {
					
				if(data.cont){
					
					resolve( data.cont );
				}
				else{
					console.log('getMacroTagChangeAllHtml', 'no result');
					reject( false )
				}
			});
		
        });
	    	
    }// getMacroTagChangeData end

	,
	getDocTitle(){
	
		return $('#doc_title_input').val();
	}
	,
	setDocTitle(title){

		$('#doc_title_input').val(title);
	}
	,
	/*
	 * 부모창정보를 읽을수 있을때
	 * 
	 * */
	checkAndGetDocInfo(){
    		
		GB_PROPS.parentObj = parent.opener.document;
		
		//필수
		GB_CUR_STATE.docNo = $('#doc_no_form_display', GB_PROPS.parentObj).val();
		//필수
		GB_CUR_STATE.keepYy = $('#keep_yy', GB_PROPS.parentObj).val();
		GB_CUR_STATE.keepMm = $('#keep_mm', GB_PROPS.parentObj).val();
		
		if(!CPCommon.isNotNull(GB_CUR_STATE.docNo, '문서번호')){
			
			GB_CUR_STATE.docNo = "제 경영 신청  -";
		}
		
		
		if(!CPCommon.isNotNull(GB_CUR_STATE.keepYy, '보존연한')){
			
			GB_CUR_STATE.keepYy = "1";
		}
		
		GB_CUR_STATE.DOC_ID = $('#form_seq', GB_PROPS.parentObj).val();
		
		GB_CUR_STATE.formNm = $('#form_nm', GB_PROPS.parentObj).val();
    	
		GB_CUR_STATE.formDivCdSeq = $('#form_div_cd_seq', GB_PROPS.parentObj).val();
		
		CPElemParent.setDocTitle(GB_CUR_STATE.formNm);
	}
	,
	/***************************************************************************
	 * 
	 * 공통 색상 선택 레이어.
	 * 
	 **************************************************************************/
	creatColorPicker(){ 
    	
    	let colorpicPanel = `
    			<ul id="panelBar_LblCnfgBx" style="display:none; z-index:30000; position:absolute; top: 720px; left: 1072px; ">
				        <li>
				            <ul class="colorPicker">
				                <li data-cd="01" data-color="#a02031" style="background-color: rgb(160, 32, 49);"></li>
				                <li data-cd="02" data-color="#f35055" style="background-color: rgb(243, 80, 85);"></li>
				                <li data-cd="03" data-color="#eb8a9f" style="background-color: rgb(235, 138, 159);"></li>
				                <li data-cd="04" data-color="#fbc9d3" style="background-color: rgb(251, 201, 211);"></li>
				                <li data-cd="05" data-color="#ffe3e9" style="background-color: rgb(255, 227, 233);"></li>
				                <li data-cd="06" data-color="#be5233" style="background-color: rgb(190, 82, 51);"></li>
				                <li data-cd="07" data-color="#f87331" style="background-color: rgb(248, 115, 49);"></li>
				                <li data-cd="08" data-color="#ff9c71" style="background-color: rgb(255, 156, 113);"></li>
				                <li data-cd="09" data-color="#fccbb6" style="background-color: rgb(252, 203, 182);"></li>
				                <li data-cd="10" data-color="#fae3d9" style="background-color: rgb(250, 227, 217);"></li>
				                <li data-cd="11" data-color="#9f766a" style="background-color: rgb(159, 118, 106);"></li>
				                <li data-cd="12" data-color="#d19b22" style="background-color: rgb(209, 155, 34);"></li>
				                <li data-cd="13" data-color="#f9bc23" style="background-color: rgb(249, 188, 35);"></li>
				                <li data-cd="14" data-color="#ffec7f" style="background-color: rgb(255, 236, 127);"></li>
				                <li data-cd="15" data-color="#fcfac1" style="background-color: rgb(252, 250, 193);"></li>
				                <li data-cd="16" data-color="#007135" style="background-color: rgb(0, 113, 53);"></li>
				                <li data-cd="17" data-color="#35a23a" style="background-color: rgb(53, 162, 58);"></li>
				                <li data-cd="18" data-color="#83b730" style="background-color: rgb(131, 183, 48);"></li>
				                <li data-cd="19" data-color="#cedf7f" style="background-color: rgb(206, 223, 127);"></li>
				                <li data-cd="20" data-color="#e9f1c3" style="background-color: rgb(233, 241, 195);"></li>
				                <li data-cd="21" data-color="#14479e" style="background-color: rgb(20, 71, 158);"></li>
				                <li data-cd="22" data-color="#4984d9" style="background-color: rgb(73, 132, 217);"></li>
				                <li data-cd="23" data-color="#42aedc" style="background-color: rgb(66, 174, 220);"></li>
				                <li data-cd="24" data-color="#ace1f0" style="background-color: rgb(172, 225, 240);"></li>
				                <li data-cd="25" data-color="#d9eff2" style="background-color: rgb(217, 239, 242);"></li>
				                <li data-cd="26" data-color="#5830b3" style="background-color: rgb(88, 48, 179);"></li>
				                <li data-cd="27" data-color="#744dc8" style="background-color: rgb(116, 77, 200);"></li>
				                <li data-cd="28" data-color="#9b65d9" style="background-color: rgb(155, 101, 217);"></li>
				                <li data-cd="29" data-color="#d4c0f1" style="background-color: rgb(212, 192, 241);"></li>
				                <li data-cd="30" data-color="#ede0fa" style="background-color: rgb(237, 224, 250);"></li>
				                <li data-cd="31" data-color="#333333" style="background-color: rgb(51, 51, 51);"></li>
				                <li data-cd="32" data-color="#555555" style="background-color: rgb(85, 85, 85);"></li>
				                <li data-cd="33" data-color="#adadad" style="background-color: rgb(173, 173, 173);"></li>
				                <li data-cd="34" data-color="#e9e9e9" style="background-color: rgb(233, 233, 233);"></li>
				                <li data-cd="35" data-color="#ffffff" style="background-color: rgb(255, 255, 255);"></li>
				            </ul>
				        </li>
				        <li>
    						<button type="button" class="mailsendBtn mL5" onclick="$('#panelBar_LblCnfgBx').hide()" title="닫기">닫기</button>
    					</li>
				    </ul>
    	`;
    	
    	$('#panelBar_LblCnfgBx').remove();
    	
    	$('.formbdContainer').append($(colorpicPanel));
    	
		$(document).off('click', '#panelBar_LblCnfgBx li');
    	$(document).on('click', '#panelBar_LblCnfgBx li', function(){
    		
    		//$('#panelBar_LblCnfgBx').hide();
    		if($(this).attr('data-color')){
    			let coltype = $("#attrColorType").val();
    			let piccol = $(this).attr('data-color');
    			
    			if( CPCommon.isNotNull( piccol ) ){
    				
    				CPElemParent.applyColorToAttrTab(coltype, piccol);
    				
        			$('#cp_cb'+ coltype ).trigger( 'change' );
        			$('#panelBar_LblCnfgBx').hide();
        			
    			}
    		}
    	});
    }
	,
	/***************************************************************************
	 * 
	 *  색상 선택 .
	 * 
	 **************************************************************************/
	applyColorToAttrTab(coltype, piccol){

		if(coltype == 'background'){
			$('#cp_cb'+ coltype ).parent().parent().css( coltype, piccol );
		}
		else{
			$('#cp_cb'+ coltype ).css( coltype, piccol );
		}
		
		$('#cp_cb'+ coltype ).attr( 'value', piccol );
		
	}
	, 
	/***************************************************************************
	 * 
	 * 공통 색상 선택 버튼.
	 * 
	 **************************************************************************/
    creatColorPicCmnButton(){
    	
    	let ctlbutton = `
    		<li class="formGrid" id="colorPicBtnArea">
                <div class="colorArea">
                    <p class="formbdMenuTit">글자색</p>
                    <div class="formbdMenuCon" onClick="CPElemParent.setForeColorType(event, 'color')">
                        <div class="colorBx"  ><span id="cp_cbcolor" value="#000" class="txtcolor" style="font-size:18px; font-weight:bold;">A</span></div>
                    </div>
                </div>
                <div class="colorArea">
                    <p class="formbdMenuTit">글자배경색</p>
                    <div  id="headerOnlyDiv" class="formbdMenuCon" onClick="CPElemParent.setForeColorType(event, 'background')">
                        <div class="colorBx"><span id="cp_cbbackground" value="#fff" class="bgcolor" style="font-size:18px;font-weight:bold;">A</span></div>
                    </div>
                </div>
                <span id="headerOnlyMsg" style="color:red;display:none;">* 헤더상태 배경색 사용불가.</span>
            </li>
    		`;
    	
    	$('#colorPicBtnArea').remove();
    	
    	$(GB_PROPS.attview).find('.formbdMenu').append($(ctlbutton));
    	
    	$('#colorPicBtnArea').append($(`<input type="hidden" id="attrColorType" value="color" />`));

    }
    ,
    /***************************************************************************
	 * 
	 * 공통 색상 선택 버튼 핸들러.
	 * 
	 **************************************************************************/
    setForeColorType(e, typeNm){
    	
    	//console.log(e);
    	//console.log('e.clientX', e.clientX);
    	
    	if(typeNm == 'background' && $('#cp_rdheader').attr('value') =='on'){
    			return;
    	}
    	
    	$("#attrColorType").attr('value', typeNm);
    	
    	$('#panelBar_LblCnfgBx').show();
    	$('#panelBar_LblCnfgBx').css( 'left' , (e.clientX - 300) + 'px' );
    	$('#panelBar_LblCnfgBx').css( 'top' , (e.clientY - 300) + 'px' );
    	$('#panelBar_LblCnfgBx').draggable();
    }

}
