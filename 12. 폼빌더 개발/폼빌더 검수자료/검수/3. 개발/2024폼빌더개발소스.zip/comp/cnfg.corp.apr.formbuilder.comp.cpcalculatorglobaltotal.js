let CPCalculatorglobaltotal = {

    CP_ID : null
    ,
    CP_TYPE : "CPCalculatorglobaltotal"
    ,
    CP_ITEM_TITLE : "총계" 
    ,
    CP_UseableItemLists : new Object()
    ,
    msg : {
        "not-in-table" : '연산합 컴포넌트는 테이블 내에서 생성이 가능합니다.',
        "onlyone" : '하나 양식에 하나의 총계 컴포넌트만 등록 가능합니다.',
        "alert001" : '해당 테이블에 연산 컴포넌트을 추가 후 사용 가능 합니다.',
        "alert003" : '불완전한 수식입니다.',
        "alert004" : '연결된 함수가 없습니다.',
        "alert005" : '는 사용이 불가능 합니다.',
    }
    ,
    onOffClass : 'calculatorglobaltotal'    
    ,
    wrapID : 0
    ,
    alert( type = '' ){
        let _msg = this.msg[type];
        
        if( _msg ){ 
        	//alert(_msg);
	        layCmn.alert({
	            msg: _msg,
	            callback: function (e) { }
	        });
        }//else console.log("alert" , type);
    }
    ,
    
    getAttrView(prop){

        let vwid = "att_tle";
        let template = `<div id="div_${vwid}" class="formbdTitle"><span>총계 속성</span></div>
                        <ul id="ul_${vwid}" class="formbdMenu">

                            <li>
                                <p class="formbdMenuTit">사용 가능 항목</p>
                                <div class="formbdMenuCon">

                                    <div id="useableItemListsWrap">
                                        <div> loading...</div>                                        
                                    </div>

                                    <div id="useableCalListsWrap">
                                        <span data-style="+">+</span>
                                        <span data-style="-">-</span>
                                        <span data-style="*">x</span>
                                        <span data-style="/">%</span>
                                        <span data-style="(">(</span>
                                        <span data-style=")">)</span>                                    
                                    </div>
                                </div>                                
                            </li>                            
                            
				        	<li>
                                <p class="formbdMenuTit disInline vM">총계 정보 입력 </p>
                                <span class="formbdicon_Question vM mB10"><p class="formbd_notes_wrap">예) 총계값을 보여줄 합계컴포넌트의 셀ID를 선택해주세요</p></span>
                                <div class="formbdMenuCon">
                                    <input id="cp_calculator" style="width:100%;opacity:1;" class="k-textbox" type="text"  value="" placeholder="함수를 입력하세요.">
                                    <span id="cp_calculator_alert" class="alert"></span>
                                </div>
				        	</li>           
                            
                        </ul>`;

        let $templ = $(template);        


        //이벤트 연결
        $templ.find('#useableItemListsWrap').on('change',function (e) {
            CPCalculatorglobaltotal.updateCheckCalculatorData();      
        });

        $templ.find('#useableItemListsWrap').on('mouseover',function (e) {

            $(".CPCalculatortotal.previewoff").each((_,itm)=>{

                if( $(itm).attr("id") == $(e.target).find('input').val()){

                    $(itm).addClass("here");

                    setTimeout(() => {
                        $(itm).addClass("end");
                    }, 500);

                    setTimeout(() => {
                        $(itm).removeClass("end");
                        $(itm).removeClass("here");
                    }, 1000);                    

                }
                
            });

        });

    
        return $templ;                
    }

    ,
    
    updateCheckCalculatorData(){

        const _ids = [];

        $('#useableItemListsWrap input').each(function (_, item) {
            if( $(item).is(':checked') ){
                let _id = $(item).attr("id").replace("cp_itemID_","");
                _ids.push(_id);
            }         
        });

        $("#cp_calculator").val( (_ids.length > 0?_ids.join('+') : '') );


        CPCalculatorglobaltotal.checkCalculatorData();

    }

    ,
    checkCalculatorData(){

        //flush
        CPCalculatorglobaltotal.onCalculator(false);

        //flush
        const _cp_calculator = $("#cp_calculator");
        if( _cp_calculator.length == 0 ){
            CPCalculatorglobaltotal.onCalculatorItem([]);
            return;
        }

             
     


        const _alert = $('#cp_calculator_alert');
        _alert.html("");

        const _pv_data = $(`#pv_${CPCalculatorglobaltotal.CP_ID}data`);
        _pv_data.val('');

        const _pv_txt = $(`#pv_${CPCalculatorglobaltotal.CP_ID}calFrom`);
        _pv_txt.html("");   


        //
        let _val = _cp_calculator.val().toUpperCase();

        const CP_UseableItemListsKey = Object.keys(CPCalculatorglobaltotal.CP_UseableItemLists);

        if(_val.length == 0 || CP_UseableItemListsKey.length == 0 ) 
            return CPCalculatorglobaltotal.onCalculatorItem([]);

        if( CP_UseableItemListsKey.length == 0) {
            _alert.html(CPCalculatorglobaltotal.msg.alert001);
            return;
        }        

        //대문자로 변경
        _cp_calculator.val(_val);

        //공백 제거
        const blank = /\s/g;
        if( _val.match( /\s/g ) ){ 
            _alert.html(CPCalculator.msg.alert002);
            _cp_calculator.val( _val.replace( blank,''));
            return;
        }           

        let _function = [];
        _function.push("+");
        _function.push("-");
        _function.push("*");
        _function.push("/");
           


        //함수 테스트
        let _valTest = _val;
        _function.forEach((_f)=>{
            _valTest = _valTest.replaceAll(_f,",");               
        });



        if( 
            //중복 수식
            _valTest.includes(",,") ||

            //수식 맨앞 맨뒤
            _valTest.substr(0, 1) ==',' || 
            _valTest.substr(_valTest.length-1, 1) ==',' ||

            //소가로 갯수
            _valTest.split('(').length != _valTest.split(')').length
        ){
            CPCalculatorglobaltotal.onCalculator(false);
            CPCalculatorglobaltotal.onCalculatorItem([]);
            _alert.html(CPCalculatorglobaltotal.msg.alert003);
            return;
        }
            





        _function.push("(");
        _function.push(")");

        _function.forEach((_f)=>{
            _val = _val.replaceAll(_f,",");               
        });
            
            





        //check 
        let _msg = [];
        //중복값제거
        let splitVal =  [...new Set(_val.split(","))];

        //선처리
        CP_UseableItemListsKey.forEach((key)=>{                
            splitVal.some((split,idx,arr)=>{

                    //공백 제거
                    if(split.trim() == ''){
                        splitVal.splice(idx, 1);
                        return true;
                    }

                    //숫자사용 허용시           
                    if(/[0-9]/.test(split) && /[A-Z]/.test(split) == false){
                        splitVal.splice(idx, 1);
                        return true;
                    }                                   

                });  
        });

        //가능한 문자 추출
        CP_UseableItemListsKey.forEach((key)=>{                
                splitVal.some((split,idx,arr)=>{                    

                    if( key != split && arr.length-1 == idx && key.includes(split)){
                        splitVal.splice(idx, 1);
                        _msg.push(key);
                    }                                     

                });  
        });


        //사용허용된 값 제거
        let usedItemKey = [] ;
        CP_UseableItemListsKey.forEach((key)=>{                
                splitVal.forEach((split,idx)=>{
                    if(key == split){
                        splitVal.splice(idx, 1);  
                        usedItemKey.push(key);
                    }                   
                });
        });


        //used item display change
        CPCalculatorglobaltotal.onCalculatorItem(usedItemKey);  


        //나머지는 사용 불가
        if(splitVal.length>0){
            CPCalculatorglobaltotal.onCalculator(false);
            CPCalculatorglobaltotal.onCalculatorItem([]);
            _alert.html(`${splitVal.join(',')}${CPCalculatorglobaltotal.msg.alert005}`);
            return;
        }
           
        //참고 할만한 값 표출
        if(_msg.length>0){
            CPCalculatorglobaltotal.onCalculator(false);
            CPCalculatorglobaltotal.onCalculatorItem([]);
            _alert.html(_msg.join(','));
            return;
        }


                 



        //finish
        const dumChar = '^@^';
        const addValueDumChar = '@';
        let _finish_val = dumChar+_cp_calculator.val()+dumChar;
        _function.forEach((_f)=>{
            _finish_val = _finish_val.replaceAll(_f,dumChar+_f+dumChar);               
        }); 

        let set_data = _finish_val;
        let set_txt = _finish_val;

        CP_UseableItemListsKey.forEach((key)=>{ 
            set_data = set_data.replaceAll( dumChar+key+dumChar,  addValueDumChar+CPCalculatorglobaltotal.CP_UseableItemLists[key]+addValueDumChar);     
            set_txt = set_txt.replaceAll( dumChar+key+dumChar,  "<span>"+key+"</span>");     
        });
            
        //
        _pv_data.val(set_data.replaceAll(dumChar,  ''));
        _pv_txt.html(set_txt.replaceAll(dumChar,  ''));

    }
    ,
    onCalculator(show = true){

        const _pv_alert = $(`#${CPCalculatorglobaltotal.CP_ID}alertmsg`);  
        const _CPCalculatorglobaltotal = $(`#${CPCalculatorglobaltotal.CP_ID}`).closest(".changeWrap");

        if( show ){  
                 
            _pv_alert.html("");

            _CPCalculatorglobaltotal.addClass(CPCalculatorglobaltotal.onOffClass);
            _CPCalculatorglobaltotal.find(".previewon").addClass(CPCalculatorglobaltotal.onOffClass);
            _CPCalculatorglobaltotal.find(".previewoff").addClass(CPCalculatorglobaltotal.onOffClass);

        }else{

            _pv_alert.html(CPCalculatorglobaltotal.msg.alert004);

            _CPCalculatorglobaltotal.removeClass(CPCalculatorglobaltotal.onOffClass);
            _CPCalculatorglobaltotal.find(".previewon").removeClass(CPCalculatorglobaltotal.onOffClass);
            _CPCalculatorglobaltotal.find(".previewoff").removeClass(CPCalculatorglobaltotal.onOffClass);
        }

    }
    ,
    onCalculatorItem(lists){        

        //CPCalculatorglobaltotal.CP_ID

        const CP_UseableItemListsKey = Object.keys(CPCalculatorglobaltotal.CP_UseableItemLists);

        if( CP_UseableItemListsKey.length == 0) return;


        if( lists.length > 0 ){          
            this.onCalculator(true);
        }else{
            this.onCalculator(false);
        }
        

        CP_UseableItemListsKey.some((key)=>{

            const _itemID = CPCalculatorglobaltotal.CP_UseableItemLists[key];
            const _changeWrap = $(`#${_itemID}`).closest(".changeWrap");

            if( _changeWrap.length <= 0 ) return true;
            

            if(lists.includes(key)){

                _changeWrap.addClass(CPCalculatorglobaltotal.onOffClass);
                _changeWrap.find(".previewon").addClass(CPCalculatorglobaltotal.onOffClass);
                _changeWrap.find(".previewon").attr("data-global-target",CPCalculatorglobaltotal.CP_ID);
                _changeWrap.find(".previewoff").addClass(CPCalculatorglobaltotal.onOffClass);
                
            }else{

                _changeWrap.removeClass(CPCalculatorglobaltotal.onOffClass);
                _changeWrap.find(".previewon").removeClass(CPCalculatorglobaltotal.onOffClass);
                _changeWrap.find(".previewon").removeAttr("data-global-target");
                _changeWrap.find(".previewoff").removeClass(CPCalculatorglobaltotal.onOffClass);

            }

            //flush table data
            if( typeof CPTable == 'object' && $(`#${_itemID}`).closest("TD").length > 0 ){            
                CPTable._table.setItemData( $(`#${_itemID}`).closest('TD')[0] );
            }
            

        });

    }

    ,
    flushItems(_table=''){


        if( _table == '' && $(`#${CPCalculatorglobaltotal.CP_ID}`).closest('table').length > 0 ){  
            _table = $(`#${CPCalculatorglobaltotal.CP_ID}`).closest('table')[0];
        } 

        if( _table == '' ){
            this.alert('no-table-obj');
            return;
        }

        //
        const _CPCalculator_id_array =[];
        $(_table).find('.CPCalculatortotal.previewon.calculatorglobaltotal').each((_,_itm)=>{
            _CPCalculator_id_array.push($(_itm).attr('data-global-target'));
        });  

        //
        $(_table).find('.CPCalculatorglobaltotal.previewon').each((_,_cp)=>{

            let removeIdx =[];
            $(_CPCalculator_id_array).each((_idx,_cpid)=>{
                if(_cpid == $(_cp).attr('data-id')) removeIdx.push(_idx);                
            });

            //remove
            $(removeIdx.reverse()).each((_,no)=>{
                _CPCalculator_id_array.splice(no, 1);
            });

        });

        //
        $(_CPCalculator_id_array).each((_,_cpid)=>{

            $(_table).find('.CPCalculatortotal.previewon.calculatorglobaltotal').each((_,_itm)=>{

                if( $(_itm).attr('data-global-target') == _cpid ){    

                    const _changeWrap = $(_itm).closest(`.changeWrap`);

                    _changeWrap.removeClass(CPCalculatorglobaltotal.onOffClass);
                    _changeWrap.find(".previewon").removeClass(CPCalculatorglobaltotal.onOffClass);
                    _changeWrap.find(".previewon").removeAttr("data-global-target");
                    _changeWrap.find(".previewoff").removeClass(CPCalculatorglobaltotal.onOffClass);

                }
            });  

        });



    }

    ,
    useableItemLists(){

        let _db = [];
        if( $("#cp_calculator").val() ){
            _db = $("#cp_calculator").val().split("+");
        }

        CPCalculatorglobaltotal.CP_UseableItemLists = new Object();

        let  _html = '';

        //
        GB_PROPS.bdview.find('.CPCalculatortotal.previewoff.calculatortotal').each(function(_,cal){

            const _itemID = $(cal).find("#ID").attr("data-id");
            const _numberItemID = $(cal).attr("id");

            //flush
            $(cal).closest('td').find(".changeWrap").removeClass(CPCalculatorglobaltotal.onOffClass);


            CPCalculatorglobaltotal.CP_UseableItemLists[_itemID] = _numberItemID;

            //
            let checked = '';  
            $(_db).each((_,db)=>{
                if(db == _itemID) checked = 'checked';
            });
            
            //_html += `<span data-id='${_numberItemID}' data-style='${_itemID}'>${_itemID}</span>`;
            _html += `                            
                        <label for="cp_itemID_${_itemID}">
                            <input id="cp_itemID_${_itemID}" ${checked} type="checkbox" value="${_numberItemID}">
                            ${_itemID}
                        </label>
                        `;

        });

        $('#cp_calculator').attr("disabled",true); 
        $("#useableCalListsWrap").css("display","none");  

        //show        
        if(_html == ''){
            _html = CPCalculatorglobaltotal.msg.alert001;
            //$('#cp_calculator').attr("disabled",true);   
            //$("#useableCalListsWrap").css("display","none");      
        }else{
            //$('#cp_calculator').attr("disabled",false);
            //$("#useableCalListsWrap").css("display","block");     
        }

        $("#useableItemListsWrap").html(_html);


    }
    ,
    addCompo(prop){

        //check in table
        if(  $('.tableSelectOn').length == 0 ){
            CPCalculatorglobaltotal.alert("not-in-table");
            return;
        }


        //
        if(CPTable.countCpCalculatorglobaltotalSameTable() != 0){
            CPCalculatorglobaltotal.alert("onlyone");
            //GB_PROPS.attview.html('');
            return;
        } 
        


        let template = CPCalculatorglobaltotal.getCpHtml(prop);
        let $attrview = CPCalculatorglobaltotal.getAttrView(prop); 

        
        
        CPElemParent.addComp({
            cptype: CPCalculatorglobaltotal.CP_TYPE
            ,cpid: CPCalculatorglobaltotal.CP_ID
            ,template: template
            ,vwtemplate: $attrview
        });

        //flush data
        setTimeout(function(){     	
            CPCalculatorglobaltotal.useableItemLists();  
            CPCalculatorglobaltotal.checkCalculatorData();
        }, 100);
        
    }
    ,
    selectComp(prop){

        //flush
        $(`#${prop.cpid}`).removeClass('twinkle');

        //
        const attr = $(`#${prop.cpid}`).attr('data_attr');
        let attrJson = CPElemParent.parseDataAttrToJson(attr);
  

        let template = this.getCpHtml(prop);        
        let $attrview = CPCalculatorglobaltotal.getAttrView(prop);

        CPCalculatorglobaltotal.CP_ID = prop.cpid;
        
        
        CPElemParent.selectComp({
            cptype: CPCalculatorglobaltotal.CP_TYPE
            ,cpid: prop.cpid
            ,template: template
            ,vwtemplate: $attrview
            ,data_attr: prop.data_attr
        });


        //flush data
        setTimeout(function(){     	
            CPCalculatorglobaltotal.useableItemLists();  
            CPCalculatorglobaltotal.checkCalculatorData();
        }, 100);

    }
    ,
    print(n, width){

        n = n + '';

        return n.length >= width ? n : new Array(width - n.length + 1).join('0') + n;
    }
    ,
    getCpHtml(prop){

        let cpid = null;

        if(prop && prop.cpid){
            cpid = prop.cpid;
        }else{
            cpid = this.createCpid();
        }
        
        this.CP_ID = cpid;

        this.wrapID++;
        
        return  `
        <div class="${this.CP_TYPE} previewoff tblformbdCon" id="${cpid}">
            <span>${CPCalculatorglobaltotal.CP_ITEM_TITLE}</span> 
            <button type="button" class="k-button dltBtn groupTrash"></button>
        </div>
        <div class='${this.CP_TYPE} previewon splitWrap' data-id="${cpid}"> 
            <div class="splitBlock">  

                <input type="hidden" id="pv_${cpid}data" value="">            
            
                <span class="pv_table_id">T${this.wrapID}</span>

                <!-- 스크립트 입력 -->
                <div class="calculatorWrap"> 
                    <div id="calSumWrap"><span id="pv_${cpid}calSum" class="calSum"><b>= </b>0</span></div>                    
                    <div id="pv_${cpid}calFrom" class="calFrom"></div>
                </div>
                <span id="${cpid}alertmsg" class="alertmsg"></span>

            </div>
        </div>
        `;

        

    }
    ,
    createCpid(){

        return CPCalculatorglobaltotal.CP_TYPE + '_' + Math.floor(Math.random() * 10000);

    }    
}