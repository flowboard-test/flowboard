/**
 * 폼빌더 컴포넌트.
 * 
 * 
*/
let CPLabel = {

    CP_ID : null
    ,
    CP_TYPE : "CPLabel"
    ,
    CP_ITEM_TITLE : "레이블"
	,
	MAX_LEN: 20
    ,
    getAttrView(prop){

        let vwid = "att_tle";
        let template = `<div id="div_${vwid}" class="formbdTitle"><span>레이블컴포넌트 속성</span></div>
            <ul id="ul_${vwid}" class="formbdMenu">
            		
                <li>
                    <p class="formbdMenuTit">레이블 입력값</p>
                    <div class="formbdMenuCon">
                        <input id="cp_txlabelval" name="" maxlength="${CPLabel.MAX_LEN}" data-id="${this.CP_ID}" style="width:100%;" class="k-textbox" type="text" >
                    </div>
                </li>
                <li>
                <p class="formbdMenuTit">높이</p>
                <div class="formbdMenuCon">
                    <div class="dropdownArea">
                        <span  title="" class="k-widget k-dropdown k-header formbd_drop" unselectable="on" role="listbox" aria-haspopup="true" aria-expanded="false" tabindex="1" aria-owns="" aria-disabled="false" aria-busy="false" aria-activedescendant="b9638adf-c13e-4791-9aa7-7e060777ee7b" style="width: 60px;"><span unselectable="on" class="k-dropdown-wrap k-state-default">
                        <span unselectable="on" class="k-input">%</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span></span>
                        <input id="cp_txheightUnit" style="width: 60px; display: none;" class="formbd_drop" name="formbd_drop" type="text" value="" data-role="dropdownlist"></span>
                    </div>
                    <input id="cp_txheight" name="" style="width:150px;" class="k-textbox mL5" type="number" value="100" >
                    
                </div>
                </li>
            	<li>
                <p class="formbdMenuTit">너비</p>
                <div class="formbdMenuCon">
                    <div class="dropdownArea">
                        <span  title="" class="k-widget k-dropdown k-header formbd_drop" unselectable="on" role="listbox" aria-haspopup="true" aria-expanded="false" tabindex="1" aria-owns="" aria-disabled="false" aria-busy="false" aria-activedescendant="b9638adf-c13e-4791-9aa7-7e060777ee7b" style="width: 60px;"><span unselectable="on" class="k-dropdown-wrap k-state-default">
                        <span unselectable="on" class="k-input">%</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span></span>
                        <input id="cp_txwidthUnit" style="width: 60px; display: none;" class="formbd_drop" name="formbd_drop" type="text" value="" data-role="dropdownlist"></span>
                    </div>
                    <input id="cp_txwidth" name="" style="width:150px;" class="k-textbox mL5" type="number" value="100" >
                    
                </div>
                </li>
                
            </ul>`;

        let $templ = $(template);
        
        $templ.find('#cp_txlabelval').on('keyup', function(txe){
        	
        	let inputval = $(this).val();
            if(inputval ){

                if(inputval.length > 100){

                    let restr = inputval.substr(0, 100);
                    
                    $(this).val(restr);
                    

                    layCmn.alert({
                        msg: "입력가능 최대 100 글자 수 이하로 입력하세요.",
                        callback: function (e) { }
                    });

                   
                    return;
                }

                $("#pv_"+ GB_CUR_STATE.CP_ID).html(inputval);
            }

            
            
        });
        $templ.find('#cp_txheight').on('keyup',function (e) {
            
        	let inputval = $(this).val();
            
            if(inputval > 100){
            	
            	$(this).val(100);

                layCmn.alert({
                    msg: `가능값을 초과했습니다. 100 이하로 입력하세요.`,
                    callback: function (e) { }
                });
               
                return;
            }
            
        });

        return $templ;                
    }
    ,
    addCompo(prop){

        let template = this.getCpHtml(prop);
        
        let $attrview = CPLabel.getAttrView(prop);

        CPElemParent.getFontFamilySelect()
        .then((elem)=>{
            
            CPElemParent.addComp({
                cptype: CPLabel.CP_TYPE
                ,cpid: this.CP_ID
                ,template: template
                ,vwtemplate: $attrview
                ,cmmattrarr: ['fontFamily','textAlign','fontColor']
            });

            setTimeout(() => {  
                //console.log(elem)
                let fntselect = $attrview.find('#cp_cbfont-family'); 
                fntselect.append( elem );
                fntselect.kendoDropDownList();
            }, 10);

        });  
        
    }
    ,
    selectComp(prop){
    	
        let template = this.getCpHtml();
        
        let $attrview = CPLabel.getAttrView()               

        CPElemParent.getFontFamilySelect()
        .then((elem)=>{

            CPElemParent.selectComp({
                cptype: CPLabel.CP_TYPE
                ,cpid: prop.cpid
                ,template: template
                ,vwtemplate: $attrview
                ,data_attr: prop.data_attr
                ,cmmattrarr: ['fontFamily','textAlign','fontColor']
            });
            
            setTimeout(function(){
	        	let fntselect = $attrview.find('#cp_cbfont-family');   
	        	fntselect.append( elem );
	            fntselect.kendoDropDownList();
	        }, 10);
        });                    
        
    }
    ,
    getCpHtml(prop){

        let cpid = null;

        if(prop && prop.cpid){
            cpid = prop.cpid;
        }else{
            cpid = this.createCpid();
        }
        
        this.CP_ID = cpid;
        
        return  `
        <div class="${this.CP_TYPE} previewoff tblformbdCon" id="${cpid}"><span>${this.CP_ITEM_TITLE}</span> <button type="button" class="k-button dltBtn groupTrash"></button></div>
        <div class='${this.CP_TYPE} previewon splitWrap' data-id="${cpid}"
         		id="pv_${cpid}" style="width:100%;font-family:맑은고딕;font-size:12px; margin:0 0;"> 


        </div>
        `;

    }
    ,
    createCpid(){

        return CPLabel.CP_TYPE + '_' + Math.floor(Math.random() * 10000);

    }
    
    
}
