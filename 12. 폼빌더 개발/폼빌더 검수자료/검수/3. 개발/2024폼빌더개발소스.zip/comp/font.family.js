{
    "fonts": [
    	{ "english": "맑은고딕", "korean": "맑은고딕" },
    	{ "english": "돋움", "korean": "돋움" },
    	{ "english": "굴림", "korean": "굴림" },
    	{ "english": "바탕", "korean": "바탕" },
    	{ "english": "궁서", "korean": "궁서" },
    	{ "english": "David", "korean": "David" },
    	{ "english": "MS PGothic", "korean": "MS PGothic" },
	    { "english": "New MingLiu", "korean": "New MingLiu" },
	    { "english": "Simplified Arabic", "korean": "Simplified Arabic" },
	    { "english": "simsun", "korean": "simsun" },
	    { "english": "Arial", "korean": "Arial" },
	    { "english": "Curier New", "korean": "Curier New" },
	    { "english": "Tahoma", "korean": "Tahoma" },
	    { "english": "Times New Roman", "korean": "Times New Roman" },
	    { "english": "Verdana", "korean": "Verdana" }
    ]
}