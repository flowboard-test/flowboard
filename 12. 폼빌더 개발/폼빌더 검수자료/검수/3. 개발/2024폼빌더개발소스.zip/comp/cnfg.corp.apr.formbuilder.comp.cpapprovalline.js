/**
 * 폼빌더 컴포넌트.
 * 
 * 타이틀 컴포넌트
 * 
*/

let CPApprovalline = {

    CP_ID: null
    ,
    CP_TYPE: 'CPApprovalline'
    ,
    CP_ITEM_TITLE : '결재선' 
    ,
    CP_STYLE : 'single' // single-결재선  , multi-결재정보+결재선 , singleTypeB- 대외공문결재선
    ,
    CP_LIMIT : 1   //그룹당 해당 아이템의 사용 가능 횟수
    ,
    CP_GROUP : 'basic' //그룹당 아이템 사용 가능 횟수 카운팅    
    ,
    getAttrView(prop){

        let vwid = "att_tle";

        let _tmpSectionMulti = `<div id="div_${vwid}" class="formbdTitle"><span>결재정보 속성</span></div>
                            <ul id="ul_${vwid}" class="formbdMenu">

                                <li>
                                    <p class="formbdMenuTit">속성 선택</p>
                                    <div class="formbdMenuCon">
                                        <div class="checkWrap">
                                            <div>
                                                <input id="cp_macro_1" type="checkbox" class="macroWrap" value="pv_CT_DRFT_USR_DEPT">
                                                <label for="cp_macro_1">${CPView.macro.pv_CT_DRFT_USR_DEPT.txt}</label>
                                            </div>
                                            <div>
                                                <input id="cp_macro_2" type="checkbox" class="macroWrap" value="pv_CT_DRFT_DATE">
                                                <label for="cp_macro_2">${CPView.macro.pv_CT_DRFT_DATE.txt}</label>
                                            </div>
                                            <div>
                                                <input id="cp_macro_3" type="checkbox" class="macroWrap" value="pv_CT_DRFT_USR_NM">
                                                <label for="cp_macro_3">${CPView.macro.pv_CT_DRFT_USR_NM.txt}</label>
                                            </div>
                                            <div>
                                                <input id="cp_macro_4" type="checkbox" class="macroWrap" value="pv_AP_KEEP_YY">
                                                <label for="cp_macro_4">${CPView.macro.pv_AP_KEEP_YY.txt}</label>
                                            </div>
                                            <div>
                                                <input id="cp_macro_5" type="checkbox" class="macroWrap" value="pv_AP_IMPO_CD">
                                                <label for="cp_macro_5">${CPView.macro.pv_AP_IMPO_CD.txt}</label>
                                            </div>
                                            <div>
                                                <input id="cp_macro_6" type="checkbox" class="macroWrap" value="pv_AP_SEC_APPR_YN">
                                                <label for="cp_macro_6">${CPView.macro.pv_AP_SEC_APPR_YN.txt}</label>
                                            </div>
                                            <div>
                                                <input id="cp_macro_7" type="checkbox" class="macroWrap" value="pv_AP_OPEN_CD_LOCALE_NAME">
                                                <label for="cp_macro_7">${CPView.macro.pv_AP_OPEN_CD_LOCALE_NAME.txt}</label>
                                            </div>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <p class="formbdMenuTit">속성 위치</p>
                                    <div class="formbdMenuCon">
                                        <span title="" class="k-widget k-dropdown k-header" style="width:100%;">
                                            <span unselectable="on" class="k-dropdown-wrap k-state-default">
                                                <span id="disp_cp_addtable-align" unselectable="on" class="k-input">왼쪽</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span>
                                            </span>
                                            <select id="cp_addtable-align" data-role="dropdownlist" style="display: none;">
                                                <option value="left" selected="selected">왼쪽</option>
                                                <option value="right">오른쪽</option>
                                            </select>
                                        </span>
                                    </div>
                                </li>
                                </ul>
                            </div>                            
                            `;

        let _tmpSectionSingle = `<div id="div_${vwid}" class="formbdTitle"><span>결재선 속성</span></div>
                                <ul id="ul_${vwid}" class="formbdMenu">

                                ${this.CP_STYLE != "singleTypeB"?`
                                    <li>
                                        <p class="formbdMenuTit">결재선 이름</p>
                                        <div class="formbdMenuCon">
                                            <input id="cp_title" style="width:100%;" class="k-textbox" type="text" value="결재선">
                                            <span id="cp_title_alert" class="alert"></span>
                                        </div>
                                    </li>`:''}
                                    
                                    <li>
                                        <p class="formbdMenuTit">지정 결재자</p>
                                        <div class="formbdMenuCon" onclick="javascript:CPCommon.paintApprLineWindow();">
                                            <div>                                    
                                                <span class="formbdMenuSubTit">결재</span>
                                                <span id='appr_replace_data_area_A'></span>
                                            </div>                                    
                                            <div style="margin-top:10px;">
                                                <span class="formbdMenuSubTit">합의</span>
                                                <span id='appr_replace_data_area_B'></span>  
                                            </div> 
                                        </div>
                                    </li>   

                                    <li>
                                        <p class="formbdMenuTit">결재선 정렬</p>
                                        <div class="formbdMenuCon">
                                            <span title="" class="k-widget k-dropdown k-header" style="width:100%;">
                                                <span unselectable="on" class="k-dropdown-wrap k-state-default">
                                                    <span id="disp_cp_tablealign" unselectable="on" class="k-input">왼쪽정렬</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span>
                                                </span>
                                                <select id="cp_tablealign" data-role="dropdownlist" style="display: none;">

                                                    <option value="left" selected="selected">왼쪽정렬</option>
                                                    <option value="center">가운데정렬</option>
                                                    <option value="right">오른쪽정렬</option>
                                    
                                                    ${this.CP_STYLE == "multi"?"<option value=\"both\">좌우정렬</option>":""}
                                                                              
                                                </select>
                                            </span>
                                        </div>
                                    </li>  

                                </ul>
                            </div>
                            `;

        let _tmpSectionSingleAdd = `<div id="div_${vwid}" class="formbdTitle"><span>합의결재선 속성</span></div>
                            <ul id="ul_${vwid}" class="formbdMenu">

                                <li>
                                    <p class="formbdMenuTit">결재선 정렬</p>
                                    <div class="formbdMenuCon">
                                        <span title="" class="k-widget k-dropdown k-header" style="width:100%;">
                                            <span unselectable="on" class="k-dropdown-wrap k-state-default">
                                                <span id="disp_cp_tablealign" unselectable="on" class="k-input">왼쪽정렬</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span>
                                            </span>
                                            <select id="cp_tablealign" data-role="dropdownlist" style="display: none;">
                                                <option value="left" selected="selected">왼쪽정렬</option>
                                                <option value="center">가운데정렬</option>
                                                <option value="right">오른쪽정렬</option>                                         
                                            </select>
                                        </span>
                                    </div>
                                </li>  
                                
                            </ul>
                        </div>
                        `;

        let _tmpSectionSingleFinal = `<div id="div_${vwid}" class="formbdTitle"><span>수신결재선 속성</span></div>
                        <ul id="ul_${vwid}" class="formbdMenu">

                            <li>
                                <p class="formbdMenuTit">결재선 정렬</p>
                                <div class="formbdMenuCon">
                                    <span title="" class="k-widget k-dropdown k-header" style="width:100%;">
                                        <span unselectable="on" class="k-dropdown-wrap k-state-default">
                                            <span id="disp_cp_tablealign" unselectable="on" class="k-input">왼쪽정렬</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span>
                                        </span>
                                        <select id="cp_tablealign" data-role="dropdownlist" style="display: none;">
                                            <option value="left" selected="selected">왼쪽정렬</option>
                                            <option value="center">가운데정렬</option>
                                            <option value="right">오른쪽정렬</option>                                         
                                        </select>
                                    </span>
                                </div>
                            </li>  
                            
                        </ul>
                    </div>
                    `;

        let template = '';

        if( this.CP_STYLE == "single" ) template = _tmpSectionSingle;
        else if( this.CP_STYLE == "singleTypeB" ) template = _tmpSectionSingle; //대외공문 결재선
        else if( this.CP_STYLE == "multi" ) template = _tmpSectionMulti + "<br><br>"+ _tmpSectionSingle; //멀티컴포넌트
        else if( this.CP_STYLE == "singleAdd" ) template = _tmpSectionSingleAdd; //합의 결재선
        else if( this.CP_STYLE == "final" ) template = _tmpSectionSingleFinal; //수신 결재선


        let $templ = $(template);



        //이벤트 연결
        const _this = this;
        $templ.find('.macroWrap').on('change',function (e) {
            _this.updateMacroValue();      
        });

        $templ.find('#cp_title').on('keyup',function (e) {

            let _title = $(this).val().trim();
            const _alert = $templ.find('#cp_title_alert');

            if(_title == ""){
                _title = _this.CP_ITEM_TITLE;
                _alert.html("결재선 이름은 필수 입력 사항입니다.");
            }else{
                _alert.html("");
            }

            $(_this.CP_ID_target()).find("#editor_form_appr_title").val(_title);
        });

        /*
        $templ.find('#cp_table-length').on('keyup',function (e) {
            $(_this.CP_ID_target()).find("#editor_form_appr_alert").val($(this).val());
        });
        */

        $templ.find('#cp_tablealign').on('change',function (e) {

            $(['left','center','right']).each((_,cla)=>{
                $(_this.CP_ID_target()).closest('.formbdoverArea').removeClass(cla);
            });
            $(_this.CP_ID_target()).closest('.formbdoverArea').addClass($(this).val());
            
            $(_this.CP_ID_target()).find("#editor_form_appr_table_aglin").val($(this).val());
        });

        $templ.find('#cp_addtable-align').on('change',function (e) {
            $(_this.CP_ID_target()).find("#editor_form_appr_add_table_aglin").val($(this).val());
        });

        $templ.find('select').each(function (_, item) {
            if( $(item).attr('data-role') == "dropdownlist" ) $(item).kendoDropDownList();            
        });

        return $templ;                
    }
    ,
    getTitle(_style =''){        

        let _title =  this.CP_ITEM_TITLE;

        if(_style=='single')           _title = "결재선";
        else if(_style=='multi')       _title = "결재정보+결재선";
        else if(_style=='singleTypeB') _title = "대외공문 결재선";
        else if(_style=='singleAdd') _title = "합의 결재선";
        else if(_style=='final')     _title = "수신 결재선";

        //this.CP_ITEM_TITLE = _title;

        return _title;
    }
    ,
    setCPID(cpid=''){
        if(cpid)
        this.CP_ID = cpid;
    }
    ,
    setCPSTYLE(cpstyle=''){
        if(cpstyle)
        this.CP_STYLE = cpstyle;
    }
    ,
    setCPLIMIT(cplimit=''){
        if(cplimit)
        this.CP_LIMIT = cplimit;
    }
    ,
    setCPGROUP(cpgroup=''){
        if(cpgroup)
        this.CP_GROUP = cpgroup;
    }
    ,
    addCompo(prop){


        //limit check
        if( this.CP_LIMIT <= $("."+this.CP_TYPE+"."+this.CP_GROUP).length ){

            let _msg = this.CP_LIMIT+"개 이상의 '"+ this.getTitle( this.CP_STYLE)+"'을 생성 할 수 없습니다.";

            if( this.CP_STYLE == "single" ){
                _msg = "'"+ this.getTitle(this.CP_STYLE)+"'는 '"+ this.getTitle('multi')+"', '"+ this.getTitle('singleTypeB')+"'를 포함하여 "+this.CP_LIMIT+"개 이상 생성 할 수 없습니다.";            
            }else if( this.CP_STYLE == "singleTypeB"){
                _msg = "'"+ this.getTitle(this.CP_STYLE)+"'는 ''"+ this.getTitle('single')+"', "+ this.getTitle('multi')+"'를 포함하여 "+this.CP_LIMIT+"개 이상 생성 할 수 없습니다.";
            }else if( this.CP_STYLE == "multi"){
                _msg = "'"+ this.getTitle(this.CP_STYLE)+"'는 '"+ this.getTitle('single')+"', '"+ this.getTitle('singleTypeB')+"'를 포함하여 "+this.CP_LIMIT+"개 이상 생성 할 수 없습니다.";
            }  
          
            if( _msg ) 
            	//alert(_msg);
    	        layCmn.alert({
    	            msg: _msg,
    	            callback: function (e) { }
    	        });
            //else console.log("alert" , _msg);

            return;
        }




        //
        let template = this.getCpHtml(prop);
        
        let $attrview = this.getAttrView()                  

        CPElemParent.addComp({
            cptype: this.CP_TYPE
            ,cpid: this.CP_ID
            ,template: template
            ,vwtemplate: $attrview
        }); 
        
        /*
        //if has parent data
    	if(GB_PROPS.canReadParent 
    		&& GB_CUR_STATE.DOC_ID != undefined 
    		&& GB_CUR_STATE.DOC_ID.length > 0){      		
    		
    		CPApprovalline.loadApprData(GB_CUR_STATE.DOC_ID);
    		
    	}
    	*/


        //flush data
        setTimeout(function(){
            CPApprovalline.updateApprSettingData();
            CPApprovalline.updateMacroCheckBox();                
        }, 100);
        
    }
    ,
    selectComp(prop){
       
        //flush
        CPApprovalline.setCPSTYLE($("#"+prop.cpid).attr("data-style"));
        CPApprovalline.setCPLIMIT($("#"+prop.cpid).attr("data-limit"));
        CPApprovalline.setCPGROUP($("#"+prop.cpid).attr("data-group"));       
        CPApprovalline.setCPID(prop.cpid);  

        let template = this.getCpHtml(prop);
        
        let $attrview = this.getAttrView();             

        CPElemParent.selectComp({
            cptype: this.CP_TYPE
            ,cpid: prop.cpid
            ,template: template
            ,vwtemplate: $attrview
            ,data_attr: prop.data_attr
        }); 
        
      
        
        /*
        console.log("!!!!!" , GB_PROPS.canReadParent , GB_CUR_STATE );
        
        //if has parent data
    	if(GB_PROPS.canReadParent 
    		&& GB_CUR_STATE.DOC_ID != undefined 
    		&& GB_CUR_STATE.DOC_ID.length > 0){      		
    		console.log("!!!!!" , GB_CUR_STATE.DOC_ID );
    		CPApprovalline.loadApprData(GB_CUR_STATE.DOC_ID);
    		
    	}
    	*/
        
        //flush data
        setTimeout(function(){     	
            CPApprovalline.updateApprSettingData();
            CPApprovalline.updateMacroCheckBox();                
        }, 100);
        
    }
    
    ,
    getCpHtml(prop){

        let cpid = null;
        let cptitle = null;

        if(prop && prop.cpid){
            cpid = prop.cpid;
            cptitle = prop.cptitle;
        }else{
            cpid = this.createCpid();
            cptitle = this.getTitle(this.CP_STYLE);
        }
        
        this.CP_ID = cpid;    
        
        const _inputSingle = `
            <input type="hidden" id="editor_form_appr_title" value="${this.CP_ITEM_TITLE}">
            <input type="hidden" id="editor_form_appr_table_aglin" value="left">            
            <input type="hidden" id="editor_form_appr_line" value="">`;
        const _inputMulti = `
            <input type="hidden" id="editor_form_appr_add_table_aglin" value="left">
            <input type="hidden" id="editor_form_appr_add_line" value="">`;
        const _inputSimgleAdd = `
            <input type="hidden" id="editor_form_appr_title" value="${cptitle}">
            <input type="hidden" id="editor_form_appr_table_aglin" value="left">`;
        const _inputFinal = `
            <input type="hidden" id="editor_form_appr_title" value="${cptitle}">
            <input type="hidden" id="editor_form_appr_table_aglin" value="left">
            <input type="hidden" id="editor_aprDocEditApprLine" value="">`;

        let _input = '';
        if(this.CP_STYLE=='single') _input = _inputSingle;//결재선
        else if(this.CP_STYLE=='singleTypeB') _input = _inputSingle; //대외공문 결재선
        else if(this.CP_STYLE=='multi') _input = _inputSingle + _inputMulti; //멀티컴포넌트
        else if(this.CP_STYLE=='singleAdd') _input = _inputSimgleAdd;//합의 결재선
        else if(this.CP_STYLE=='final') _input = _inputFinal;//수신 결재선

      
        return  `
        <div class="${this.CP_TYPE} ${this.CP_GROUP} previewoff tblformbdCon" id="${cpid}" data-style="${this.CP_STYLE}" data-limit="${this.CP_LIMIT}" data-group="${this.CP_GROUP}">
            <span>${cptitle}</span> 
            <button type="button" class="k-button dltBtn groupTrash"></button>
        </div>
        <div class='${this.CP_TYPE} ${this.CP_STYLE} previewon splitWrap' data-id="${cpid}"> 
           
            ${_input}
                
            <div class="splitBlock _row"></div>

            <div id="pv_${cpid}required" class="required dn">!</div>

        </div>
        `;

    }
    ,
    createCpid(){

        return this.CP_TYPE + '_' + Math.floor(Math.random() * 10000);

    }

    

    ,

    /*
     reference : /abc.common/src/main/webapp/resources/abc/js/apr/apr.doc.edit.window_apprLine.js
     function  : onApply
    */
    loadApprData(apprID=''){

        const _this = this;

        $.ajax({
			url		: CPView.url.apprlist.replace("{{apprId}}",apprID),
			type	: "post",
			data	: {},
			success : function(res) {  	
				
				//console.log("!!!!!loadApprData",res);

                let hiddenVal ='';

                try {

                    //const obj = res;
                    const obj = JSON.parse( res );
                    //const obj = jQuery.parseJSON( res );

                    if( obj.list.length > 0 ){
                        $.each(obj.list, function(_, dataItem){

                        hiddenVal += ","+ dataItem.appr_line_order +"^";
                        hiddenVal += dataItem.appr_meth_cd +"^";
                        hiddenVal += dataItem.usr_key +"^";
                        hiddenVal += dataItem.kor_nm +"^";
                        hiddenVal += dataItem.dept_nm +"^";
                        hiddenVal += dataItem.pos_duty_nm +"^";
                        hiddenVal += dataItem.usr_id +"^";
                        hiddenVal += dataItem.dept_seq +"^";
                        hiddenVal += dataItem.macro_seq+"^";
                        hiddenVal += dataItem.macro_del_yn+"^";
                        hiddenVal += dataItem.macro_user_del_yn+"^";
                        hiddenVal += dataItem.macro_nm+"^";
                        hiddenVal += dataItem.appr_appr_line_seq;

                        });
                    }

                    const _editor_form_appr_line = $(_this.CP_ID_target()).find("#editor_form_appr_line");

                    if(_editor_form_appr_line.length > 0){
                        _editor_form_appr_line.val(hiddenVal);
                    } 

                    return true;
                } catch (e) {
                    return false;
                }
				
			}
		});

    }

    ,

    CP_ID_target(){
        let target = null;
        const _this = this;
        $("."+_this.CP_TYPE + ".previewon").each(function(_,item){
            if(_this.CP_ID && _this.CP_ID == $(item).data('id')){
                target = item;
                return true;
            }            
        }); 

        return target;
    }

    ,

    updateApprSettingData( data =''){

        const _this = this;        
        
        
        //CPApprovalline의 데이터 값을 보정해 준다.
		const _editor_form_appr_line = $("#editor_form_appr_line");
		if( _editor_form_appr_line.length > 0 && _editor_form_appr_line.val() == "" ){			   
			//_editor_form_appr_line.val( $('#form_appr_line', GB_PROPS.parentObj).val());
			_editor_form_appr_line.val( $('#form_appr_line', parent.opener.document).val());
		}
		
		
		

        let _editor_form_appr_line_value = data;

        if(_editor_form_appr_line_value == '' ){

            const _editor_form_appr_line = $(_this.CP_ID_target()).find("#editor_form_appr_line");
            if(_editor_form_appr_line.length > 0){
                _editor_form_appr_line_value = _editor_form_appr_line.val();               
            }          

        }
        
        
       
        if( _editor_form_appr_line_value =='' ){
            $("#appr_replace_data_area_A").html('');
            $("#appr_replace_data_area_B").html('');
            return;
        }

        
        /*
        1=승인 
        2=필수합의(순차) 
        3=필수합의(병렬) 
        4=선택합의(순차) 
        5=선택합의(병렬)
        */
        const db = [];
        _editor_form_appr_line_value.split(",").forEach((item) => {
            const innerDB = [];
            item.split("^").forEach((_item) => {
                innerDB.push(_item); 
            });
            db.push(innerDB);           
        });

        if( db.length == 0 ) return;

        let sectionA = [];
        let sectionB = [];
        $.each(db,function(_,item){
            if(item[1] == 1){  
                //sectionA.push( item[5]+":"+item[3] );                            
                sectionA.push( item[3] );                            
            }else if(item[1]){
                //sectionB.push( item[5]+":"+item[3] );   
                sectionB.push( item[3] );   
            }     
        });

        $("#appr_replace_data_area_A").html(sectionA.join(", "));
        $("#appr_replace_data_area_B").html(sectionB.join(", "));

    }

    ,
    updateMacroCheckBox(){

        const _this = this;

        let _editor_form_appr_add_line_value ='';

        const _editor_form_appr_line = $(_this.CP_ID_target()).find("#editor_form_appr_add_line");
        if(_editor_form_appr_line.length > 0){
            _editor_form_appr_add_line_value = _editor_form_appr_line.val();
        } 

        if( _editor_form_appr_add_line_value =='' ) return;
        

        const db = [];
        _editor_form_appr_add_line_value.split(",").forEach((item) => {
            item.split("^").forEach((_item,_idx) => {
                if(_idx == 0) db.push(_item); 
            });        
        });

        if( db.length == 0 ) return;

        $('.macroWrap').each(function (_, item) {
            if(db.includes($(item).val())){
                $(item).prop('checked',true);
            }         
        });
    }

    ,
    updateMacroValue(){

        const _this = this;

        let value = '';
        $('.macroWrap').each(function (_, item) {
            const macro = CPView.macro[$(item).val()];
            if( $(item).is(':checked') && macro  ){
                value += ","+$(item).val()+"^"+macro.code;
            }             
        });

        const _editor_form_appr_add_line = $(_this.CP_ID_target()).find("#editor_form_appr_add_line");
        if(_editor_form_appr_add_line.length > 0){
            _editor_form_appr_add_line.val(value);
        } 

    }

    ,
    /*
     @target : /abc.office/abc.common/src/main/webapp/resources/abc/js/apr/apr.doc.edit.window_apprLine.js
    */
    update_editor_form_appr_line_and_flush_settingAreaTxt(val){

        const _this = this;

        const _editor_form_appr_line = $(_this.CP_ID_target()).find("#editor_form_appr_line");
		if(_editor_form_appr_line.length > 0){

			_editor_form_appr_line.val(val); 

			_this.updateApprSettingData();
		} 	
        
    }

};