/**
 * 폼빌더 컴포넌트.
 * 
 * 타이틀 컴포넌트
 * 
*/

let CPDateBox = {

    CP_ID: null
    ,
    CP_TYPE: 'CPDateBox'
    ,
    CP_ITEM_TITLE : '날짜'
    ,
    getAttrView(prop) {

        let vwid = "att_tle";
        let template = `<div class="formbdTitle"><span>날짜 속성</span></div>
                        <ul class="formbdMenu">
                           <li>
                                <p class="formbdMenuTit">필수입력</p>
                                <div class="formbdMenuCon">
                                    <div class="btnWrap">
                                        <label  for="toggle" class="toggleSwitchBtn">
                                            <span id="cp_rdrequired" class="togglebtn"></span>
                                        </label>
                                    </div>
                                </div>
                            </li>
                        </ul>`;

        let $templ = $(template);

        return $templ;
    }
    ,
    addCompo(prop) {
    	
    	 let cpid = this.CP_ID = this.createCpid();
         let cptitle = this.CP_ITEM_TITLE;
         
         let template = `
             <div class="${this.CP_TYPE} previewoff tblformbdCon" id="${cpid}"><span>${cptitle}</span> <button type="button" class="k-button dltBtn groupTrash"></button></div>
             <div class='${this.CP_TYPE} previewon splitWrap' data-id="${cpid}"> 
                 <div class="splitBlock" id="pvdiv_${cpid}">          

                     <!-- preview area -->
                     
        	 		<input type="text" class="pview-kendo-date" id="pv_${this.CP_ID}" />

                 </div>
             </div>
             `;
         
        CPElemParent.addComp({
            cptype: CPDateBox.CP_TYPE
            , cpid: this.CP_ID
            , template: template
            , vwtemplate: CPDateBox.getAttrView()
        });



    }
    ,
    selectComp(prop) {

        this.CP_ID = prop.cpid;

        CPElemParent.selectComp({
            cptype: CPDateBox.CP_TYPE
            , cpid: this.CP_ID
            , vwtemplate: CPDateBox.getAttrView()
            , cp_attr_set_fn: CPDateBox.setAttItemHtml
            , data_attr: prop.data_attr
        });

    } 
    ,
    createCpid(){

        return CPDateBox.CP_TYPE + "_" + Math.floor(Math.random() * 10000);

    }

}
