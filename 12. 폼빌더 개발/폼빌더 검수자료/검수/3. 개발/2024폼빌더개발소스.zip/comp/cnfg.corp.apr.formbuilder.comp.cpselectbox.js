/**
 * 폼빌더 컴포넌트.
 * 
 * 드롭박스 컴포넌트
 * 
*/

let CPSelectBox = {

    CP_ID: null
    ,
    CP_TYPE: 'CPSelectBox'
    ,
    CP_ITEM_TITLE : '드롭박스'
    	
    ,
    MAX_LEN : 10
    ,
    getAttrView(prop) {

        let vwid = "att_tle";
        let template = `<div class="formbdTitle"><span>드롭박스 속성</span></div>
                        <ul class="formbdMenu">
                            <li>
                                <p class="formbdMenuTit">입력 항목</p>
                                <div class="formbdMenuCon">
                                    <ul class="radioAddList">
                                    </ul>                                    
                                </div>
                            </li>
                        </ul>`;

        let $templ = $(template);

        return $templ;
    }
    ,
    addCompo(prop) {

        let template = this.getCpHtml();

        CPElemParent.addComp({
            cptype: CPSelectBox.CP_TYPE
            , cpid: this.CP_ID
            , template: template
            , vwtemplate: CPSelectBox.getAttrView()
            , cp_attr_set_fn: CPSelectBox.setAttItemHtml
        });

    }
    ,
    selectComp(prop) {

        this.CP_ID = prop.cpid;

        CPElemParent.selectComp({
            cptype: CPSelectBox.CP_TYPE
            , cpid: this.CP_ID
            , vwtemplate: CPSelectBox.getAttrView()
            , cp_attr_set_fn: CPSelectBox.setAttItemHtml
            , data_attr: prop.data_attr
        });
        

    }
    ,
    getCpHtml(prop){

        let cpid = null;
        let cptitle = null;

        if(prop && prop.cpid){
            cpid = prop.cpid;
        }else{
            cpid = this.createCpid();
        }
        
        this.CP_ID = cpid;
        cptitle = CPSelectBox.CP_ITEM_TITLE;
        
        let template = `
            <div class="${this.CP_TYPE} previewoff tblformbdCon" id="${cpid}"><span>${cptitle}</span> <button type="button" class="k-button dltBtn groupTrash"></button></div>
            <div class='${this.CP_TYPE} previewon splitWrap' data-id="${cpid}"> 
                <div class="splitBlock" id="pvdiv_${cpid}">          

                    <!-- preview area -->
                    <select id="pv_${this.CP_ID}" data-role="dropdownlist" >
                    </select>


                </div>
            </div>
            `;
        
        return template;
    }
    ,
    addBtnEvt(prop) {

        let nidx = null;
        
        if(prop.idx){
            nidx = prop.idx;
        }
        else{

            nidx = Math.floor(Math.random() * 1000);
        }

        //attr 속성 텍스트 추가.
        htm = CPSelectBox.createAttrLi({
            idx: nidx
            , val: prop.val
            , name: prop.name
            , placehold: prop.placehold
        });
        
        $(document).on('keyup', '#cp_txradio' + nidx, function(e){

            let picidx = $(e.target).attr('idx');
            
            $('#pv_' + GB_CUR_STATE.CP_ID + "_" + picidx).html($(this).val());
            $('#pv_' + GB_CUR_STATE.CP_ID + "_" + picidx).attr('value',$(this).val());

            CPElemParent.applyAttrToElem(e);

        });

        GB_PROPS.attview.find('ul.radioAddList').append($(htm));
        
    	if($('#pv_' +GB_CUR_STATE.CP_ID).length == 0){
    		$('#pvdiv_' + GB_CUR_STATE.CP_ID).append($('<select id="pv_'+ GB_CUR_STATE.CP_ID +'" data-role="dropdownlist" ></select>'));
    	}
    	
    	$('#pv_' + GB_CUR_STATE.CP_ID).append(`<option id="pv_${GB_CUR_STATE.CP_ID}_${nidx}" value="${prop.val}">${prop.val}</option>`);

    }
    ,
    fnAddExec(e){
    	CPSelectBox.addBtnEvt({ 
            name: CPSelectBox.CP_ITEM_TITLE
            ,placehold: '입력'
            ,val: '입력'
        });

        
        CPElemParent.changeAttrViewHandler(e);
    }
    ,
    fnDelExec(e){
    	let picidx = $(e.target).attr('idx');
        CPSelectBox.delBtnEvt(picidx);

        CPElemParent.applyAttrToElem(e);
    }
    ,
    delBtnEvt(idx) {

        $(document).off('click', '#dltBtn' + idx);
        $(document).off('click', '#addBtn' + idx);
        $(document).off('keyup', '#cp_txradio' + idx );

        $('#cp_txradio' + idx).parent('div').parent('li').remove();

    	$('#pv_' + GB_CUR_STATE.CP_ID + "_" + idx).remove();


        CPCommon.console.log('delBtnEvt!!!!!!!!!!!!!', idx);
    }

    ,
    setAttItemHtml(data_attr) {

        let htm = '';
        let itemCnt = 0;

        $('#pv_' + GB_CUR_STATE.CP_ID).html('');


        if (data_attr && data_attr.length > 0) {

            let attrJson = CPElemParent.parseDataAttrToJson(data_attr);
            let keys = Object.keys(attrJson); //키를 가져옵니다. 이때, keys 는 반복가능한 객체가 됩니다.

            itemCnt = keys.length;


            $(keys).each((idx, key) => {

                if(key != '') {

                    let nidx = key.replace('cp_txradio', '');

                    CPSelectBox.delBtnEvt(nidx);

                    CPSelectBox.addBtnEvt({
                        idx: nidx
                        ,name: attrJson[key]
                        ,placehold: '입력'
                        ,val: attrJson[key]
                    });

                }

            });

        }
        else{

            CPSelectBox.addBtnEvt({
                name: CPSelectBox.CP_ITEM_TITLE
                ,placehold: '입력'
                ,val: '입력'
            });
        }
        
    }
    ,
    createAttrLi(prop) {

        return `<li>
                    <div class="radioAdd">
                        <input id="cp_txradio${prop.idx}" idx="${prop.idx}" cpid="${this.CP_ID}"  name="" style="width:100%;" class="k-textbox" type="text" maxlength="${CPSelectBox.MAX_LEN}" value="${prop.val}" placeholder="${prop.placehold}">
                        <button type="button" id="dltBtn${prop.idx}" idx="${prop.idx}" class="k-button dltBtn" onclick="CPSelectBox.fnDelExec(event)"></button>
                    </div>
                    <button type="button" id="addBtn${prop.idx}" idx="${prop.idx}" class="k-button addBtn" onclick="CPSelectBox.fnAddExec(event)"></button>
                </li>`
    }
   
    ,
    createCpid(){

        return CPSelectBox.CP_TYPE + "_" + Math.floor(Math.random() * 10000);

    }

}
