/**
 * 폼빌더 컴포넌트.
 * 
 * 조직도를 사용하는 컴포넌트
 * 사용자, 부서
 * 
*/
let CPOrganize = {

    CP_ID : null
    ,
    CP_TYPE : "CPOrganize"
    ,
    CP_ITEM_TYPE : null //호출시 지정.
    ,
    CP_ITEM_TITLE : null   
   
    ,
    getAttrView(prop){

        let vwid = "att_tle";
        let template = '';

        let $templ = $(template);

        return $templ;                
    }
    ,
    setTitle(){

        if(this.CP_ITEM_TYPE == "user"){
            this.CP_ITEM_TITLE = "사용자";
        }
        else if(this.CP_ITEM_TYPE == "recipient"){
        	this.CP_ITEM_TITLE = "수신자";
        }
        else{
            this.CP_ITEM_TITLE = "부서";
        }
    }
    ,
    addCompo(prop){

        this.CP_ITEM_TYPE = prop.itemType;

        this.setTitle();

        let template = this.getCpHtml(prop);
        
        let $attrview = this.getAttrView()

        CPElemParent.addComp({
            cptype: CPOrganize.CP_TYPE
            ,cpid: this.CP_ID
            ,template: template
            ,vwtemplate: $attrview
        });  
        
    }
    ,
    selectComp(prop){

        this.CP_ITEM_TYPE = prop.itemType;
        
        let $attrview = this.getAttrView()
        
        CPElemParent.selectComp({
            cptype: CPOrganize.CP_TYPE
            ,cpid: prop.cpid
            ,vwtemplate: $attrview
        });                
        
    }
    ,
    getCpHtml(prop){

        let cpid = null;
        let cptitle = null;

        if(prop && prop.cpid){
            cpid = prop.cpid;
            cptitle = prop.cptitle;
        }else{
            cpid = this.createCpid();
            cptitle = CPOrganize.CP_ITEM_TITLE;
        }
        
        this.CP_ID = cpid;
        
        return  `
        <div class="${this.CP_TYPE} ${this.CP_ITEM_TYPE} previewoff tblformbdCon" id="${cpid}"><span>${cptitle}</span> <button type="button" class="k-button dltBtn groupTrash"></button></div>
        <div class='${this.CP_TYPE} ${this.CP_ITEM_TYPE} previewon splitWrap' data-id="${cpid}"> 
            <div class="splitBlock">          

                <!-- 스크립트 입력 -->
                <button id="pv_${cpid}" class="pv_${this.CP_ITEM_TYPE} k-link k-state-selected k-state-focused">+ ${this.CP_ITEM_TITLE}추가</button>
                <div id="pv_${cpid}_input" class="formbdMenuCon initrequir" type="text" />
                <input id="pv_${cpid}_hidd" class="initrequir" type="hidden" />


            </div>
        </div>
        `;

    }
    ,
    createCpid(){

        return CPOrganize.CP_TYPE + '_' + Math.floor(Math.random() * 10000);

    }
    
    
}
