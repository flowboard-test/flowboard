/** 
let CPTable = {
    addComp(){}
    ,
    setState(){}
    ,
    selectComp(){}    
}
*/
let CPTable = {

    CP_TYPE : "CPTable"

    ,

    CP_ITEM_TITLE : "표 컴포넌트"    

    ,

    cpid : null

    ,   

    _table : null

    ,

    wrapID : 1
    
    ,
    focusOn : false

    ,
    msg : {
        "del" : "삭제 후 복구가 불가 합니다. 삭제를 진행 하시겠습니까?",
        "noEmpty" : "다른 셀을 선택해 주세요.",
        "noMatchMsg_tableSize" : "입력너비는 숫자와 콤마만 사용 가능합니다.",
        "noMatchMsg_onlyNumber" : "표컴포넌트 셀 설정은 숫자만 입력 가능합니다.",
        "noMatchMsg_numberLimit" : "표컴포넌트 행과 열은 10개 이내로 생성이 가능합니다.",
        "noMatchMsg_data" : "검색된 항목이 없습니다. 새로고침 후 이용 바랍니다.",
        "failMsg" : "스크립트 작동중 오류가 발생 했습니다. 새로고침 후 이용 바랍니다.",
        "no-row_col-data" : "동일한 줄의 행 혹은 열을 선택 가능합니다.",
        "mixed-row_col-data" : "행과 열을 혼합한 다중 선택은 불가능 합니다.",
        "has-col-data" : "선택한 열에 포한된 항목을 삭제 후 수정이 가능 합니다.",
        "has-row-data" : "선택한 행에 포한된 항목을 삭제 후 수정이 가능 합니다.",
        "has-merge-data" : "첫번째 영역을 제외한 나머지 영역에 포함된 항목을 삭제 후 표합치기가 가능 합니다.",
        "no-selected" : "선택된 항목이 없습니다. 테이블의 항목을 선택 후 이용 가능 합니다.",
        "merge-able-count" : "테이블의 연속된 행 혹은 열의 항목을 선택 후 표합치기 기능 이용 가능 합니다.",
        "noSwitch" : "선택한 항목들의 자리 이동은 불가능 합니다.",
        "noToolTipData" : "{{title}} 속성을 설정해 주세요.",
        "focusOut" : "표컴포넌트 초과 시 셀을 선택해야 합니다.",
        "colGrpCheck" : "세로 셀의 개수({{count}}개) 만큼 너비를 입력 하세요.",
    }
    ,

    alert( type = '' ){
        let _msg = this.msg[type];
        
        if( _msg ){ 
        	//alert(_msg);
	        layCmn.alert({
	            msg: _msg,
	            callback: function (e) { }
	        });
        }//else console.log("alert" , type);
    }

    ,

    updatelistener( prop ){
        

        //console.log( "updatelistener" , prop );


        /**
         *  포커스가 테이블을 벗어나면 선택된 항목을 초기화 해준다.
         */
        if( prop.cptype != this.CP_TYPE){

            this._table.selectflush();

        }

        

    }
   
    ,
    /**
     * 항목 추가시 항목들을 추적한다.
     */
    append(prop){      

        let result = false;
        let msg = "";

        if( prop.cptype != 'CPTable' && this.focusOn && $('.tableSelectOn').length == 0 ){

            this.focusOn = false;

            result = true;

            msg = "focusOut";

        //check in table
        }else if(  $('.tableSelectOn').length > 0 ){


            this.focusOn = true;

            result = true;

            //
            const _selectedTableItemWrap =  $('.tableSelectOn').first();
            const _selectedTableItem =  _selectedTableItemWrap.find('.changeWrap');

            //
            if( _selectedTableItem.html() == '' ){

                //tooltip(1/2)
                CPToolTip.setToolTipLayout(prop);

                const html = $(prop.template);

                _selectedTableItem.append($(html).addClass('containerItem'));
                _selectedTableItemWrap.removeClass('tableSelectOn');

                //
                this.flushItemsTableID();


                msg = "append";
            }else{
                msg = "noEmpty";
            }

            /**
             * item 추가시 td data안에 내용을 입력해 준다.
             */
            result = this._table.setItemData( _selectedTableItemWrap[0] );


            /*
            update last data
            */
            this._table.set_lastItem();

        }  

        return {result:result,msg:msg};
    }
    
    ,
    /**
     * 
     * 마우스를 이용한 항목이동을 위한 공통 사항
     * 
     */
    templateWrap(prop){

        //console.log( prop );

        let btnArea =`
        <button type="button" class="setUpbtn groupUp"></button>
        <button type="button" class="setDownbtn groupDown"></button>        
        `;

        if(prop.cptype == "CPTable"){
            btnArea +=`
            <button type="button" class="setDltbtn groupDel"></button>
            <button type="button" class="setSetbtn groupSetting"></button>
            `;
        }


       //tooltip(1/2)
       CPToolTip.setToolTipLayout(prop);


        return `
        <section class='formbdoverWrap _overOn sortAbleItem' data-id='${prop.cpid}' data-type='${prop.cptype}'>
            <div class='formbdoverBox moveIcon'>
                <div class="formbdmoveBtn" data-group="${this.wrapID++}"></div>
                <div class="formbdsetBtn">${btnArea}</div>
            </div>
            <div class="formbdoverArea">
            ${prop.template}
            </div>            
        </section>`;
    }
    ,

    getAttrView(prop){   

        
        let vwid = "att_tle";
        let template = `
                        <div id="div_${vwid}" class="formbdTitle"><span>표컴포넌트 속성</span></div>
                            <ul id="ul_${vwid}" class="formbdMenu">
                            
                            <li>
                                <p class="formbdMenuTit">표컴포넌트 만들기</p>
                                <div class="formBtnBox btngrid">
                                    <button type="button" class="k-button formBtn" id="cptable_row">행추가</button>
                                    <button type="button" class="k-button formBtn" id="cptable_delrow">행삭제</button>
                                    <button type="button" class="k-button formBtn" id="cptable_col">열추가</button>
                                    <button type="button" class="k-button formBtn" id="cptable_delcol">열삭제</button>
                                    <button type="button" class="k-button formBtn" id="cptable_merge">표합치기</button>
                                    <button type="button" class="k-button formBtn" id="cptable_splitcol">표나누기</button>
                                </div>
                            </li>                            
                            <li>
                                <p class="formbdMenuTit">표 컴포넌트 셀 설정</p>

                                <div class="formbdMenuCon">
                                                                      
                                    <span class="formbdMenuConT">가로</span>
                                    <input id="update_row" style="width:45px;" class="k-textbox mR5" type="number" maxlength="2" value="2">
                                     
                                    <button type="button" class="k-button formBtnNum" id="update_add_row"><img src="/resources/abc/images/new_images/common/btn_num_up.png" alt="up icon"></button>
                                    <button type="button" class="k-button formBtnNum" id="update_del_row"><img src="/resources/abc/images/new_images/common/btn_num_down.png" alt="down icon"></button>
                                     
                                </div>

                                <div class="formbdMenuCon mT5">                                 
                                                                     
                                    <span class="formbdMenuConT">세로</span>
                                    <input id="update_col" style="width:45px;" class="k-textbox mR5" type="number" maxlength="2" value="2">


                                    <button type="button" class="k-button formBtnNum" id="update_add_col"><img src="/resources/abc/images/new_images/common/btn_num_up.png" alt="up icon"></button>
                                    <button type="button" class="k-button formBtnNum" id="update_del_col"><img src="/resources/abc/images/new_images/common/btn_num_down.png" alt="down icon"></button>
                                    
                                    <button class="k-button" id="updateRowCol">적용</button>
                                    
                                </div>

                            </li>
                            <li>
                                <p class="formbdMenuTit disInline vM">입력 너비</p>
                                <span class="formbdicon_Question vM mB10"><p class="formbd_notes_wrap">예) 4개 열인 경우 10,10,10,70</p></span>

                                <div class="formbdMenuCon">
                                    <div class="dropdownArea">
                                        <span title="" class="k-widget k-dropdown k-header formbd_drop" unselectable="on" role="listbox" aria-haspopup="true" aria-expanded="false" tabindex="1" aria-owns="cp_tableWidthType_listbox" aria-disabled="false" aria-busy="false" style="width: 60px;" aria-activedescendant="39cf1a74-9738-460b-94eb-822ce8bf2ec0"><span unselectable="on" class="k-dropdown-wrap k-state-default">
                                        <span unselectable="on" class="k-input">%</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span></span>
                                        <input id="cp_tableWidthType" style="width: 60px; display: none;" class="formbd_drop" name="formbd_drop" type="text" value="" data-role="dropdownlist"></span>
                                    </div>
                                    <input id="cp_tableWidth" name="" style="width:150px;" class="k-textbox mL5" type="text" value="">
                                    <span id="cp_tableWidth_alert" class="alert"></span>                                   
                                </div>



                            </li>
                            
                        </ul> `;

        let $templ = $(template);


        var data = [
            { text: "%", value: "%" },
            { text: "px", value: "px" },
            //{ text: "em", value: "2" },
        ];
        $templ.find("#cp_tableWidthType").kendoDropDownList({
            dataTextField: "text",
            dataValueField: "value",
            dataSource: data,
            index: 0
        });

        return $templ;
    }

    ,
    innerAddCompo(col = 1 , row = 1){

        this.cpid = this.createCpid();
        let template = `
        <div id="${this.cpid}" class="${this.CP_TYPE} _dn">
        <table class='tbl_formbd'>
            <tr>
                <td></td>
            </tr>           
        </table>        
        </div>`;



        CPElemParent.addComp({
            cptype: this.CP_TYPE
            ,cpid: this.cpid
            ,template: template
            ,vwtemplate: this.getAttrView()
            //,cp_attr_set_fn: this.setAttItemHtml
        });
        


        //
        const _target = document.getElementById(this.cpid);
        let cnt = 0;
        let _wait = setInterval(() =>{
    
            //
            if( typeof(_target) == 'undefined' || _target == null ){
                if( cnt > 1000 ){
                    clearInterval(_wait); 
                }
                cnt++;
                return;
            } 		
        
            clearInterval(_wait);              
            
            
            const _table = this._table.makeTable(col , row);
            _target.querySelector('table').outerHTML = _table.outerHTML;            
            
            this._table.addTableData(_target.querySelector('table')); 

            this.change_row_col_data();
            this.flushItemsTableID();
            
        }, { passive: false });

    }
    ,
    setAttItemHtml(data_attr) {

        //console.log( "setAttItemHtml" , data_attr );
        
    }
    ,
    addCompo(prop){

        //open popup
        const popup = $("#cptableColRowEditorPopup");

        popup.removeClass('dn');

        let row = popup.find("#row").eq(0);
        let col = popup.find("#col").eq(0);

        row.val(2);
        col.val(2);

        this._table.selectflush();

        popup.removeClass('dn');

    }
    ,
    setState(){

        //console.log("cptable_" ,"setState");

    }
    ,
    selectComp(){

        //
        const attr = $(`#${this.cpid}`).attr('data_attr');
        let attrJson = CPElemParent.parseDataAttrToJson(attr);
        CPElemParent.applyElemToAttrView(attrJson); 


        //
        CPElemParent.selectComp({
            cptype: this.CP_TYPE
            ,cpid: this.cpid
            ,vwtemplate: this.getAttrView()
            ,data_attr: attr
        });    

        this.change_row_col_data();  
        //this.flushItemsTableID();   



        //kendo
        if(attrJson['cp_tableWidthType'])
            $("#cp_tableWidthType").data("kendoDropDownList").value(attrJson['cp_tableWidthType']);
        
    }    
    ,
    createCpid(){

        return 'cptable_' + Math.floor(Math.random() * 10000);

    }

    //changeAttrViewHandler


    ,

    listenPareantChangeData($target){

        //        
        if( 
            $target.attr('id') == "cp_tableWidthType" || 
            $target.attr('id') == "cp_tableWidth"
        ){
            this.set_tableWidth();
        }

        /*
        홈페이지 우측 속성창에서 input, select 수정 되는 것은 해당 위치에서 table안의 데이터를 일관 변경해 준다
        추가 수정이 있는 경우 개별 컴포넌트 에서 추가 으록해 줘야 함
        sample : CPCalculator > search //flush table data
        */
        //flush table data
        const CP_TargetObj = $(`#${GB_CUR_STATE.CP_ID}`);
        if( CP_TargetObj.length > 0 ){
            if( CP_TargetObj.closest("TD").length > 0 )       
            CPTable._table.setItemData( CP_TargetObj.closest('TD')[0] );
        }


        //tooltip(2/2)        
        CPToolTip.showPopToolTip();
        
        
    } 

    ,
    countCpCalculatorglobaltotalSameTable(){
        return GB_PROPS.bdview.find('.CPCalculatorglobaltotal').length;
    }

    ,
    countCpCalculatortotalSameTable(){
     
        let check = false;
        let count = 0;

        if( CPTable._table.gripDB.length > 0 ){   
            $(CPTable._table.gripDB[CPTable._table.last.gridIDX].items).each((_,tdh)=>{
                check = true;
                if( tdh.data != undefined && 
                    tdh.data.includes("CPCalculatortotal") ){

                        const formObj = new DOMParser().parseFromString(tdh.data, 'text/html');
                        let formItem = null;
                        try{    
                            formItem = formObj.querySelector(".CPCalculatortotal");  
                        }catch(e){        			

                        }finally{        			
                            if(formItem != null)count++; 
                        }  


                    } 
            });
        }   

        if( check == false ) return;
        
        return count;
    }

    ,
    countCpCalculatorRow(style='',skip=[],idx=null ,position=null){
     
        let check = false;
        let count = 0;

        if( CPTable._table.gripDB.length > 0 ){  

            if( idx == null )idx = CPTable._table.last.gridIDX;
            if( position == null )position = CPTable._table.last.position.y;

            $(CPTable._table.gripDB[idx].result[position-1]).each((_,tdh)=>{
                check = true;

                //if skip
                if( skip.includes( tdh.no.toString() ) ) return true;
                
                if( tdh.data != undefined && tdh.data.includes("CPCalculator")){
                    if( style != '' ){
                        if(tdh.data.replaceAll("'","\"").toLowerCase().includes(`data-style="${style.toLowerCase()}"`)) 
                            count++;
                    }else{
                        count++;
                    }
                }  
            });
        }   

        if( check == false ) return;
        
        return count;
    }

    ,
    countCpCalculatorCol(style='',skip=[],idx=null ,position=null){

        let check = false;
        let count = 0;        

        if( CPTable._table.gripDB.length > 0 ){ 

            if( idx == null )idx = CPTable._table.last.gridIDX;
            if( position == null )position = CPTable._table.last.position.x;

            $(CPTable._table.gripDB[idx].result).each((_,tr)=>{
                
                check = true;
                const tdh = tr[position-1];

                //if skip
                if( tdh.no != undefined && skip.includes( tdh.no.toString() ) ) return true;

                if( tdh.data != undefined && tdh.data.includes("CPCalculator")){
                    if( style != '' ){
                        if(tdh.data.replaceAll("'","\"").toLowerCase().includes(`data-style="${style.toLowerCase()}"`)) 
                            count++;
                    }else{
                        count++;
                    }
                }  

            });

        }

        if( check == false ) return;
        
        return count;
    }

    ,

    inCPCalculator(){

        let count = 0;

        $('.tableSelectOn').each((_,tdh)=>{

            let _line = null;
            const items = CPTable._table.gripDB[CPTable._table.last.gridIDX].items;
            const itemDB = CPTable._table.gripDB[CPTable._table.last.gridIDX].result;
            const _itemID = CPTable._table.get_itemid(tdh);

            $(items).each((_,itm)=>{
                if(itm.no == _itemID){
                    _line = itm.position.y;
                    return false;
                }
            });

            if( _line != null && _line > 0 ){
                $(itemDB[_line-1]).each((__,_tdh)=>{
                    if( _tdh.data != undefined && 
                        _tdh.data.includes("CPCalculator") &&
                        _tdh.data.includes("CPCalculatortotal") == false &&
                        _tdh.data.includes("CPCalculatorglobaltotal") == false
                    ) count++;                    
                });
            }

        });


        if(count == 0 ) return false;
        return true;

    }

    ,
    isMerged(){

        let check = false;
        let result = null;

        if( CPTable._table.gripDB.length > 0 ){  
            
            $(CPTable._table.gripDB[CPTable._table.last.gridIDX].result[CPTable._table.last.position.y-1]).each((_,tdh)=>{

                check = true;
                if(result != 'isMerged' && tdh != CPTable._table.blankAreaID && tdh.row == 1){
                    result = 'isNoMerged';                                                                  
                }else{
                    result = 'isMerged';  
                    return false;   
                }
            });
        }   

        if( check == false ) return;
        
        return result;
    }

    ,
    targetTDisNoMergeCheck( cpid = '' ){

        if( cpid == '') return CPTable.alert("noMatchMsg_data");

        let result = null;
        let _tableID = null;
        const _tableObj = $(`#${cpid}`).closest("table");
        const _tdObj = $(`#${cpid}`).closest("td");       
       
        if( _tableObj.length == 0 || _tdObj.length == 0 ) return CPTable.alert("noMatchMsg_data");
        
        const _itemID = CPTable._table.get_itemid(_tdObj[0]);
        
        try{

            _tableID = CPTable._table.get_wrapid( _tableObj[0] );                

        }catch(e){

            CPTable.alert("noMatchMsg_data");
                
        }finally{

            if( _tableID != null && CPTable._table.gripDB.length > 0 ){

                

                CPTable._table.gripDB.some((db,idx)=>{
                    if( db.no == _tableID){

                        let _line = null;

                        $(db.items).each((_,itm)=>{
                            if(itm.no == _itemID){
                                _line = itm.position.y;
                                return false;
                            }
                        });

                        if( _line != null && _line > 0 ){

                            $(db.result[_line-1]).each((_,tdh)=>{
                                if(result != 'isMerged' && tdh != CPTable._table.blankAreaID && tdh.row == 1){
                                    result = 'isNoMerged';                                                                  
                                }else{
                                    result = 'isMerged';  
                                    return false;   
                                }
                            });

                        }

                    }
                });
            }
        }

      return result;
    }
    
    ,
    set_tableWidth(){

        const __cp_tableWidth = $("#cp_tableWidth").val();
        const __cp_tableWidthType = $("#cp_tableWidthType").val();
        const _target = $(`#${this.cpid}`);

        if( __cp_tableWidth && __cp_tableWidth.search(/\s/) != -1) {
            this.alert('noMatchMsg_tableSize');
            return true;
        }

        //if comma
        let _split = __cp_tableWidth.split(",");

        //or blank
        //if( _split.length == 1 ) _split = __cp_tableWidth.val().split(" ");            

        const widths  = _split.filter((item)=>item !== null && item !== undefined && item !== '');

        //
        if(widths.length == 0){
            this._table.fixTableColGroupWidth( _target.children('table')[0] , 0 , '*' );
            return;
        }

        //
        widths.some(( width , idx )=>{

            let _width = width.replace(/\s+/g, '');                             

            //if only number
            if(!/^[0-9]*$/.test(_width)){
                this.alert('noMatchMsg_tableSize');
                return true;
            }

            _width += __cp_tableWidthType;

            this._table.fixTableColGroupWidth( _target.children('table')[0] , idx , _width );
                
        });


        //
        this.col_check_alert();

    }

    ,

    addHtml(){

        const _wrap = $('#wrap');


        

        /**
         * col - row - edit - popup - html
         */
        if( _wrap.find('#cptableColRowEditorPopup').length == 0){
            
            _wrap.append(

            `    
            <!-- layer popup -->
            <div id="cptableColRowEditorPopup" class="k-overlay dn">
                <div id="popupWrap" class="k-widget k-window" data-role="draggable">
                    <div class="k-window-titlebar k-header" style="margin-top: -44px;">
                        &nbsp;<span class="k-window-title" id="">표 컴포넌트 셀 설정</span>
                        <div class="k-window-actions" id='close' >
                            <a role="button" href="#none" class="k-window-action _k-link" aria-label="Close"><span class="k-icon k-i-close"></span></a>
                        </div>
                    </div>
        
                    <div id="" data-role="window" class="layerpopup k-window-content k-content" tabindex="0" role="dialog" aria-labelledby="" style="">
        
                        <!-- 표 컴포넌트 셀 설정 -->
                        <div class="k-grid k-widget formbuilderlayer">
                            <div class="formbuildertbl" style="max-height: 420px; overflow-y: auto;">                    
                                <table class="tbl_tr" style="width:100%;">
                                    <colgroup>
                                        <col width="80px;">
                                        <col width="*;">
                                    </colgroup>
                                    <tbody>
                                        <tr>
                                            <th>가로</th>
                                            <td>
                                                <input id="row" name="" style="width:90px;" class="k-textbox" type="number" maxlength="2" value="2">
                                                <span class="k-link iconBtnWrap">
                                                    <button class="k-button k-iconBtn" title="up" id="rowUp"><span class="k-icon k-i-arrow-u"></span></button>
                                                    <button class="k-button k-iconBtn" title="down" id="rowDown"><span class="k-icon k-i-arrow-d"></span></button>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>세로</th>
                                            <td>
                                                <input id="col" name="" style="width:90px;" class="k-textbox" type="number" maxlength="2" value="2">
                                                <span class="k-link iconBtnWrap">
                                                    <button class="k-button k-iconBtn" title="up" id="colUp"><span class="k-icon k-i-arrow-u"></span></button>
                                                    <button class="k-button k-iconBtn" title="down" id="colDown"><span class="k-icon k-i-arrow-d"></span></button>
                                                </span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="btn_wrap">
                                <button class="k-button" id='save'>확인</button>
                                <button class="mailsendBtn mL3" id='close'>취소</button>
                            </div>
                        </div>
                        <!-- //표 컴포넌트 셀 설정 -->
                        
                    </div>
                </div>
            </div>
            <!-- //layer popup -->
            `        
            );

        }


    }
    ,


    init(){

        //this.builder.load();  
    	
    	

    	CPTable._table = this.builder;
    	CPTable._table.load();
    	
        
        
    	//if has parent data
    	if(GB_PROPS.canReadParent 
    		&& GB_CUR_STATE.DOC_ID != undefined 
    		&& GB_CUR_STATE.DOC_ID.length > 0){  
    		    		
    		let onUseCount = 0;
    		let onUseWait = setInterval(() =>{
    			
    			if( builderDocList.getContentCheck != "finished" ){
    				if( onUseCount > 1000 ){
    					clearInterval(onUseWait); 
    				}
    				onUseCount++;
    				return;
    			} 	    			
    		
    			clearInterval(onUseWait); 	
    			
    			CPTable._table.flushAllTable();
    			
    			/*
    			//CPApprovalline의 데이터 값을 보정해 준다.
    			const _editor_form_appr_line = $("#editor_form_appr_line");
    			if( _editor_form_appr_line.length > 0 && _editor_form_appr_line.val() == "" ){
    				   
    				//_editor_form_appr_line.val( $('#form_appr_line', GB_PROPS.parentObj).val());
    				_editor_form_appr_line.val( $('#form_appr_line', parent.opener.document).val());
    			}
    			*/


    		}, { passive: false });
    		
    	}
    	
    	
    	

        this._draggableGroupAndSwitchItem = this.draggableGroupAndSwitchItem;
        this._draggableGroupAndSwitchItem.load();

        

        
        /*
        //table builder        
        this._table = 
        new tableBuilder({
            targetID : '#layContent table.tablebuilder_',
            defaultForm : '<div class=\"changeWrap\" data-no=\"dcgm___${{random}}\"></div>',
            removeID : ['.__draggableGroup' ,'#sampleID'],
            skipObj : ['.__changeWrap'],
            initTableFlush : 'table',
            builderName : 'tablebuilder'	,
            builderWrapName : '_'	,	
        
        },( json )=>{ 
        
            console.log( "tableBuilder" , json );
        
        });  
        */      
        
        
        this.addHtml();

        this.listener();

        //console.log("table init" , this._table);

        

    }

    ,
    /*
     * 
     */
    groupUpdown( type='up' , target = null ){

        if( target == null ) return; 

        const _items = $('.sortAble .sortAbleItem');

        _items.each(function(idx,item){

            let go = false;
            let targetIdx = null;

            if( target == item ){                

                //
                if( idx > 0 && type == 'up'){ 
                    go = true;          
                    targetIdx = idx-1;            
                }else if( ( idx + 1 ) < _items.length && type == 'down'){
                    go = true;          
                    targetIdx = idx+1;
                }

                //
                if(go){
                    const _outerHTML = _items[targetIdx].outerHTML;
                    _items[targetIdx].outerHTML = item.outerHTML;
                    _items[idx].outerHTML = _outerHTML;
                }                
                
            }
            
        });

    }

    ,
    addTwinkle(changeWrapA =null , changeWrapB=null , type ='B'){

        //console.log("addTwinkle" , changeWrapA );

        if( changeWrapA == null ) return;

        let resultArray = [];
        let initTarget = [];
        let finishTarget = [];
        let useable = false;

        //basic
        if( changeWrapA != null )
            initTarget =[
                $(changeWrapA).find(`.previewon.CPCalculator`).attr("data-id")
                ,
                $(changeWrapA).find(`.previewon.CPCalculatortotal`).attr("data-id")
                ,
                $(changeWrapA).find(`.previewon.calculator`).attr("data-col-target")
                ,
                $(changeWrapA).find(`.previewon.calculator`).attr("data-row-target")
                ,
                $(changeWrapA).find(`.previewon.calculator`).attr("data-total-target")
                ,
                $(changeWrapA).find(`.previewon.calculatortotal`).attr("data-global-target")
            ];

        if( changeWrapB != null )
            finishTarget =[
                $(changeWrapB).find(`.previewon.CPCalculator`).attr("data-id")
                ,
                $(changeWrapA).find(`.previewon.CPCalculatortotal`).attr("data-id")
                ,
                $(changeWrapB).find(`.previewon.calculator`).attr("data-col-target")
                ,
                $(changeWrapB).find(`.previewon.calculator`).attr("data-row-target")
                ,
                $(changeWrapB).find(`.previewon.calculator`).attr("data-total-target")
                ,
                $(changeWrapB).find(`.previewon.calculatortotal`).attr("data-global-target")
            ];




        /*
        B : 배타적 논리합
        */
        if( type =="B" && finishTarget.length > 0 ){
            resultArray = initTarget.filter(x => !finishTarget.includes(x)).concat(finishTarget.filter(x => !initTarget.includes(x))); 

        }else{

            resultArray = initTarget;

        }

        /*
        DEL : 삭제
        */
        if( type =="DEL" ){           
            //console.log("twinkle DEL array " , resultArray); 
            $(resultArray).each((_,twk)=>{

                if( $(`#${twk}`).length > 0 ){               
    
                    const _table = $(`#${twk}`).closest('table');                
                    $(_table).find(`.previewon.calculator,.previewon.calculatortotal,.previewon.calculatorglobaltotal`).each((_,item)=>{
    
                        if( $(item).attr('data-row-target') == twk ){                            
                            $(item).removeAttr('data-row-target');
                            CPCalculator.flushItems(_table);
                        }
    
                        if( $(item).attr('data-col-target') == twk ){
                            $(item).removeAttr('data-col-target');
                            CPCalculator.flushItems(_table);
                        }

                        if( $(item).attr('data-total-target') == twk ){
                            $(`#${twk}`).addClass('twinkle');                
                            $(`#${twk}`).addClass('twinkle102');
                        }

                        if( $(item).attr('data-global-target') == twk ){
                            $(`#${twk}`).addClass('twinkle');                
                            $(`#${twk}`).addClass('twinkle102');
                        }
                    });            
    
                }
                
            });
        }      

        //show twinkle
        if( useable == false ){
            $(resultArray).each((_,twk)=>{

                if( $(`#${twk}`).length > 0 ){               
    
                    const _table = $(`#${twk}`).closest('table');                
                    $(_table).find(`.previewon.calculator`).each((_,item)=>{

                        if( $(item).attr('data-id') == twk ){
                            useable = true;
                            return false;
                        }
    
                        if( $(item).attr('data-row-target') == twk ){
                            useable = true;
                            return false;
                        }
    
                        if( $(item).attr('data-col-target') == twk ){
                            useable = true;
                            return false;
                        }
                    });            
    
                }
                
            });
        }
        

        //
        if(useable){
            $(resultArray).each((_,twk)=>{
                $(`#${twk}`).addClass('twinkle');                
                $(`#${twk}`).addClass('twinkle101'); 
            });
        }

    }

    ,

    listener(){

        const _this = this;


        /**
         * col - row - edit - popup
         */
        const popup = $("#cptableColRowEditorPopup");
        popup.on("click", "#close", function () {

            popup.addClass('dn');

        }).on("click", "#rowUp", function () {

            let row = popup.find("#row").eq(0);
            let count = Number(row.val());
            row.val( count >= 10 ? 10 : count + 1);

        }).on("click", "#rowDown", function () {

            let row = popup.find("#row").eq(0);
            let count = Number(row.val());
            row.val( count <= 1 ? 1 : count - 1);  

        }).on("click", "#colUp", function () {

            let col = popup.find("#col").eq(0);
            let count = Number(col.val());
            col.val( count >= 10 ? 10 : count + 1);

        }).on("click", "#colDown", function () {

            let col = popup.find("#col").eq(0);
            let count = Number(col.val());
            col.val( count <= 1 ? 1 : count - 1);            

        }).on("click", "#save", function () {

            let row = popup.find("#row").eq(0);
            let col = popup.find("#col").eq(0);

            if( !$.isNumeric(row.val()) || !$.isNumeric(col.val()) ){

                _this.alert("noMatchMsg_onlyNumber");

            }else if( 
                row.val() < 1 || 
                col.val() < 1 || 
                row.val() > 10 || 
                col.val() > 10
            ){

                _this.alert("noMatchMsg_numberLimit");

            }else{

                _this.innerAddCompo(col.val() , row.val() );
                popup.addClass('dn');

            }        

        });


        //group btn
        $(document).on("click", ".groupUp", function (event) {

            _this.groupUpdown( 'up', event.target.closest(`.sortAbleItem`) );

        }).on("click", ".groupDown", function (event) {

            _this.groupUpdown( 'down', event.target.closest(`.sortAbleItem`) );

        }).on("click", ".groupSetting", function (event) {


            const _sortAbleItem = event.target.closest(`.sortAbleItem`);
            const _cpid = _sortAbleItem.dataset.id;
            const _cpType = _sortAbleItem.dataset.type;

            if( _cpType =='CPTable' ){

                eval(`${_cpType}.cpid = '${_cpid}';`);
                eval(`${_cpType}.selectComp();`);

            }


        //테이블 삭제
        }).on("click", ".groupDel", function (event) {

            if( confirm( _this.msg.del ) == false ) return;

            event.stopPropagation();     

            const _sortAbleItem = event.target.closest(`.sortAbleItem`);
            const _cpType = _sortAbleItem.dataset.type;

            _sortAbleItem.remove();

            if( _cpType =='CPTable' ){
                CPTable._table.flushAllTable();
            }


        //테이블 안의 아이템 삭제
        }).on("click", ".groupTrash", function (event) {   

            if( confirm( _this.msg.del ) == false ) return;

            event.stopPropagation();            

            const _table = event.target.closest(`table`);

            //확인이 필요한 아이템을 표시한다.
            CPTable.addTwinkle(event.target.closest(`.changeWrap.calculator`),[],"DEL");
            CPTable.addTwinkle(event.target.closest(`.changeWrap.calculatortotal`),[],"DEL");
            CPTable.addTwinkle(event.target.closest(`.changeWrap.calculatorglobaltotal`),[],"DEL");



            //필요없는 class를 삭제
            const _CPCalculatortotal = event.target.closest(`.CPCalculatortotal.previewoff`);
            if(_CPCalculatortotal != null){

                const _ID = $(_CPCalculatortotal).attr('id');

                $(_table).find('.CPCalculator.previewon').each((_,itm)=>{
                    //twinkle
                    if( _ID == $(itm).attr('data-total-target') ){
                        const _CPCalculatortotal = $(itm).closest(`.changeWrap.calculator`);
                        _CPCalculatortotal.removeClass(CPCalculatortotal.onOffClass);
                        _CPCalculatortotal.find(".previewon").removeClass(CPCalculatortotal.onOffClass);
                        _CPCalculatortotal.find(".previewoff").removeClass(CPCalculatortotal.onOffClass);
                    }                     
                                          
                });
            }

            //필요없는 class를 삭제
            const _CPCalculatorglobaltotal = event.target.closest(`.CPCalculatorglobaltotal.previewoff`);
            if(_CPCalculatorglobaltotal != null){

                const _ID = $(_CPCalculatorglobaltotal).attr('id');

                $(_table).find('.CPCalculatortotal.previewon').each((_,itm)=>{
                    //twinkle
                    if( _ID == $(itm).attr('data-global-target') ){
                        const _CPCalculatorglobaltotal = $(itm).closest(`.changeWrap.calculatortotal`);
                        _CPCalculatorglobaltotal.removeClass(CPCalculatorglobaltotal.onOffClass);
                        _CPCalculatorglobaltotal.find(".previewon").removeClass(CPCalculatorglobaltotal.onOffClass);
                        _CPCalculatorglobaltotal.find(".previewoff").removeClass(CPCalculatorglobaltotal.onOffClass);
                    }                        
                                 
                });
            }



            
            //
            let _target =  null;  
            if( _target = event.target.closest(`.changeWrap`) ){               

                _target.innerHTML = "";

                //flush-changeWrap(1/2)
                _target.classList.value = "changeWrap";

            }else if( _target = event.target.closest(`.sortAbleItem`) ){
                _target.remove();
            }


            //flush
            GB_PROPS.attview.html('');

            GB_CUR_STATE.CP_ID = null;

            _this.flushItemData();

            _this.flushItemsTableID();

            //_this.flushCPCalculator();
            
        });


        $(document).on("click", "#update_add_row", function () { 

            let row = $("#update_row").eq(0);

            row.val( Number(row.val()) + 1 );

            $("#updateRowCol").click();

        });

        $(document).on("click", "#update_del_row", function () { 

            let row = $("#update_row").eq(0);

            row.val( Number(row.val()) - 1 );

            $("#updateRowCol").click();

        });

        $(document).on("click", "#update_add_col", function () { 

            let row = $("#update_col").eq(0);

            row.val( Number(row.val()) + 1 );

            $("#updateRowCol").click();

        });

        $(document).on("click", "#update_del_col", function () { 

            let row = $("#update_col").eq(0);

            row.val( Number(row.val()) - 1 );

            $("#updateRowCol").click();

        });

        /**
         * col - row - update
         */        
        $(document).on("click", "#updateRowCol", function () {  
            
            let row = $("#update_row").eq(0);
            let col = $("#update_col").eq(0);

            if( !$.isNumeric(row.val()) || !$.isNumeric(col.val()) ){

                _this.alert("noMatchMsg_onlyNumber");

            }else if( 
                row.val() < 1 || 
                col.val() < 1 || 
                row.val() > 10 || 
                col.val() > 10
            ){

                if(  row.val() < 1 ) row.val(1);
                if(  col.val() < 1 ) col.val(1);
                if(  row.val() > 10 ) row.val(10);
                if(  col.val() > 10 ) col.val(10);

                _this.alert("noMatchMsg_numberLimit");

            }else{

                
                const _tableObj = $(`#${_this.cpid}`).find("table");
                let _tableID = null;

                if( _tableObj.length == 0 ){
                    _this.alert("noMatchMsg_data");
                    return;
                } 

                try{

                    _tableID = _this._table.get_wrapid( _tableObj[0] );                

                }catch(e){

                    _this.alert("noMatchMsg_data");
                    
                }finally{

                    if( _tableID != null && _this._table.gripDB.length > 0 ){
                        _this._table.gripDB.some((db,idx)=>{
                            if( db.no == _tableID){

                                //     
                                const totalCol = db.totalCol;
                                const totalRow = db.totalRow;

                                let checkData = null;

                                if( row.val() == totalRow && col.val() == totalCol ){
                                    return;
                                }

                                /*
                                if( row.val() < totalRow || col.val() < totalCol ){
                                    _this.change_row_col_data();
                                    CPTable.alert('fail-add-row-col');
                                    return;
                                }
                                */  
                                
                                let roof = 4;
                                while( roof > 0 ){

                                    let countColRow = 0;
                                    let changeType = "";                                    

                                    switch(roof){                                        

                                        //add row
                                        case 4:
                                        if( row.val() > totalRow ){
                                            countColRow = row.val() - totalRow;
                                            changeType = "addRow";
                                        }
                                        break;

                                        //add col
                                        case 3:
                                        if( col.val() > totalCol ){
                                            countColRow = col.val() - totalCol;
                                            changeType = "addCol";                                                
                                        }
                                        break;

                                        //del row
                                        case 2:
                                        if( totalRow > row.val() ){
                                            countColRow = totalRow - row.val();
                                            changeType = "delRow";                                                 
                                        }
                                        break;

                                        //del col
                                        case 1:
                                        if( totalCol > col.val() ){
                                            countColRow = totalCol - col.val();
                                            changeType = "delCol";  
                                        }
                                        break;                                            
                                    }

                                    while( changeType && countColRow > 0){

                                        const lastItem = db.items[db.items.length-1]; 

                                        _this._table.last = {
                                            wrapID :_tableID
                                            ,
                                            itemID :lastItem.no
                                            ,
                                            gridIDX : idx
                                            ,
                                            position : lastItem.position
                                        };                             

                                        _this._table.set_position();

                                        checkData = _this._table.changeTable(changeType);

                                        if(checkData.result == 'fail'){
                                            CPTable.alert(checkData.msg); 
                                            break;
                                        }

                                        countColRow--;
                                    }
                                    

                                    roof--;
                                }

                                //
                                _this.change_row_col_data();

                                //
                                _this._table.selectflush();

                                return true;
                            }                            
                        });
                    }

                }


             

                /*
                _this.innerAddCompo(col.val() , row.val() );
                popup.addClass('dn');
                */

                //_this._table.replace_row_col(  row.val() , col.val() );


              

            }

        })


        /*
         * row - col - button
         */
        const layContent = $("#layContent");
        layContent.on("click", "#cptable_row", function () {

            if( $("#update_row").eq(0).val() >= 10 ){
                _this.alert("noMatchMsg_numberLimit");
                return;
            }

            _this._table.changeTable("addRow");
            _this.change_row_col_data();
            _this.flushItemsTableID();

        }).on("click", "#cptable_delrow", function () {

            _this._table.changeTable("delRow");
            _this.change_row_col_data();
            _this.flushItemsTableID();

        }).on("click", "#cptable_col", function () {

            if( $("#update_col").eq(0).val() >= 10 ){
                _this.alert("noMatchMsg_numberLimit");
                return;
            }

            _this._table.changeTable("addCol");
            _this.change_row_col_data();
            _this.flushItemsTableID();

        }).on("click", "#cptable_delcol", function () {

            _this._table.changeTable("delCol");
            _this.change_row_col_data();
            _this.flushItemsTableID();

        }).on("click", "#cptable_merge", function () {

            //연산식 적용된 행은 합칠 수 없다.
            if(_this.inCPCalculator()){
                CPCalculator.alert("noMerge");
                return;
            }

            _this._table.changeTable("merge");
            _this.change_row_col_data();
            _this.flushItemsTableID();

        }).on("click", "#cptable_splitcol", function () {

            _this._table.changeTable("split");

            _this.change_row_col_data();
            _this.flushItemsTableID();

        });

    }
    ,
    change_row_col_data(){

        const data = this._table.getTableSize();

        if( data == null ) return;

        $("#update_row").val(data.totalRow);
        $("#update_col").val(data.totalCol);

        this.set_tableWidth();        
    }

    ,
    col_check_alert(){

        //입력 너비 개수와 열의 개수가 다르면 경고를
        if( $("#update_col").length > 0 && $("#cp_tableWidth").length > 0 && $("#cp_tableWidth").val() != "" ){
            const colGrpCount = $("#cp_tableWidth").val().split(",").length;
            const colCount = Number($("#update_col").val());
            if( colGrpCount != colCount ){
                $("#cp_tableWidth_alert").html("*"+this.msg['colGrpCheck'].replace("{{count}}",colCount));
            }else{
                $("#cp_tableWidth_alert").html("");
            }                   
        }

    }
    ,
    flushItemsTableID(){        

        $(".pv_table_id").each(function(_, item){

            if( $(item).closest('.CPCalculatortotal').length > 0  ){
                return false;
            } 

            const _itemID =  $(item).closest(`td`).find(".itemID").attr("data-id");
            $(item).html(_itemID);
        });

    }
    ,
    flushItemData(){

        $(".changeWrap").each(function(_, item){ 
            
            //flush-changeWrap(2/2)
            if( $(item).html() == "" )
                item.classList.value = "changeWrap";            

            if($(item).closest('TH')[0])
                CPTable._table.setItemData( $(item).closest('TH')[0] );
            else if($(item).closest('TD')[0])
                CPTable._table.setItemData( $(item).closest('TD')[0] );
            else
                CPTable.alert("failMsg"); 

        });

    }
    ,
    flushCPCalculator(target = []){

        //console.log("!!!!!flushCPCalculator");


        /*
        * 함수 기능 이용시
        */
         if(  $(".CPCalculator").length > 0 && typeof CPCalculator == 'object' ){

            //포커스를 잃었을 경우
            //if( GB_CUR_STATE.CP_ID == null || GB_CUR_STATE.CP_ID != _CPCalculatorID_B){
                $(".changeWrap").each(function(_, item){ 
                    if(target[1] == $(item).attr('data-no')){

                        
                        let __getID = $(item).find(".CPNumber.previewon").attr('data-col-target');
                        if(__getID != undefined){
                            //$(`#${__getID}`).addClass('twinkle');
                            //$(`#${__getID}`).addClass('twinkle003');
                        }

                        let _getID = $(item).find(".CPNumber.previewon").attr('data-row-target');

                        if(_getID == undefined)
                            _getID = $(item).find(".CPCalculator.previewon").attr('data-id');                        

                        if(_getID != undefined){

                            //$(`#${_getID}`).addClass('twinkle');
                            //$(`#${_getID}`).addClass('twinkle004');

                            //
                            /*
                            CPCalculator.selectComp({
                                cpid: _getID
                                ,data_attr : $(`#${_getID}`).attr("data_attr")
                            });
                            */

                            return false;                            
                        }
                    }
                });

                $(".changeWrap").each(function(_, item){ 
                    if(target[1] == $(item).attr('data-no')){

                        let _getID = $(item).find(".CPCalculator.previewon").attr('data-total-target');      
                        
                        if(_getID != undefined){
                            //$(`#${_getID}`).addClass('twinkle');
                            return false;                            
                        }

                        if(_getID == undefined)
                            _getID = $(item).find(".CPCalculatortotal.previewon").attr('data-id'); 

                        if(_getID != undefined){
                            //
                            CPCalculatortotal.selectComp({
                                cpid: _getID
                                ,data_attr : $(`#${_getID}`).attr("data_attr")
                            });
                            return false;                            
                        }


                    }
                });

                $(".changeWrap").each(function(_, item){ 
                    if(target[1] == $(item).attr('data-no')){

                        let _getID = $(item).find(".CPCalculatorglobaltotal.previewon").attr('data-id');                        

                        if(_getID != undefined){

                            //$(`#${_getID}`).addClass('twinkle');

                            //
                            CPCalculatorglobaltotal.selectComp({
                                cpid: _getID
                                ,data_attr : $(`#${_getID}`).attr("data_attr")
                            });
                            return false;                            
                        }
                    }
                });
                
            //}


            //CPCalculator.flushItems();
            //CPCalculator.checkCalculatorData(_CPCalculatorID);

            /*
            CPCalculator.useableItemLists();              
            CPCalculator.checkCalculatorData();
            CPCalculatortotal.checkCalculatorData();
            CPCalculatorglobaltotal.checkCalculatorData();
            */
        }


        //
        /*
        const _tables = [];
        $(".changeWrap").each(function(_, item){ 

            //console.log("table" , item , $(item).find(".calculator") );

            if(
                $(item).find(".CPCalculator") && 
                $(item).closest('table').length > 0 && 
                _tables.includes($(item).closest('table')[0]) == false 
            ){
                //_tables.push($(item).closest('table')[0]);

                //CPCalculator.flushItems($(item).closest('table')[0]);

                console.log("table - switch B");

            }


            if(
                $(item).find(".calculator") && 
                $(item).closest('table').length > 0 && 
                _tables.includes($(item).closest('table')[0]) == false 
            ){
                _tables.push($(item).closest('table')[0]);

                console.log("table - switch C" , item);

                //CPCalculator.flushItems($(item).closest('table')[0]);
            }

        });
        */

    }
    ,
    builder : {        
        options : {
            targetID : '#layContent table.tbl_formbd',
            defaultForm : '<div class=\"formbdItem\"><p class=\"itemID tblformbdTxt\" data-id=\"${{itemID}}\">${{itemID}}</p><div class=\"changeWrap\" data-no=\"dcgm___${{random}}\"></div></div>',
            removeID : [],
            skipObj : ['.changeWrap'],
            initTableFlush : 'table',
            builderName : 'tbl_form',
            builderWrapName : 'bd'	,
            builderWrapItem : 'Item',
        }
        ,
        blankAreaID : "blocked"
        ,    
        tabSelectedClass : 'tableSelectOn'
        ,        
        targetType : null
        ,        
        gripDB : []
        ,         
        last : {
            wrapID :null
            ,
            itemID :null
            ,
            gridIDX : null
            ,
            position : null
        }
        ,
        Onlistener : false
        ,

        load(){

            this.name = this.options.builderName;
            this.wrapName = this.name + this.options.builderWrapName;
            this.itemName = this.name + this.options.builderWrapItem;
            
            
            if( !this.init() ){
                return;           
            }

            this.replaceAllTable();  
            this.listener();

        }
        ,
        clone( obj , target ) {
            if (obj === null || typeof(obj) !== 'object')  return obj;
    
            let copy = obj.constructor();	  
    
            for (let attr in obj) {
                if (target.hasOwnProperty(attr)) copy[attr] = target[attr];
                else copy[attr] = obj[attr];		
            }
    
        return copy;
        }
        ,
        init(){
            return false;
        }
        ,
        selectflush(){

            document.querySelectorAll(`.${this.tabSelectedClass}`).forEach((item)=>{
                item.classList.remove(this.tabSelectedClass);                        
            });   
            
            this.last = {
                wrapID :null
                ,
                itemID :null
                ,
                gridIDX : null
                ,
                position : null
            };
    
        }
        ,
        flushAllTable(){
        	
        	//
            document.querySelectorAll(`.${this.tabSelectedClass}`).forEach((item)=>{
                item.classList.remove(this.tabSelectedClass);                        
            });            
        	
        	 this.gripDB = []; 
             
             //
             this.getTables().forEach((item ,idx)=>{  
            	            	 
            	 
                 if( item.tagName.toLowerCase()=='table') this._table(item);
                 else                                     this.non_table(item);  
                 
                 
                 this.last.gridIDX = idx;
                 
                 this.set_grid(this.last.gridIDX);

                 this.replaceTable(item,this.last.gridIDX);
                 
                 this.listener(); 
                 
             });
        	
        }
        ,
        flushAllTableData(){        

            this.flushTableData();
            
            //
            this.gripDB.forEach((_,idx)=>this.set_grid(idx));
    
        }
        ,
        flushTableData(){
    
            this.gripDB = []; 
    
            //
            this.getTables().forEach((item)=>{  
                if( item.tagName.toLowerCase()=='table') this._table(item);
                else                                     this.non_table(item);        
            });
    
    
        }
        ,
        addTableData(item){
    
            let no = null;
    
            //
            if( this.options.initTableFlush=='table') no = this._table(item);
            else                                      no = this.non_table(item); 
    
            //
            this.gripDB.some((_item ,_idx )=>{
                if( no == _item.no ){
    
                    this.last.gridIDX = _idx;
    
                    this.set_grid(this.last.gridIDX);
    
                    this.replaceTable(item,this.last.gridIDX);
                    
                    this.listener();                    
    
                    return true;
                }  
            });    
    
        }
        ,
        replaceAllTable(){
    
            if( !this.options.initTableFlush ) return;
    
            this.getTables().forEach((item ,idx )=>{
    
                this.replaceTable(item,idx);
    
            });        
    
        }
        ,
        replaceTable(item,idx=0){        	
        	
        	const _colgroup = item.querySelector("colgroup");        	
    
            const _obj = this.options.initTableFlush=='table'?this.showTable(idx):this.showGrid(idx);
    
            if( _colgroup != null && _colgroup != ''){
            	
            	//flush
                _obj.querySelectorAll("colgroup").forEach(obj=>{
                    obj.remove();
                });               
                
                
                _obj.insertAdjacentElement('afterbegin',_colgroup);            	
            }           
            
            
            item.outerHTML = _obj.outerHTML;
            
            
    
            //
            this.set_position();
    
        }
        ,
        setItemData(obj){
            
            let result = false;

            //
            if (
                obj === null || 
                typeof(obj) !== 'object' 
            )  return result;
    
            const _no = this.get_itemid(obj);
    
            //
            if( !_no )  return result;  
    
            this.gripDB.some((_item,_idx)=>{                
                _item.items.some((item,idx)=>{                    
                    if(item.no == _no){
                        item.data = obj.innerHTML;    
                        result = true;
                        return result;
                    }
                });
    
                if(result) return result;
            });
           
    
            return result;
        }
        ,
        getTables(){
            return document.querySelectorAll(this.options.targetID);
        }
        ,
        getTableSize(){
    
            if(this.last.gridIDX == null) return false;
    
            return {
                totalCol : this.gripDB[this.last.gridIDX].totalCol ,      
                totalRow : this.gripDB[this.last.gridIDX].totalRow
            };
    
        }
        ,
        changeTable( type = ''){

            let checkData = null;
    
            switch(type){
    
                case "merge":
                    checkData = this.merge();
                break;
    
                case "split":
                    checkData = this.splitHorizontal();
                    checkData = this.splitVertical();
                break;
    
                case "addCol":
                    checkData = this.addFUllCol();
                break;
    
                case "addRow":
                    checkData = this.addFUllRow();
                break;
    
                case "delCol":
                    checkData = this.delFUllCol();
                break;
    
                case "delRow":
                    checkData = this.delFUllRow();
                break;
    
            }


            //
            if( checkData.result == "fail" ) CPTable.alert(checkData.msg);                 

            return {
                result : checkData.result,
                totalCol : this.gripDB[this.last.gridIDX].totalCol ,      
                totalRow : this.gripDB[this.last.gridIDX].totalRow
            };    
    
        }
        ,
        listener(){           	
    
            if( this.Onlistener ) return;
               
            this.Onlistener = true;            
            
            document.addEventListener("click", event => { 
    
                let _wrap = null;
               
                if( 
                    event.target.classList.contains(`${this.itemName}`) 
                    ||
                    (event.target.closest(`.${this.itemName}`) && event.target.classList.contains('itemID'))
                ){
                //if( _wrap = event.target.closest(`.${this.wrapName}`) ){                	
    
                    _wrap = event.target.closest(`.${this.wrapName}`);
    
                    const wrapID = this.get_wrapid(_wrap);  
                    
                    //flush checked item
                    if( this.last.wrapID != null && this.last.wrapID != wrapID ){
                        document.querySelectorAll(`.${this.wrapName+this.last.wrapID} .${this.tabSelectedClass}`).forEach((item , idx)=>{
                            item.classList.remove(this.tabSelectedClass);                        
                        });
                    }
    
    
    
                    //init
                    this.last.wrapID = wrapID;
                    this.last.gridIDX = this.get_wrapidx(wrapID);
                    
                       
    
                    //group - A (1/2)
                    //const _target = event.target;
                    const _target = event.target.closest(`.${this.itemName}`);
    
                    if( _target == null ) return;
                   
                    const _targetClass = _target.classList;
    
    
                   
    
                    //group - A (2/2)
                    //if(!_targetClass.contains(this.itemName)) return;
    
                    const classStatus =  _targetClass.contains(this.tabSelectedClass) ? 'remove' :'add';
                    const checkData = this.checkRowOrColAble( _target, this.last.gridIDX , classStatus);
    
                    if(checkData.result == 'finish' ){
                        if(classStatus == 'add'){
    
                            _targetClass.add(this.tabSelectedClass);
    
                            this.last.itemID = this.get_itemid(_target);                        
    
                        }else{
                            _targetClass.remove(this.tabSelectedClass);
                        }
    
    
                        //
                        this.last.position = this.get_position();
                            
                    }else{    
                        CPTable.alert(checkData.msg);                
                        //console.log('multi select fail massage !!!! : ' , checkData );
                        //this.listenScript({ type:"mergeAble", result:checkData.result , msg : checkData.msg });
                    }     
                    
                    //listen
                    //CPTable.cpid
                    //cpWrap
                    const tableWrap = event.target.closest(`.CPTable`);
                    CPTable.cpid = tableWrap.id;
                    CPTable.selectComp();
    
                }
    
            });
    
    
        }
        
        ,
        makeTable(col = 1 , row = 1){

           
            const _wrap = document.createElement('table');

            
            for(let r = 0 ; r < row ; r++){
    
                const _tr = document.createElement("tr");               
    
                for(let c = 0 ; c < col ; c++){
    
                    const _td = document.createElement("td");
                    _td.innerHTML = this.options.defaultForm.replace("${{random}}" ,this.get_random() );
    
                    _tr.appendChild(_td);
    
                }
    
                _wrap.appendChild(_tr);
    
            }
    
            return _wrap;
        }
        ,

        //only table
        fixTableColGroupWidth( _wrap = null, idx=0 , width=null ){

            let _backup = _wrap.querySelectorAll("colgroup > col");

            const no = this.get_wrapid(_wrap);
            const colgroup = document.createElement('colgroup');   
            this.gripDB.some((_item ,_idx )=>{
                if( no == _item.no ){  

                    if(_item.result[0][idx]){

                        const _tmpData = this.gripDB_NO( _idx );

                        _item.result[0].some((___item , ___idx)=>{

                            let col = document.createElement('col');

                            if( idx > ___idx ){col.setAttribute("width",_backup[___idx].getAttribute("width"));
                            } else{
                                let addText = `${idx==___idx?width:'*'}`;
                                col.setAttribute("width",addText);
                            }

                            //.style.width = addText;
                            colgroup.appendChild(col);


                        });

                    }

                    return true;
                } 
            }); 

            //flush
            _wrap.querySelectorAll("colgroup").forEach(obj=>{
                obj.remove();
            });

            _wrap.insertAdjacentElement('afterbegin',colgroup);
        }
        ,
    
        //only table
        fixTableColWidth( _wrap = null, idx=0 , width=null){
    
            const no = this.get_wrapid(_wrap);
    
            this.gripDB.some((_item ,_idx )=>{
                if( no == _item.no ){                
    
                    if(_item.result[0][idx]){
    
                        const _tmpData = this.gripDB_NO( _idx );
    
                        _item.result[0].some((___item , ___idx)=>{
    
    
                            if( idx > ___idx ) return false;
    
    
                            try{
    
                                let addText = `width:${idx==___idx?width:'auto'};`;
    
                                let style = _tmpData[_item.result[0][___idx]['no']]['style'];
                                if(style == null){
                                    _tmpData[_item.result[0][___idx]['no']]['style'] = addText;
                                }else{
    
                                    //
                                    let check = false;
                                    const _split = style.split(';');
                                    _split.forEach((_style,_idx)=>{
                                        if(_style.toLowerCase().indexOf('width') == 0 ){
                                            _split[_idx] = addText.replace(";","");  
                                            check = true;
                                        }                          
                                    });
    
                                    //
                                    let __style = _split.join(';');
    
                                    if(check==false) __style += addText;                       
    
                                    _tmpData[_item.result[0][___idx]['no']]['style'] = __style;
    
                                }
    
                            }catch(e){
                            }
                        });
    
    
                        this.replaceTable(_wrap,_idx);                   
                     
    
                    }
    
                    return true;
                } 
                
               
            }); 
    
        }
    
        ,
        addRow(_positionY = 0 ){
    
            //
            let result = "finish";
            let msg = "";
    
            const _tmpData = this.gripDB_NO( this.last.gridIDX );
    
            //add row
            const positionY = Number(_positionY) - 1;
    
            const addCount = 1;
            
            let work = false;
    
            if( positionY < 0 ){
                result = "fail";
                msg = "no-position-data";
                return  {"result":result , "msg":msg };
            }
    
        
    
            const itemDB = this.gripDB[this.last.gridIDX].result;
    
            itemDB.forEach((_line , _idx )=>{
                if( positionY <= _idx){
                    _line.forEach((_ ,idx)=>{
    
                        let __item = _tmpData[_line[idx]['no']];
    
                        //prefix
                        if( _line[idx] == this.blankAreaID ){
    
                            let _while = true;
                            let _cnt = positionY;                            
                            while(_while){
                                if( _cnt < 0 )_while = false;
                                _cnt--;
                                if( _cnt >= 0 && itemDB[_cnt][idx] != this.blankAreaID ){
                                    __item = _tmpData[itemDB[_cnt][idx]['no']];
                                    _while = false;
                                }
                             }
    
                        }
    
                        if(__item) work = true;  
    
                        if( positionY == _idx ){                      
                            __item.row += addCount;   
                        }else{
                            __item.position.y += addCount;
                        }
                    
                    });
                }           
            });
    
    
            if( !work ){
                result = "fail";
                msg = "no-work-data";
                return  {"result":result , "msg":msg };
            }
    
            this.gripDB[this.last.gridIDX].totalRow += addCount;
    
            return  {"result":result , "msg":msg };
    
        }
        ,
        addCol(_positionX = 0 ){
    
            //
            let result = "finish";
            let msg = "";
    
            const _tmpData = this.gripDB_NO( this.last.gridIDX );
    
            //add col
            const positionX = Number(_positionX) - 1;
    
            const addCount = 1;
    
            let work = false;
    
            if( positionX < 0 ){
                result = "fail";
                msg = "no-position-data";
                return  {"result":result , "msg":msg };
            }
            
            this.gripDB[this.last.gridIDX].result.forEach((_line , _idx )=>{
                _line.forEach((_ ,idx)=>{
                    if( positionX <= idx){
    
                        let __item = _tmpData[_line[idx]['no']];
    
                        //prefix
                        if( _line[idx] == this.blankAreaID ){
                            let _while = true;
                            let _cnt = idx;                            
                            while(_while){
                                if( _cnt < 0 )_while = false;
                                _cnt--;
                                if( _cnt >= 0 && _line[_cnt] != this.blankAreaID ){
                                    __item =_tmpData[_line[_cnt]['no']];
                                    _while = false;
                                }
                            }
                        }
    
                        if(__item) work = true;  
    
                        if( positionX == idx ){                            
                            __item.col += addCount;   
                        }else{
                            __item.position.x += addCount;
                        }
                    }
                });
            });
    
            if( !work ){
                result = "fail";
                msg = "no-work-data";
                return  {"result":result , "msg":msg };
            }
    
            this.gripDB[this.last.gridIDX].totalCol += addCount;
    
            //add col end
    
            return  {"result":result , "msg":msg };
    
        }
        ,
        itemsSort(_items){
    
            const _sort = new Array();
            _items.forEach((item)=>{
                _sort[item.position.y * 1000000 + item.position.x ] = item;
            });
    
            return _sort.filter((itm, i) => itm !== undefined);
        }
        ,
        rightLastItem(gripDB , itemDB){
    
        }
        ,
        bottomLeftItem(gripDB , itemDB ){
    
            const totalCol = gripDB.totalCol;
            //const totalRow = this.gripDB[this.last.gridIDX].totalRow;
            const totalRow = itemDB.position.y;
    
    
            let beforeItem = null;  
            let beforeIdx = null; 
    
    
            gripDB.items.reverse().forEach(( item)=>{
                if( itemDB.position.y < item.position.y && item.position.x > itemDB.position.x ) return false;
    
    
                if( item != this.blankAreaID && beforeItem == null ){
                    beforeItem = item;
                } 
            });
    
            
            gripDB.items.reverse().forEach(( item , idx)=>{
                if(item.no == beforeItem.no) {
                    beforeIdx = idx; 
                    return true;
                }
            });
    
            //console.log( "fffff", beforeIdx ,  beforeItem );
    
            return { idx : beforeIdx , item : beforeItem};
    
        }
        ,
    
        delFUllRow(){
    
            //
            let result = "finish";
            let msg = "";

            //
            if(this.last.wrapID == null){
                result = "fail";
                msg = "no-selected";
                return  {"result":result , "msg":msg };
            }
    
            //
            const delCount = 1;
    
            //
            const wrap = document.querySelector(`.${this.wrapName+this.last.wrapID}`);
            const item = wrap.querySelector(`.${this.itemName+this.last.itemID}`); 
    
            //01. selected check
            if( !item.classList.contains(this.tabSelectedClass) ){
                result = "fail";
                msg = "no-selected";
                return  {"result":result , "msg":msg };
            }
           
            //
            const _tmpData = this.gripDB_NO( this.last.gridIDX );
            const itemDB = _tmpData[this.last.itemID];
            const _grid = this.gripDB[this.last.gridIDX];
            const __itemDBs = _grid.items;
            
            let _idx = null;
    
            //
            __itemDBs.forEach((item,idx)=>{ 
                if( item.no == this.last.itemID ) _idx = idx;            
            });
    
            //
            if( _idx == null ){
                result = "fail";
                msg = "no-data";
                return  {"result":result , "msg":msg };
            }
    
            //
            const __itemDB = _grid.items[_idx];
            const _y = __itemDB.position.y;
    
            //00 copy
            let _items = structuredClone(_grid.items);    
    
            const rowAddPositionXArray = new Array();
            const blankPositionXArray = new Array();
            let last_x = null;
            _items.forEach((_item , _idx )=>{
    
                //blank check
                if( _item.position.y == __itemDB.position.y ){
    
                    if( _item.row > 1) rowAddPositionXArray.push(_item['no']);
    
                    if( last_x != null ){
    
                        let _start = last_x;
                        while( _start < _item.position.x - 1 ){
                            _start++;
                            blankPositionXArray.push(_start);
                        }
    
                    }
                    
                    last_x = _item.position.x + (_item.col - 1);
                }
            });
    
    
            if( blankPositionXArray.length > 0 || rowAddPositionXArray.length > 0 ){            
    
                /*
                result = "fail";
                msg = "no-del-data";
                return  {"result":result , "msg":msg };
                */
    
            }
    
    
            if( blankPositionXArray.length > 0 ){
    
                
                blankPositionXArray.forEach((blankX,idx)=>{
                    let _targetY = __itemDB.position.y;
                    while( _targetY >= 0){
                        _targetY--;
    
                        if(_grid.result[_targetY][blankX-1] != this.blankAreaID ){           
    
                            //blankPositionXArray[idx] = _grid.result[_targetY][blankX-1]['no'];
    
                            _items.some((_item , _idx)=>{
                                if( _grid.result[_targetY][blankX-1]['no'] == _item.no){
                                    _item.row -= delCount;
    
                                    //error data fix
                                    _item.row = this.delErrorDataFix(_item.row);
    
                                    //console.log( _idx , _item );
                                    return true;
                                }  
                            });
    
                            _targetY = -1;
    
                        }  
    
                    }
    
    
                });
    
            }
    
            let delItem = new Array();
            _items.some((_item , _idx )=>{
                if(_item.position.y == _y){
    
                    if( rowAddPositionXArray.includes(_item['no']) ){
                        _item.row -= delCount;
    
                        //error data fix
                        _item.row = this.delErrorDataFix(_item.row);
    
                        _item.position.y += 1;
                    }else{
                        delItem.push(_idx);
                    }
                    
                }
            });


            
            //del able check
            if( this.delAbleCheck(_items , delItem ) == false ){
                result = "fail";
                msg = "has-row-data";
                return  {"result":result , "msg":msg };
            }

    
    
            delItem.reverse().forEach((_idx)=>{
                _items.splice(_idx, 1);
            });
    
           
    
            //sort
            _items = this.itemsSort(_items);
    
    
            
            //04 insert original data
            if( _grid.items.length == _items.length){
                result = "fail";
                msg = "no-change";
                return  {"result":result , "msg":msg };
            }
            
            _grid.items = _items;
    
            _grid.totalRow -= delCount;
    
            //error data fix
            _grid.totalRow = this.delErrorDataFix(_grid.totalRow);
    
            //05 flush temp data
            _items = null;
         
    
            this.set_grid(this.last.gridIDX);
            this.replaceTable( wrap , this.last.gridIDX);
    
            return  {"result":result , "msg":msg };        
            
        }
        ,

        delAbleCheck(items , delItem ){

            let delAbleCheck = true;
            delItem.some((_idx)=>{

                let _changeWrapCopy = document.querySelector(`.${this.itemName + items[_idx].no}`).cloneNode(true);
                
                this.skipObj(_changeWrapCopy);

                if(_changeWrapCopy.innerHTML!=''){
                    delAbleCheck = false;
                    return true;                   
                }
                
            });


            return delAbleCheck;            
        }


        ,
        delFUllCol(){
    
            //
            let result = "finish";
            let msg = "";

            //
            if(this.last.wrapID == null){
                result = "fail";
                msg = "no-selected";
                return  {"result":result , "msg":msg };
            }
    
            //
            const delCount = 1;
    
            //
            const wrap = document.querySelector(`.${this.wrapName+this.last.wrapID}`);
            const item = wrap.querySelector(`.${this.itemName+this.last.itemID}`); 
    
            //01. selected check
            if( !item.classList.contains(this.tabSelectedClass) ){
                result = "fail";
                msg = "no-selected";
                return  {"result":result , "msg":msg };
            }
           
            //
            const _tmpData = this.gripDB_NO( this.last.gridIDX );
            const itemDB = _tmpData[this.last.itemID];
            const _grid = this.gripDB[this.last.gridIDX];
            const __itemDBs = _grid.items;
            
            let _idx = null;
    
            //
            __itemDBs.forEach((item,idx)=>{ 
                if( item.no == this.last.itemID ) _idx = idx;            
            });
    
            //
            if( _idx == null ){
                result = "fail";
                msg = "no-data";
                return  {"result":result , "msg":msg };
            }
    
            //
            const __itemDB = _grid.items[_idx];
            const _x = __itemDB.position.x;
            const _y = __itemDB.position.y;
     
            //00 copy
            let _items = structuredClone(_grid.items);
     
            //console.log( _x , _grid.result );
            //console.log( __itemDB );
    
            const colAddPositionXArray = new Array();
            const blankPositionYArray = new Array();
            _items.forEach((_item , _idx )=>{
    
                if( _item.col > 1 && _item.position.x == _x ) colAddPositionXArray.push(_item['no']);
    
                //console.log( _x ,  _item );
    
                //option
                if( _item.position.x < _x && _x <= _item.position.x + (_item.col - 1) ){
                    //blankPositionYArray.push(_item['no']);
                    blankPositionYArray.push(_item.position.y);
                }
            });
    
    
            
            //console.log( "here", colAddPositionXArray  , blankPositionYArray);
            //console.log( _grid );
    
            if( blankPositionYArray.length > 0 ){
                
                blankPositionYArray.forEach((blankY,idx)=>{
                  
                    let _targetX = __itemDB.position.x;
                    while( _targetX >= 0){
                        _targetX--;
                                           
                        if(_grid.result[blankY-1][_targetX] != this.blankAreaID ){           
    
                            _items.some((_item , _idx)=>{
                                if( _grid.result[blankY-1][_targetX]['no'] == _item.no){
                                    _item.col -= delCount;
    
                                    //error data fix
                                    _item.col = this.delErrorDataFix(_item.col);
    
                                    //console.log( _idx , _item );
                                    return true;
                                }  
                            });
    
                            _targetX = -1;
    
                        }  
                           
    
                    }
                  
    
                });
    
            }
    
            let delItem = new Array();
            _items.some((_item , _idx )=>{
                if(_item.position.x == _x){
    
                    if( colAddPositionXArray.includes(_item['no']) ){
                        _item.col -= delCount;
    
                        //error data fix
                        _item.col = this.delErrorDataFix(_item.col);
    
                    }else{
                        delItem.push(_idx);
                    }
                    
                }
            });


            //del able check 
            if( this.delAbleCheck(_items , delItem ) == false ){
                result = "fail";
                msg = "has-col-data";
                return  {"result":result , "msg":msg };
            }
    
    
            delItem.reverse().forEach((_idx)=>{
                _items.splice(_idx, 1);
            });
    
           
    
            //sort
            _items = this.itemsSort(_items);
    
    
            
            //04 insert original data
            if( _grid.items.length == _items.length){
                result = "fail";
                msg = "no-change";
                return  {"result":result , "msg":msg };
            }
            
            _grid.items = _items;
    
            _grid.totalCol -= delCount;
    
            //error data fix
            _grid.totalCol = this.delErrorDataFix(_grid.totalCol);
    
            //05 flush temp data
            _items = null;
         
    
            this.set_grid(this.last.gridIDX);
            this.replaceTable( wrap , this.last.gridIDX);
    
            return  {"result":result , "msg":msg };        
            
    
        }    
        ,
        addFUllCol(type='right'){
            //
            let result = "finish";
            let msg = "";

            //
            if(this.last.wrapID == null){
                result = "fail";
                msg = "no-selected";
                return  {"result":result , "msg":msg };
            }
    
            //
            const addCount = 1;
    
            //
            const wrap = document.querySelector(`.${this.wrapName+this.last.wrapID}`);
            const item = wrap.querySelector(`.${this.itemName+this.last.itemID}`); 

            
    
            //01. selected check
            if( !item.classList.contains(this.tabSelectedClass) ){
                result = "fail";
                msg = "no-selected";
                return  {"result":result , "msg":msg };
            }
           
            //
            const _tmpData = this.gripDB_NO( this.last.gridIDX );
            const itemDB = _tmpData[this.last.itemID];
            const _grid = this.gripDB[this.last.gridIDX];
            const __itemDBs = _grid.items;
            
            let _idx = null;
    
            //console.log( 'test' , this.last , _grid );
    
            //
            __itemDBs.forEach((item,idx)=>{ 
                if( item.no == this.last.itemID ) _idx = idx;            
            });
    
            //
            if( _idx == null ){
                result = "fail";
                msg = "no-data";
                return  {"result":result , "msg":msg };
            }
    
            //
            const __itemDB = _grid.items[_idx];
    
            const _totalRow = _grid.totalRow;
            const _totalCol = _grid.totalCol;
            const _x = type == 'left'?__itemDB.position.x:( __itemDB.col - 1 )+__itemDB.position.x+addCount;
    
    
            //00 copy
            let _items = structuredClone(_grid.items);
    
            //console.log( "addFUllCol",_x , __itemDB );
    
    
            //01 check existing
            const blankPositionYArray = new Array();
            _items.forEach((_item , _idx )=>{
                //option
                if( _item.position.x < _x && _x <= _item.position.x + (_item.col - 1) ){
                    //blankPositionYArray.push(_item['no']);
                    blankPositionYArray.push(_item);
                }
            });
    
    
            //
            blankPositionYArray.some(( _item )=>{
                _item.col += addCount;
            });
    
    
            //02
            _items.forEach((_item , _idx )=>{
                if( _item.position.x >= _x ){                          
                    _item.position.x += addCount;
                }
            });
    
    
            //add
            for( let i=0 ; i < _totalRow ; i++){
    
                const _y = i + 1;
    
                //
                let goNext = false;
                blankPositionYArray.some(( _item )=>{
                    if( _item.position.y == _y){
                        return goNext = true;
                    } 
                });
    
                if( goNext ) continue;
    
    
                //
    
                const copy = this.newItem( __itemDB , 'n' ,  1 , 1 );
                copy.id='copy';
                copy.position.x = _x;
                copy.position.y = _y;
    
                _items.splice( _items.length  , 0 , copy );
    
            }
    
    
            //sort
            _items = this.itemsSort(_items);
    
    
    
            //04 insert original data
            if( _grid.items.length == _items.length){
                result = "fail";
                msg = "no-change";
                return  {"result":result , "msg":msg };
            }
            
            _grid.items = _items;
    
            _grid.totalCol += addCount;
    
            //05 flush temp data
            _items = null;
    
    
         
    
            this.set_grid(this.last.gridIDX);
            this.replaceTable( wrap , this.last.gridIDX);
    
            return  {"result":result , "msg":msg };
    
            
        }
        ,
        addFUllRow(type='bottom'){
    
            //
            let result = "finish";
            let msg = "";

            //
            if(this.last.wrapID == null){
                result = "fail";
                msg = "no-selected";
                return  {"result":result , "msg":msg };
            }
    
            //
            const addCount = 1;
    
            //
            const wrap = document.querySelector(`.${this.wrapName+this.last.wrapID}`);
            const item = wrap.querySelector(`.${this.itemName+this.last.itemID}`); 
    
            //01. selected check
            if( !item.classList.contains(this.tabSelectedClass) ){
                result = "fail";
                msg = "no-selected";
                return  {"result":result , "msg":msg };
            }
           
            //
            const _tmpData = this.gripDB_NO( this.last.gridIDX );
            const itemDB = _tmpData[this.last.itemID];
            const _grid = this.gripDB[this.last.gridIDX];
            const __itemDBs = _grid.items;
            
            let _idx = null;
    
            //
            __itemDBs.forEach((item,idx)=>{ 
                if( item.no == this.last.itemID ) _idx = idx;            
            });
    
            //
            if( _idx == null ){
                result = "fail";
                msg = "no-data";
                return  {"result":result , "msg":msg };
            }
    
            //
            const __itemDB = _grid.items[_idx];
    
            const _totalRow = _grid.totalRow;
            const _totalCol = _grid.totalCol;
            const _y = type == 'top'?__itemDB.position.y:( __itemDB.row - 1 )+__itemDB.position.y+addCount;
    
    
            //00 copy
            let _items = structuredClone(_grid.items);
    
    
    
            //01 existing position.y data add 
            const lowAddPositionXArray = new Array();
            const blankPositionXArray = new Array();
            let last_x = null;
            let _start_idx = _items.length;
            _items.forEach((_item , _idx )=>{
    
                //blank check
                if( _item.position.y == __itemDB.position.y ){
    
                    if( last_x != null ){
    
                        let _start = last_x;
                        while( _start < _item.position.x - 1 ){
                            _start++;
                            blankPositionXArray.push(_start);
                        }
    
                    }
                    
                    last_x = _item.position.x + (_item.col - 1);
                }
    
    
                if( _item.position.y >= _y ){
                    if( _start_idx > _idx ) _start_idx = _idx;
                    _item.position.y += addCount; 
                }          
               
                
                if(type =='bottom'){
                    if( _item.position.y == __itemDB.position.y && __itemDB.row < _item.row ){
                        lowAddPositionXArray.push( _item.position.x );
                        _item.row += addCount;
                    }
                }
            });
    
        
            if( blankPositionXArray.length > 0 || lowAddPositionXArray.length > 0 ){            
    
                /*
                result = "fail";
                msg = "no-add-data";
                return  {"result":result , "msg":msg };
                */
    
            }
    
            if( blankPositionXArray.length > 0 ){
    
                //console.log( blankPositionXArray , __itemDB.position.y , _grid.result );  
    
                
                blankPositionXArray.forEach((blankX,idx)=>{
                    let _targetY = __itemDB.position.y;
                    while( _targetY >= 0){
                        _targetY--;
    
                        if(_grid.result[_targetY][blankX-1] != this.blankAreaID ){           
    
                            //blankPositionXArray[idx] = _grid.result[_targetY][blankX-1]['no'];
    
                            _items.some((_item)=>{
                                if( _grid.result[_targetY][blankX-1]['no'] == _item.no){
                                    _item.row += addCount;
                                    return true;
                                }  
                            });
    
                            _targetY = -1;
    
                        }  
    
                    }
    
    
                });
    
            }
    
    
            //console.log( blankPositionXArray , lowAddPositionXArray );   
    
            //02 add full row line
            for( let i=0 ; i < _totalCol ; i++){
    
                const _x= i + 1;
    
                if( lowAddPositionXArray.length > 0 && lowAddPositionXArray.includes( _x ) ) continue;          
    
                const copy = this.newItem( __itemDB , 'n' ,  1 , 1 );
                copy.id='copy';
                copy.position.x = _x;
                copy.position.y = _y;
    
                _items.splice( _start_idx  , 0 , copy );
    
                _start_idx++;
    
            }
    
            //03 sort position data - skip
    
            //04 insert original data
            if( _grid.items.length == _items.length){
                result = "fail";
                msg = "no-change";
                return  {"result":result , "msg":msg };
            }
            
            _grid.items = _items;
    
            _grid.totalRow += addCount;
    
            //05 flush temp data
            _items = null;
    
    
            this.set_grid(this.last.gridIDX);
            this.replaceTable( wrap , this.last.gridIDX);
    
            return  {"result":result , "msg":msg };
    
        }
        ,
        splitVertical(type='bottom'){
    
            //
            let result = "finish";
            let msg = "";

            //
            if(this.last.wrapID == null){
                result = "fail";
                msg = "no-selected";
                return  {"result":result , "msg":msg };
            }
    
            //
            const delCount = 1;
    
            //
            const wrap = document.querySelector(`.${this.wrapName+this.last.wrapID}`);
            const item = wrap.querySelector(`.${this.itemName+this.last.itemID}`); 
    
            //01. selected check
            if( !item.classList.contains(this.tabSelectedClass) ){
                result = "fail";
                msg = "no-selected";
                return  {"result":result , "msg":msg };
            }
           
            //
            const _tmpData = this.gripDB_NO( this.last.gridIDX );
            const itemDB = _tmpData[this.last.itemID];
            const _grid = this.gripDB[this.last.gridIDX];
            const __itemDBs = _grid.items;

            
            let _idx = null;
    
            //
            __itemDBs.forEach((item,idx)=>{ 
                if( item.no == this.last.itemID ) _idx = idx;            
            });
    
            //
            if( _idx == null ){
                result = "fail";
                msg = "no-data";
                return  {"result":result , "msg":msg };
            }


            //00 copy
            let _items = structuredClone(this.gripDB[this.last.gridIDX].items);
    
            //
            const __itemDB = _items[_idx];
    
            let isAdd = false;
            if( itemDB.row <= 1 ){
    
                /*
                @workwait 240913
    
                isAdd = true;
    
                //
                const addResult = this.addRow( __itemDB.position.y );
    
                //
                if(addResult["result"] == "fail" ) return  addResult;   
                */
                
                //double check
                if( itemDB.row <= 1 ){
                    result = "fail";
                    msg = "no-splitAble-data";
                    return  {"result":result , "msg":msg };
                }
    
            }
            
            
            //data change
            __itemDB.row -= delCount; 

            const copy = this.newItem( __itemDB , 'n' ,  __itemDB.col , 1 );
            copy.id='copy';
            

            if( type == 'top'){

                copy.position.y = Number(__itemDB.position.y);

                __itemDB.position.y = Number(__itemDB.position.y) + 1;
    
               
    
            }else if( type == 'bottom'){
    
                copy.position.y = Number(__itemDB.position.y) + ( Number(__itemDB.row) - 1 ) + 1;
    
            }


            _items.splice( _items.length  , 0 , copy );

            //sort
            _items = this.itemsSort(_items);


            //04 insert original data
            if( _grid.items.length == _items.length){
                result = "fail";
                msg = "no-change";
                
                //console.log( "!!!!????????" , _grid.items.length , _items.length );
                return  {"result":result , "msg":msg };
            }

            _grid.items = _items;

            //05 flush temp data
            _items = null;

            this.set_grid(this.last.gridIDX);
            this.replaceTable( wrap , this.last.gridIDX);

            return  {"result":result , "msg":msg };            

            /*
    
            
    
            const positionX = Number(__itemDB.position.x) + Number(__itemDB.col) - 1;
            const positionY = Number(__itemDB.position.y) + Number(__itemDB.row) - 1;
    
            //data change
            __itemDB.row -= delCount; 
    
            //error data fix
            __itemDB.row = this.delErrorDataFix(__itemDB.row);
    
    
            //
            const before =this.bottomLeftItem( this.gripDB[this.last.gridIDX] , __itemDB );
    
           
    
            //
            const _totalCol = this.gripDB[this.last.gridIDX].totalCol;
            let _positionIdx =  before.idx + 1;   
            
            //let _positionIdx =  Number(_idx) + ( Number(__itemDB.row) * Number(_totalCol) );
    
    
            console.log( "before" , before );
    
            
            
            if( isAdd ){
    
                //rightLastItem(gripDB , itemDB)
    
    
    
                _positionIdx -= 1;
    
            }
           
    
    
            console.log( "_positionIdx", _positionIdx );
            
            //
            //const copy = this.newItem( __itemDB , __itemDB.bold ,  __itemDB.col , 1 );
            const copy = this.newItem( __itemDB , 'n' ,  __itemDB.col , 1 );
    
    
            console.log( "A",_idx , __itemDB.position.y , _totalCol );
            console.log( "B",_positionIdx , copy , __itemDBs );
    
            
    
            if( type == 'top'){
    
                __itemDBs.splice( _positionIdx ,0,__itemDB);
                __itemDBs.splice( _idx , 1 ,copy);
    
            }else if( type == 'bottom'){
    
                __itemDBs.splice( _positionIdx ,0,copy);
    
            }
    
            this.set_grid(this.last.gridIDX);
    
            this.replaceTable( wrap , this.last.gridIDX);
    
            console.log( this.gripDB[this.last.gridIDX] );            
          
    
            return  {"result":result , "msg":msg };

            */
    
        } 
        
        ,
        splitHorizontal(type='right'){
    
            //
            let result = "finish";
            let msg = "";

            //
            if(this.last.wrapID == null){
                result = "fail";
                msg = "no-selected";
                return  {"result":result , "msg":msg };
            }
    
            //
            const delCount = 1;
    
            //
            const wrap = document.querySelector(`.${this.wrapName+this.last.wrapID}`);
            const item = wrap.querySelector(`.${this.itemName+this.last.itemID}`); 
    
            //01. selected check
            if( !item.classList.contains(this.tabSelectedClass) ){
                result = "fail";
                msg = "no-selected";
                return  {"result":result , "msg":msg };
            }
           
            //
            const _tmpData = this.gripDB_NO( this.last.gridIDX );
            const itemDB = _tmpData[this.last.itemID];
            const __itemDBs = this.gripDB[this.last.gridIDX].items;
            let _idx = null;
    
            //
            __itemDBs.forEach((item,idx)=>{ 
                if( item.no == this.last.itemID ) _idx = idx;            
            });
    
            //
            if( _idx == null ){
                result = "fail";
                msg = "no-data";
                return  {"result":result , "msg":msg };
            }
    
            //
            const __itemDB = this.gripDB[this.last.gridIDX].items[_idx];
    
            if( itemDB.col <= 1 ){
    
                /*
                @workwait 240913
    
                //
                const addResult = this.addCol( __itemDB.position.x );
    
                //
                if(addResult["result"] == "fail" ) return  addResult;       
                */     
    
                //double check
                if( itemDB.col <= 1 ){
                    result = "fail";
                    msg = "no-splitAble-data";
                    return  {"result":result , "msg":msg };
                }
    
            }
    
            //data change
            __itemDB.col -= delCount;    
            
            //error data fix
            __itemDB.col = this.delErrorDataFix(__itemDB.col);
    
            //
            const copy = this.copyItem( __itemDB );
    
            __itemDBs.splice( type=='right'?_idx+1:_idx,0,copy);
    
            this.set_grid(this.last.gridIDX);
    
            this.replaceTable( wrap , this.last.gridIDX);
            
            /*
            arr3.splice(1, 0, 'a', 'b'); // �꾩튂 , ��젣 異붽�
            <div class="changeWrap" data-no="dcgm___{{random}}">
            </div>
            */
    
            return  {"result":result , "msg":msg };
        }
        ,
        merge(){
    
            let result = "finish";
            let msg = "";
    
            //console.log('merge' , this.lastWrap);
    
            //this.gripDB[idx].no
            const wrap = document.querySelector(`.${this.wrapName+this.last.wrapID}`); 
            const items = document.querySelectorAll(`.${this.wrapName+this.last.wrapID} .${this.tabSelectedClass}`);
    
    
            //01.data useable check
            if( items.length <= 1 ){
    
                result = "fail";
                msg = "merge-able-count";
    
            }else{


                

   
                const itemIDs = new Array();
                items.forEach((item)=>{
    
                    const itemID = this.get_itemid(item);
    
                    itemIDs.push( itemID );
                    
                    
                });


                //
                let delItem = new Array();
                itemIDs.forEach((_no)=>{
                    this.gripDB[this.last.gridIDX].items.some((_item , _idx)=>{
                        if( _no == _item.no ){
                            delItem.push(_idx);
                            return true;
                        } 
                    });                    
                });

                //첫번째 값은 제외                
                delItem.shift();

                //del able check
                if( this.delAbleCheck(this.gripDB[this.last.gridIDX].items , delItem ) == false ){
                    result = "fail";
                    msg = "has-merge-data";
                    return  {"result":result , "msg":msg };
                }



    
                const _tmpData = this.gripDB_NO( this.last.gridIDX );
    
                /*
                console.log( itemIDs  );
                console.log( this.gripDB[this.last.gridIDX]  );
                */
    
                let rowOrcol = null;
                let rowOrcolBackup = null;
                itemIDs.some((_no)=>{
    
                    rowOrcol = this.rowOrcol( _tmpData[itemIDs[0]]  , _tmpData[_no]);                
    
                    if( rowOrcolBackup!= null && rowOrcol != rowOrcolBackup){
                        result = "fail";
                        msg = "mixed-row_col-data";
                        return true;
                    }
    
                    rowOrcolBackup = rowOrcol;
    
                });
    
    
                //console.log( rowOrcol );
    
                //02. row, col, data replace
                const _y = new Array();
                const _x = new Array(); 
                itemIDs.forEach((_no)=>{
                    if( rowOrcol == 'row' )
                        _y[ _tmpData[_no].position.y ] = _tmpData[_no];
                    else if( rowOrcol == 'col' )
                        _x[ _tmpData[_no].position.x ] = _tmpData[_no];                
                });
    
    
                //replace empty
                const __x = _x.filter((itm, i) => itm !== undefined);
                const __y = _y.filter((itm, i) => itm !== undefined);
    
                let __itemDBs = null;            
    
                if( rowOrcol == 'row' && __y.length > 1 ){ 
    
                    const useID =  __y[0].no;
                    //const useRow = __y[__y.length-1].position.y;
                    let useRow = 0;
    
                    __itemDBs = this.gripDB[this.last.gridIDX].items;
    
                    __y.forEach((_item)=>{
                        __itemDBs.some((item,idx)=>{                         
                            if(item.no == _item.no){
                                useRow += Number(item.row);
                                return true;
                            }  
                        });
                    }); 
    
                    __y.forEach((_item)=>{
                        __itemDBs.some((item,idx)=>{                         
                            if(item.no == _item.no){
                                if( item.no == useID ) item.row = useRow;
                                else                   delete __itemDBs[idx];
                                return true;
                            }  
                        });
                    });
    
    
                }else if( rowOrcol == 'col' && __x.length > 1 ){
    
                    const useID =  __x[0].no;
                    //const useCol = __x[__x.length-1].position.x;
                    let useCol = 0;
    
                    __itemDBs = this.gripDB[this.last.gridIDX].items;
    
                    __x.forEach((_item)=>{
                        __itemDBs.some((item,idx)=>{                         
                            if(item.no == _item.no){
                                useCol += Number(item.col);
                                return true;
                            }  
                        });
                    });      
    
                    __x.forEach((_item)=>{
                        __itemDBs.some((item,idx)=>{                         
                            if(item.no == _item.no){
                                if( item.no == useID ) item.col = useCol;
                                else                   delete __itemDBs[idx];
                                return true;
                            }  
                        });
                    });                         
    
                }
    
    
    
                if(__itemDBs == null){
    
                    result = "fail";
                    msg = "no-data";
    
                }else{
    
                    this.gripDB[this.last.gridIDX].items = __itemDBs.filter((itm, i) => itm !== undefined);
    
                    this.set_grid(this.last.gridIDX);
    
                    this.delBlockedY(this.last.gridIDX);
    
                    this.delBlockedX(this.last.gridIDX);
    
                    this.replaceTable( wrap , this.last.gridIDX);  
    
                    //console.log( this.gripDB[this.last.gridIDX] );
    
                }
    
            }      
    
            return  {"result":result , "msg":msg };
    
        }
        ,
        delBlockedX(val=0){
    
            const __data = this.gripDB[val].result;
            const __itemDBs = this.gripDB[val].items;
    
            const delCount = 1;
    
            let backupIdx = new Array();
    
            __data[0].forEach((_lineCheck , _idxCheck )=>{
    
                const _totalRow = this.gripDB[val].totalRow;
    
                if( _lineCheck == this.blankAreaID ){               
    
                    //console.log( "_lineCheck" , _idxCheck  );
    
                    let rowCnt = 0;
                    let __y = new Array();
    
                    __data.forEach((_line , _idx )=>{
    
                        if( _line[_idxCheck] == this.blankAreaID ){
    
                            rowCnt++;
    
                            let _while = true;
                            let _cnt = _idxCheck;                            
                            while(_while){
                                if( _cnt < 0 )_while = false;
                                _cnt--;
                                if( _cnt >= 0 && _line[_cnt] != this.blankAreaID ){
                                    __y.push(_line[_cnt]['no']);
                                    _while = false;
                                }
                            }
    
                        }
    
                    });
    
                    //console.log( "_lineCheckFinish" , _totalRow , rowCnt );
    
                    if( _totalRow == rowCnt ){
    
                        //
                        backupIdx.push(_idxCheck);
                        
                        //
                        __y.forEach((_no)=>{
                            __itemDBs.some((item,idx)=>{                         
                                if(_no == item.no){
                                    item.col -= delCount;
    
                                    //error data fix
                                    item.col = this.delErrorDataFix(item.col);
    
                                    return true;
                                }  
                            });
                        });
    
                        //
                        this.gripDB[val].totalCol -= delCount;
    
                        //error data fix
                        this.gripDB[val].totalCol = this.delErrorDataFix(this.gripDB[val].totalCol);
    
                    }
                }
    
            });
    
    
            //console.log("backupIdx", backupIdx);
    
            //
            __data.forEach((_line , idx)=>{
    
                backupIdx.forEach((idxLine)=>{  
                    delete _line[idxLine];
                });
    
                 __data[idx] = __data[idx].filter((itm) => itm !== undefined);
                
            });
    
        }
        ,
        delBlockedY(val=0){
    
            if( this.gripDB[val] == undefined ) return false;
    
            const _grid = this.gripDB[val];
            const itemDB = _grid.result;
    
            const _tmpData = this.gripDB_NO( val );
    
            const delCount = 1;
    
            //console.log( 'allBlankedCheck' );
            //console.log( 'total',  _grid.totalCol  );
    
            //00 copy
            let _result = structuredClone(_grid.result);
    
            //
            let allLineOnlyOneItem = true;
    
            let delResult = [];
    
            _result.forEach((line , _idx , array )=>{
                const __line = line.filter((itm) => itm !== this.blankAreaID );
    
                
                if(  __line.length > 1 ) allLineOnlyOneItem = false;  
    
                //del row
                if( __line.length == 0 ){
    
                    //del row line
                    //_grid.result.splice(_idx, 1);
    
                    delResult.push(_idx);
    
                    array[_idx-1].forEach((_itm , idx)=>{
    
                        let __item = _tmpData[_itm['no']];                    
    
                        //this line all blank
                        if( _itm == this.blankAreaID ){
    
                            let _while = true;
                            let _cnt = _idx;                            
                            while(_while){
                                if( _cnt < 0 )_while = false;
                                _cnt--;
                                if( _cnt >= 0 && itemDB[_cnt][idx] != this.blankAreaID ){
                                    __item = _tmpData[itemDB[_cnt][idx]['no']];
                                    _while = false;
                                }
                             }
    
                        }
    
                        __item.row -= delCount;
    
                        //error data fix
                        __item.row = this.delErrorDataFix(__item.row);
    
                    });
    
                }
            });
    
            //del row
            //console.log("delResult", delResult);
    
            delResult.reverse().forEach((_idx)=>{
                _grid.result.splice(_idx, 1);
            });
    
            //05 flush temp data
            _result = null;
            
    
           
            //del col  
            if(allLineOnlyOneItem){
           
                _grid.result.forEach((line , idx )=>{    
                    _grid.result[idx]= line.filter((itm, i) => itm !== this.blankAreaID);    
                });
           
                _grid.items.forEach((item)=>{
                    item.col = 1;
                });
           
                this.gripDB[val].result = _grid.result.filter((itm, i) => itm !== undefined);
           
                _grid.totalCol = 1;
            }
            
    
    
    
    
            //
            let cnt = 0;
            _grid.result.forEach((item)=>{
                cnt++;
                item.some((_item)=>{
                    if( _item == this.blankAreaID ) return false;
                    _item.position.y = cnt;
                });
            });
    
    
            //
            _grid.result = _grid.result.filter((itm) => itm !== undefined);
       
            _grid.totalRow =  _grid.result.length;
    
            return;
    
        }
        ,
    
        rowOrcol(itemA,itemB){
    
            let rowOrcol = null;
    
            if( itemA == null || itemB == null ) return null;
            if( itemA == itemB ) return null;
    
            //is row
            if( itemA.position.x == itemB.position.x ){
                rowOrcol = 'row';
            //is col
            }else if( itemA.position.y == itemB.position.y ){
                rowOrcol = 'col';
            }
            return rowOrcol;
        }
        ,
        checkRowOrColAble(target,idx=0,type='add'){
    
            const _tmpData = this.gripDB_NO( idx );
            const this_itemID = this.get_itemid(target);    
    
            let rowOrcol = null;
            let rowOrcolBackup = null;
            let msg = null;
            let itemTarget = null;
    
            let result = "finish";
            let checkNearby = false;
            let nearbyCnt = 0;
    
            document.querySelectorAll(`.${this.wrapName+this.gripDB[idx].no} .${this.tabSelectedClass}`).forEach((item , idx)=>{
                           
    
                if( itemTarget == null ) itemTarget = this_itemID;
                /*
                y : row
                x : col
                */       
                const itemID = this.get_itemid(item);
                
                //i continue;
                if( _tmpData[itemTarget] == _tmpData[itemID] ) return false;
    
    
                rowOrcol = this.rowOrcol(_tmpData[itemTarget],_tmpData[itemID]);
    
                //error
                if(rowOrcol == null ){
                    result = "fail";
                    msg = "no-row_col-data";
                    return true;
                }else if( type =='add' && rowOrcolBackup!= null && rowOrcol != rowOrcolBackup){
                    result = "fail";
                    msg = "mixed-row_col-data";
                    return true;
    
               }else if( type =='add' && rowOrcol == 'row' && ( _tmpData[itemTarget].col != _tmpData[itemID].col ) ){
                    result = "fail";
                    result = "fail";
                    msg = "mismatch-row";
                    return true;
    
                }else if( type =='add' &&  rowOrcol == 'col' && ( _tmpData[itemTarget].row != _tmpData[itemID].row ) ){
                    result = "fail";
                    msg = "mismatch-col";
                    return true;
                }
    
    
                //near by
                if( rowOrcol == 'row' ){
    
                    const dataA = _tmpData[this_itemID].position.y > _tmpData[itemID].position.y ? _tmpData[this_itemID] : _tmpData[itemID];
                    const dataB = _tmpData[this_itemID].position.y > _tmpData[itemID].position.y ? _tmpData[itemID] : _tmpData[this_itemID];
    
                    if( dataA.position.y == dataB.position.y + dataB.row){
    
                        if( type != 'add' &&  this_itemID != itemID ){
                            nearbyCnt++;
                        }
    
                        checkNearby = true;
                    }            
    
                }else if( rowOrcol == 'col' ){
    
                    const dataA = _tmpData[this_itemID].position.x > _tmpData[itemID].position.x ? _tmpData[this_itemID] : _tmpData[itemID];
                    const dataB = _tmpData[this_itemID].position.x > _tmpData[itemID].position.x ? _tmpData[itemID] : _tmpData[this_itemID];
    
                    if( dataA.position.x == dataB.position.x + dataB.col){
    
                        if( type != 'add' && this_itemID != itemID ){
                            nearbyCnt++;
                        }
                        
                        checkNearby = true;
                    } 
    
                }    
                
                //replace and backup
                itemTarget = itemID;
                rowOrcolBackup = rowOrcol;
    
            });
    
            //console.log( rowOrcolBackup , checkNearby );
    
            //check nearby
            if( type =='add' && rowOrcolBackup != null && checkNearby == false){
                result = "fail";
                msg = "no-nearby";
            }
    
            if( type != 'add' && nearbyCnt > 1 ){
                result ='fail';
                msg = 'divide-disabled';
            } 
    
            return  {"result":result , "msg":msg };
            
        }
        ,
        gripDB_NO( idx = 0 ){
    
            const _Array = new Array();
    
            this.gripDB[idx].items.forEach((item)=>{
                _Array[item.no] = item;
            });
    
            return _Array;
        }
        ,
        get_wrapid(wrap){
    
            let wrapID = null;
    
            wrap.classList.forEach((cls)=>{    
                if(cls.includes(this.wrapName) && cls != this.wrapName ) wrapID = cls;
            });
    
            return  wrapID != null ? wrapID.replace(this.wrapName,'') : '';
        }
        ,
        get_wrapidx(wrapID){
    
            let result = null;
            //
            this.gripDB.some((_item ,_idx )=>{
                if( wrapID == _item.no ){
                    result = _idx;
                    return true;                    
                }
            });
            
            return result;
        }
        ,
        set_lastItem(){


            if( this.last.gridIDX == null ) return false;           
            if( this.last.wrapID == null ) return false;           

            const _wrap = document.querySelector(`.${this.wrapName+this.last.wrapID}`);           
            const _item = _wrap.querySelector(`.${this.tabSelectedClass}`);  
            
            if( _item == null ) return false;                

            const _tmpData = this.gripDB_NO( this.last.gridIDX ); 
            const _no = this.get_itemid(_item);
            
            if(_tmpData[ _no ] == undefined) return false;
                
            this.last.itemID = _no;
            this.last.position = _tmpData[ _no ].position;

            return true;
        }
        ,
        set_position(){
    
            if( this.last.position == null ) return false;
    
            let item = null;     
            
            try{         
    
                const itemDB = this.gripDB[this.last.gridIDX].result;      
                item = itemDB[this.last.position.y - 1][this.last.position.x - 1];
    
            }catch(e){
    
            }finally{
    
                if( item == null ) return false;
    
                const _wrap = document.querySelector(`.${this.wrapName+this.last.wrapID}`);           
                const _item = _wrap.querySelector(`.${this.itemName+item.no}`);        
                const _targetClass = _item.classList;            
    
                _targetClass.add(this.tabSelectedClass);   
    
    
                //flush
                this.last.itemID = item.no;
                //this.last.position = null;
    
                //this.get_position();
    
                //console.log("set_position" , this.last);
    
            }
    
            return true;
        }
        ,
        get_position(){
    
            const _this = this;
            let _result = new Array();
    
            const _tmpData = this.gripDB_NO( this.last.gridIDX );
            const _sort = new Array();  
    
            document.querySelectorAll(`.${this.wrapName+this.last.wrapID} .${this.tabSelectedClass}`).forEach((item)=>{
    
                const _no = this.get_itemid(item);
                if(_tmpData[_no] != undefined){
                    const _position = _tmpData[_no].position;    
                    _sort[_position.y * 1000000 + _position.x ] = _position;
                }else{
                    _this.selectflush();
                }                
                                    
            });
    
    
            //
            if( _sort.length == 0 ) return null;        
            
            //
            _result = _sort.filter((itm, i) => itm !== undefined);
    
            return _result.shift();
        }
        ,
        get_itemid(item){
    
            let itemID = null;
    
            const exceptedClassNameArray = [this.itemName,'Col','Row'];
    
            item.classList.forEach((cls)=>{    
                if(cls.includes(this.itemName) && !exceptedClassNameArray.includes(cls) ) itemID = cls;
            });        
    
            return  itemID != null ? itemID.replace(this.itemName,'') : '';
        }
        ,
        set_grid(val=0){
    
            if( this.gripDB[val] == undefined ) return false;
    
            const _data = this.gripDB[val];
    
            //set array
            const _rect = new Array( _data.totalRow );
            for (let i = 0; i < _rect.length; i++) _rect[i] = new Array(_data.totalCol);
    
            let itemIndex = 0;
            let _y = 0;
            let _x = 0;
        
            for( let i=0 ; i < _data.totalCol * _data.totalRow ; i++ ){
    
                const __itm = _data.items[itemIndex];   
                const __col = typeof __itm != 'undefined' ? __itm.col : 1;
                const __row = typeof __itm != 'undefined' ? __itm.row : 1;
    
                // x | y setting
                _x = i % _data.totalCol ;
                if( i > 0 && _x == 0 ) _y++;      
                
                
    
    
                if( typeof _rect[_y][_x] == "undefined"){  
    
                    //add position
                    __itm.position = {x:_x+1,y:_y+1};
    
                    _rect[_y][_x] = __itm;
    
                    itemIndex ++;
                }
    
    
    
    
                //console.log( "test", _x , _y  , __col , __row , itemIndex , _rect[_y][_x]  );
                if( _rect[_y][_x] == this.blankAreaID) continue;
    
    
    
    
                //console.log( "test ", i , __itm.col, __itm.row , __itm   );
    
                //if use row replace blocked text
                if( __row > 1 || __col > 1 ){
                    for( let rowCnt = 0 ; rowCnt < __row ; rowCnt++){
                        for( let colCnt = 0 ; colCnt < __col ; colCnt++){
                            if( typeof _rect[_y + rowCnt][_x + colCnt] == "undefined") _rect[_y + rowCnt][_x + colCnt] = this.blankAreaID;
                            //console.log( "col",_y ,  _x + colCnt , __itm   );
                        }
                    }
                }
                
            }
    
            this.gripDB[val]['result'] = _rect;
        }
        ,
        replaceCustomID( formData='', row =0 , col=0 , test=null ){  

            let addTestTxt = '';
            /*
            addTestTxt += ", no : " + test.no ;
            addTestTxt += ", x : " + test.position.x ;
            addTestTxt += ", y : " + test.position.y ;
            addTestTxt += ", col : " + test.col ;
            addTestTxt += ", row : " + test.row ;
            */

            //add id
            const ids =["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"];
    
            if(formData.includes("${{itemID}}")){
            	
            	return formData.replaceAll("${{itemID}}" , ids[col]+(row+1) + addTestTxt );
        		
        	}else{
        		
        		const formObj = new DOMParser().parseFromString(formData, 'text/html');
        		let formItem = null;
        		try{    
        			formItem = formObj.querySelector(".itemID");  
        		}catch(e){        			
        			//console.log( "fail - saerch.itemID" , e );        			
        		}finally{        			
        			if(formItem== null) return formData;
        			else{        				
        				formItem.innerHTML = formItem.dataset.id = ids[col]+(row+1) + addTestTxt;        				
        				return formObj.body.innerHTML;        				
        			}        			
        		}        		
                
        	}

        }
        ,
        showTable(val=0){
    
            if( this.gripDB[val] == undefined ) return false;
    
            const _data = this.gripDB[val];
    
            const _wrap = document.createElement('table');
    
            if(_data.no){
                _wrap.classList.add(this.wrapName);
                _wrap.classList.add(this.wrapName+_data.no);
                //_wrap.dataset[this.name+"wrap"] = _data.no;    
            } 
    
            if(_data.id) _wrap.id = _data.id;
            if(_data.style) _wrap.style = _data.style;
            if( _data.class != null ){
                    _data.class.forEach((item)=>_wrap.classList.add(item));
            }
            if( _data.dataset != null ){
                for(var key in _data.dataset)
                    _wrap.dataset[key] = _data.dataset[key];                
            }              
    
            _data.result.forEach(((tr,col)=>{
    
                const _tr = document.createElement("tr");                
    
                tr.forEach(((tdh ,row )=>{
    
                    if( tdh == this.blankAreaID ) return true;
    
                    const _tdh = tdh.bold =='y' ? document.createElement("th") : document.createElement("td");
    
                    if(tdh.no){
                        //_tdh.dataset[this.name+"item"] = tdh.no;  
                        _tdh.classList.add(this.itemName);  
                        
                        //_tdh.classList.add(this.itemName+"Col"+tdh.col);  
                        _tdh.classList.add(this.itemName+"Row"+tdh.row);  
    
                        _tdh.classList.add(this.itemName+tdh.no);  
                    }   
    
                    if(tdh.id) _tdh.id = tdh.id;
                    if(tdh.style) _tdh.style = tdh.style;
                    if( tdh.class != null ){
                        tdh.class.forEach((item)=>_tdh.classList.add(item));
                    }
                    if( tdh.dataset != null ){
                        for(var key in tdh.dataset)
                            _tdh.dataset[key] = tdh.dataset[key];                
                    }
    
                    if(tdh.col > 1) _tdh.colSpan = tdh.col;
                    if(tdh.row > 1) _tdh.rowSpan = tdh.row;
    
                    //test add text 777
                    if(tdh.data) _tdh.innerHTML = this.replaceCustomID(tdh.data , col , row , tdh);
    
    
                    _tr.appendChild(_tdh);
        
                }));
    
                _wrap.appendChild(_tr);
    
            }));
    
            return _wrap;
        }
        ,
        showGrid(val=0){

        }
        ,
        get_random(){
            return Math.floor(Math.random() * 10000000000000000);
        }
        ,
    
        flushClass(classList){
    
            let remove =[];
            classList.forEach((cls)=>{    
                if(cls.includes(this.name)) remove.push(cls);  
            });
    
            remove.forEach((_rm)=>{ 
                classList.remove(_rm);
            });
        }
        ,
        flushGridStyle(style){
            Array.from(style).forEach((_stl)=>{            
                if( _stl.includes('grid') ){ 
                    style[_stl] = '';
                } 
            });  
        }
        ,
        _table(item){
    
            const _rows = item.querySelectorAll('tr');
    
            let  _th = false;
            let totalCol = 0;
            let totalRow = _rows.length;
            _rows[0].querySelectorAll('th').forEach((th)=>{
                _th = true;
                totalCol += th.colSpan;
            });
    
            if(_th == false ){
                _rows[0].querySelectorAll('td').forEach((td , array)=>{
                    totalCol += td.colSpan;
                });
            }
    
       
           
    
            //
            this.flushClass(item.classList);
            
            //table 
            let _basic = this.setBasic( item , totalCol , totalRow );
    
            item.querySelectorAll('tr').forEach((tr , _idx)=>{
    
                this.removeTagString(tr);
    
                ['th','td'].forEach((_tar)=>{
    
                    tr.querySelectorAll(_tar).forEach((th)=>{
    
                        //
                        this.flushClass(th.classList);
        
                        //
                        _basic.items.push(this.setItem(th ,_tar =='th'?'y':'n'));
        
                        this.removeTagString(th);     
                        this.skipObj(th);
        
                    });
                });
    
            });        
    
            this.gripDB.push(_basic);
            
    
            return _basic.no;
        }
        ,
        non_table(item){
        }
        ,
    
        setBasic( item , totalCol , totalRow ){
    
            let style = null;
    
            if(item.style.length > 0 )
                style = /(?<=style=['|"])(.*?)(?=['|"])/g.exec(item.outerHTML)[0];

            return{
                no : this.get_random(),
                id : item.id,
                class : Array.from(item.classList) ,
                style : style,
                dataset : Object.assign({}, item.dataset ) ,
                totalCol : totalCol,
                totalRow : totalRow,
                items : [],
            };
        }
        ,
    
        setItem(th , bold ='n'){
    
            let style = null;    
            if(th.style.length > 0 )
                style = /(?<=style=['|"])(.*?)(?=['|"])/g.exec(th.outerHTML)[0];  
    
            return {
                no : this.get_random(),
                id : th.id,
                bold : bold,
                class : Array.from(th.classList) ,
                style : style,
                dataset : Object.assign({}, th.dataset ) ,
                col : th.colSpan,
                row : th.rowSpan,
                data : th.innerHTML,
            };
        }
        ,
    
        copyItem(item , _col = 1 , _id='' , _class =[] , _style='' , _dataset={}  ){
    
            const _item = structuredClone(item);
    
            //hide - row ,  bold       
            return this.clone(  _item , { 
                no : this.get_random()	,   
                id : _id ,	 
                class : _class	, 
                style : _style	,  
                dataset : _dataset	,                 
                col : _col	,				
                data : this.options.defaultForm.replace("${{random}}" ,this.get_random() )	,				           						
            } );
        }
        ,
    
        newItem(item , _bold ='n', _col = 1, _row = 1 , _id='' , _class =[] , _dataset={} , _style='' ){
    
            const _item = structuredClone(item);           
           
            return this.clone(  _item , { 
                no : this.get_random()	,   
                id : _id ,	 
                bold : _bold,
                class : _class	, 
                style : _style	,  
                dataset : _dataset	,                 
                col : _col	,				
                row : _row	,				
                data : this.options.defaultForm.replace("${{random}}" ,this.get_random() )	,				           						
            } );
        }
        ,
        removeTagString(obj){
    
            this.options.removeID.forEach((_rem)=>{
    
                if( _rem.substring(0, 1) == "." ){
                    if( obj.classList.contains(_rem.substring(1)) )
                        obj.classList.remove(_rem.substring(1));
    
                }else if( _rem.substring(0, 1) == "#" ){
                    if(obj.id == _rem.substring(1) )
                        obj.removeAttribute('id');
                }
    
            });
    
            return obj;
        }
        ,
        skipObj(obj){
    
            this.options.skipObj.forEach((_rem)=>{
                if( obj.querySelector(_rem) )
                    obj.innerHTML = obj.querySelector(_rem).innerHTML; 
            });
    
        }

        ,
    
        //error data fix
        delErrorDataFix( number ){
        	//if( number < 1  ) console.log("!!!!!!!delErrorDataFix");
            if( number < 1 ) number = 1;
            return number;
        }  

    }
    ,
    draggableGroupAndSwitchItem :{
        options : {                         
            container : ''
            , 
            group : '.sortAble' 
            ,
            item : '.sortAbleItem'
            ,
            itemDetail : '.moveIcon'
            ,
            direction : 'vertical'
            ,
            containerReuseable : false    
            ,
            containerDraggable : true                   
            ,   
            multiGroup : false 
            ,                      
            itemSwitch : true   
            ,
            switchGroup : '.changeWrap'
            , 
            switchItem : '.containerItem' 
            ,                                           
            switchClass : "tmpSwitch"                    
            ,                       			
            groupClass : "__DC__group"                       
            ,                       			
            targetItemClass : "__DC__target_item"   
            ,                       			
            switchItemClass : "__DC__switch_item"                    
            ,                       			
        }
        ,
        load(){

            this.containers = null;
            this.draggables = null;
            this.direction  = null;
            this.groupClass = this.options.groupClass;
            this.targetItemClass = this.options.targetItemClass;      
            this.switchItemClass = this.options.switchItemClass;      

            this.container_backup = null;
        
            this.startTarget   = "";
            this.startItem     = "";

            this.draggItem     = "";

            this.positionID    = "";
            this.positionStart = "";
            this.positionEnd   = "";  
            this.positionX   = 0;  
            this.positionY   = 0;  

            this.switch = {
                initID : null,
                initHtml : null,
                finishID : null,
                finishHtml : null,
            }

            this.dragTarget = null;

            this.init();
            this.draggStart();

        }
        ,
        draggOn(target =""){
            if(!target)return;
            
            if(this.options.container)
            target.querySelectorAll(`${this.options.container} > ${this.getItem()}`).forEach(function (item, index, arr) {
                item.draggable = true;
            });        

            target.querySelectorAll(`${this.getGroup()} > ${this.getItem()}`).forEach(function (item, index, arr) {
                item.draggable = true;
            });            
        }
        ,
        draggOff(target =""){
            if(!target)return;
            target.querySelectorAll(`${this.getItem()}`).forEach(function (item, index, arr) {
                item.draggable = false;
            });        
        }
        ,
        getTargetItemClass(){
            return this.switch.initID == null ? this.targetItemClass : this.switchItemClass
        }
        ,
        getGroup(){
            return this.switch.initID == null ? this.options.group : this.options.switchGroup
        }
        ,
        getItem(){
            return this.switch.initID == null ? this.options.item : this.options.switchItem
        }
        ,
        targetItemAdd(target =""){
            if(!target)return;  

            target.classList.add( this.getTargetItemClass() );

            this.startItem = target.dataset.no;
        }
        ,
        targetItemFlush(target =""){
            if(!target)return;

            if( this.options.containerReuseable == true && this.containers.querySelector(this.options.container) ) 
                target.remove();
            else 
                target.classList.remove(this.getTargetItemClass());
        }
        ,
        groupClassAdd(target =""){
            if(!target)return;
    
            target.classList.add(this.groupClass);

            this.startTarget = target.dataset.no;
            this.direction   = target.dataset.direction?target.dataset.direction:this.options.direction;
        }
        ,
        groupClassFlush(target =""){
            var _this = this;
            document.querySelectorAll(`${this.options.container}.${this.groupClass} , ${this.getGroup()}.${this.groupClass}`).forEach(function (item, index, arr) {
                if( !target || target != item ){
                    item.classList.remove(_this.groupClass);
                    _this.draggOff(item);
                }
            });
        }
        ,
        initSetID(){

            if(this.options.container)
            document.querySelectorAll(`${this.options.container}`).forEach(function (item, index, arr) {           
                item.dataset.no = "dcgm___"+ Math.floor( Math.random() * 10000000 );                
            });

            document.querySelectorAll(`${this.getGroup()}`).forEach(function (item, index, arr) {           
                item.dataset.no = "dcgm___"+ Math.floor( Math.random() * 10000000 );                
            });
        }
        ,
        setResultStart(){

            if( document.querySelector(`.${this.groupClass}`) == undefined ) return;

            this.positionStart = "";
            this.positionEnd   = "";
            this.positionID    = document.querySelector(`.${this.groupClass}`).dataset.no;

            const _draggables = document.querySelectorAll(`.${this.groupClass} > ${this.getItem()}`);

            for( var i = 0 ; i < _draggables.length ; i++){
                if( _draggables[i].classList.contains(this.getTargetItemClass()) ){
                    this.positionStart = i;						
                    break;
                }				
            }  

        }
        ,
        setResultEnd(type =''){

            //
            const _this = this;

            //switch flush(2/2)
            if( this.dragTarget == "switch"){
                //listen
                document.querySelectorAll(this.options.switchGroup).forEach((item)=>{
                    item.classList.remove('listen');                        
                }); 

            }

            this.dragTarget = null;

            let positionType = document.querySelector(`.${this.groupClass}`).dataset.no == this.positionID ? "sort" : "change";

            //
            if( type ) positionType = type;      

            //
            const _draggables = document.querySelectorAll(`.${this.groupClass} > ${this.getItem()}`);
            for( var i = 0 ; i < _draggables.length ; i++){
                if( _draggables[i].classList.contains(this.getTargetItemClass()) ){
                    this.positionEnd = i;
                    
                    if(positionType == "sort" ){
                        if( this.positionStart > i ){							
                            this.positionEnd   = this.positionStart;
                            this.positionStart = i
                        }  
                    }              

                break;
                }				
            }    
            
            
            //
            if(positionType == "switch" ){                
                
                /**
                 * item 위치 변경시 td안의 데이터를 넣어준다.
                 * @_this.positionID 
                 * @_this.startTarget
                 */  
                CPTable.flushItemData(); 

                CPTable.flushItemsTableID(); 

                CPTable.flushCPCalculator([_this.positionID,_this.startTarget]);

            }
        }
        ,
        containerBackup(){
            if(this.options.containerReuseable ) 
            if(document.querySelector(`${this.options.container}`))
                this.container_backup = document.querySelector(`${this.options.container}`).innerHTML;
            
            //else 
            //   console.log("fail containerBackup no container");
        }
        ,
        containerFlush(){
            if(this.options.containerReuseable && document.querySelector(`${this.options.container}`) ) 
            document.querySelector(`${this.options.container}`).innerHTML =  this.container_backup;
        }
        ,
        getDragAfterElement(event){

            try{

                const draggableElements = [
                    ...this.containers.querySelectorAll(`.${this.groupClass} > ${this.getItem()}:not(.${this.getTargetItemClass()})`),
                ];

                return draggableElements.reduce(
                    (account, currentItem ,index ,array) => {
                        const box = currentItem.getBoundingClientRect();
                        const offset = (
                                        this.direction == 'vertical'
                                        ?
                                        event.clientY - box.top - box.height/2
                                        :
                                        event.clientX - box.left - box.width/2
                                    );      
                                    
                        if (offset < 0 && offset > account.offset) {
                            return { offset: offset, element: currentItem };
                        } else {
                            return account;
                        }
                    },
                    { offset: Number.NEGATIVE_INFINITY },
                ).element;

            }catch(e){
                //console.log(e);
            }
        }
        ,
        init(){ 

            if(!this.options.container) this.options.containerReuseable = false;

            this.initSetID();        
            this.containerBackup();        
        }
        ,
        switchInitFlush(){
            this.switch.initID = null;
            this.switch.initHtml = null;
            this.switch.finishID = null;
            this.switch.finishHtml = null;
        }
        ,
        draggStart(){

            document.addEventListener("mouseup", event => { 

                //switch flush(1/2)
                if( this.dragTarget == "switch"){
                    //listen
                    document.querySelectorAll(this.options.switchGroup).forEach((item)=>{
                        item.classList.remove('listen');                        
                    }); 
                }

                this.dragTarget = null; 
                
            });
            
            document.addEventListener("mousedown", event => {    
                
                //mouse right click
                if ( ("button" in event && event.button == 2) || ("which" in event && event.which == 3) ) return;   
                
                if( this.dragTarget == null && event.target.closest(this.options.switchItem) ){

                    this.dragTarget = "switch";

                    this.draggItem = event.target.closest(this.options.switchItem);
                    this.containers = event.target.closest(this.options.switchGroup);

                    if( this.containers  == null) return;

                    //init
                    this.switch.initID = this.containers;
                    this.switch.initHtml = this.containers.innerHTML; 

                    //listen
                    document.querySelectorAll(this.options.switchGroup).forEach((item)=>{
                        item.classList.add('listen');  
                        //console.log( this.options.switchGroup , item );                      
                    });   

                    
                    this.targetItemAdd(this.draggItem);    
                    this.groupClassAdd(this.containers);
                    this.draggOn(this.containers);   

                    this.draggItem.addEventListener("mouseup", event => {

                        this.switchInitFlush();

                        this.targetItemFlush(this.draggItem);
                        this.groupClassFlush(); 
                        this.draggOff();
                    });
                
                    this.draggItem.addEventListener("dragend", event => {

                        /*
                        check block list start
                        제약 사항 해당 아이템은 테이블의 한 행에 하나만 존재 할 수 있다. 
                        + CPCalculator
                        + CPCalculatorcol
                        + CPCalculatortotal
                        + CPCalculatorglobaltotal
                        */                        
                        const blockingCheckList = [this.switch.initID,this.switch.finishID];
                        const blockedList = ['CPCalculator','CPCalculatortotal','CPCalculatorglobaltotal'];

                        

                        //블록 리스트에 포함되는지 확인한다.
                        let tmpCnt = 0;
                        const pinCode = 1000000;
                        $(blockingCheckList).each((idx,itm)=>{


                            //checking each items data style
                            //const _switchItem = 
                            //console.log("_switchItem" , $(itm).find(`.CPCalculator`) );
                            

                            /*
                            let blockID = null;
                            let blockPinCode = null;
                            //blocked 리스트 여부를 판단
                            $(blockedList).each((idx,blk)=>{
                                const _blk = $(itm).find(`.${blk}`);  
                                if( _blk.length > 0 ){
                                    blockID = blk;
                                    blockPinCode = blockedPinCode[idx];
                                    return false;
                                }  

                            });
                            */

                            

                            

                           
                            /*
                            const _CPCalculatorStyle = $(_CPCalculator).attr("data-style");

                            if( _CPCalculatorStyle == 'row')
                                _CPCalculator = $(itm).closest("tr").find(`.CPCalculator`); 
                            */        
                            const _CPCalculator = $(itm).find(`.CPCalculator`);
                            if( _CPCalculator.length > 0 ){

                                if( idx == 0 ){

                                    const _CPCalculatorStyle = $(_CPCalculator).attr("data-style");
                                    const _nextItem = $(blockingCheckList[1]).find(`.CPCalculator`);
                                    const _nextItemStyle = $(_nextItem).attr("data-style");

                                    //존재하지 않는다면
                                    if( _nextItem.length == 0 ){

                                        tmpCnt += pinCode;
                                        
                                        //타겟 행 혹은 열의 적합성 여부 판단.
                                        if(_CPCalculatorStyle == 'col'){
                                        //col

                                            const _initItemID = CPTable._table.get_itemid(blockingCheckList[0].offsetParent);
                                            const _itemID = CPTable._table.get_itemid(blockingCheckList[1].offsetParent);
                                            let positionX = null; 
                                            let gridIDX = null;  
                                            if( CPTable._table.gripDB.length > 0 && _itemID ){
                                                CPTable._table.gripDB.some((db,idx)=>{

                                                    $(db.items).each((_,itm)=>{
                                                        if(itm.no == _itemID){
                                                            gridIDX = idx;
                                                            positionX = itm.position.x;
                                                            return false;
                                                        }
                                                    });

                                                    if( positionX != null )
                                                    return false;
                                                });
                                            }

                                            if(CPTable.countCpCalculatorCol(_CPCalculatorStyle,[_initItemID], gridIDX, positionX) != 0){                                                
                                                //console.log("wait........ col - 1" , _CPCalculatorStyle , gridIDX, positionX );
                                                tmpCnt += pinCode;
                                            }                                                 
                                            
                                        }else{    
                                        //row                                        
                                            const _tmp = $(blockingCheckList[1]).closest("tr").find(`.CPCalculator`); 

                                            if(_tmp.length > 0 && _CPCalculatorStyle == _tmp.attr("data-style")){

                                                //이동 제약 영역에 동일 아이템이 이동 한다면 하다면 switch가능
                                                if($(_CPCalculator).attr('id') == $(_tmp).attr('id')){
                                                    //console.log("next........ row - 1" , $(_CPCalculator).attr('id') , $(_tmp).attr('id') );
                                                
                                                }else{
                                                    //console.log("wait........ row - 1" , $(_CPCalculator).attr('id') , $(_tmp).attr('id') );
                                                    tmpCnt += pinCode;
                                                }

                                            }
                                        }

                                    }else{

                                        //동일 하다면 switch가능
                                        if( _CPCalculatorStyle == _nextItemStyle){

                                        //동일 하지 않는다면

                                        /*
                                        각각 아이템을 검수 한다.
                                            - row은 tr당 하나만 허용한다.
                                            - col은 td당 하나만 허용한다.
                                        */
                                        }else{

                                            //console.log("wait........ row col - 2,3");

                                            //
                                            tmpCnt += pinCode;

                                            if(_CPCalculatorStyle == 'col'){

                                               // console.log("wait........ col - 2");

                                            }else{

                                                
                                                const _tmp = $(blockingCheckList[1]).closest("tr").find(`.CPCalculator`); 
                                                if(_tmp.length > 0 && _CPCalculatorStyle == _tmp.attr("data-style")){

                                                    //console.log("wait........ row - 2");
                                                    tmpCnt += pinCode;
                                                }

                                            }

                                            if(_nextItemStyle == 'col'){



                                                //console.log("wait........ col - 3");

                                                

                                            }else{

                                                const _tmp = $(itm).closest("tr").find(`.CPCalculator`); 
                                                if(_tmp.length > 0 && _CPCalculatorStyle == _tmp.attr("data-style")){

                                                    //console.log("wait........ row - 3");
                                                    tmpCnt += pinCode;
                                                }

                                            }

                                            


                                        }

                                    }

                                    //stop each
                                    return false;
                                    
                                }else{

                                    //console.log("non........ - 3");
                                    tmpCnt += pinCode;
                                }                                 

                            }else{
                                
                                $(blockedList).each((_,_lst)=>{                                    
                                    if( $(itm).find(`.${_lst}`).length > 0 ){
                                        tmpCnt += 1;
                                    } 
                                });

                            }
                            
                        });

                        //console.log( "---tmpCnt" , tmpCnt );

                        /*
                        let changeAble = false;

                        //동일한 아이템 일경우 위치 교환이 가능하다.
                        if( tmpCnt == (pinCode * 2) ){
                            changeAble = true;
                        }
                        */

                       


                        if( tmpCnt > pinCode ){
                            this.switch.finishHtml = null;
                            CPTable.alert("noSwitch");
                        }
                        //check block list end

               

                        
                        //switch - change data
                        if( this.switch.finishHtml != null )
                        this.switch.initID.innerHTML =  this.switch.finishHtml;

                        if( this.switch.finishHtml != null )
                        this.switch.finishID.innerHTML =  this.switch.initHtml;


                        //
                        if( tmpCnt <= pinCode )
                            CPTable.addTwinkle(this.switch.initID , this.switch.finishID ,"B");

                            
                        this.switchInitFlush();

                        const _tmpLoad = document.querySelectorAll(`.${this.options.switchClass}`);                        
                        for( var i = 0 ; i < _tmpLoad.length ; i++){
                            _tmpLoad[i].remove();
                        }                          
                                        
                        if( !this.draggItem )return;
                        if( document.querySelector(`.${this.groupClass}`) == null ) return;


                        this.setResultEnd('switch');                    
                        this.targetItemFlush(this.draggItem);
                        this.groupClassFlush(); 
                        this.draggOff();   
                        this.containerFlush();
                        this.draggStop();

                    });

                    this.draggItem.addEventListener("dragstart", () => {  

                        this.setResultStart();
                            
                    });

                    return; 
                }
                

                if( this.dragTarget == null && event.target.closest(this.getItem()) ){

                    this.dragTarget = "sort";
                    
                    this.draggItem = event.target.closest(this.getItem());
                    
                    if( this.options.itemDetail && !event.target.closest(this.options.itemDetail) )return;   

                    if( this.options.container && event.target.closest(this.options.container) ) this.containers = event.target.closest(this.options.container);
                    else if( event.target.closest(this.getGroup()) )     this.containers = event.target.closest(this.getGroup());                    

                    if( this.containers  == null) return;
                    
                    this.targetItemAdd(this.draggItem);    
                    this.groupClassAdd(this.containers);
                    this.draggOn(this.containers);   

                    this.draggItem.addEventListener("mouseup", event => {

                        this.targetItemFlush(this.draggItem);
                        this.groupClassFlush(); 
                        this.draggOff();

                    });
                
                    this.draggItem.addEventListener("dragend", event => {  
                                        
                        if( !this.draggItem )return;
                        if( document.querySelector(`.${this.groupClass}`) == null ) return;

                        this.setResultEnd();                    
                        this.targetItemFlush(this.draggItem);
                        this.groupClassFlush(); 
                        this.draggOff();   
                        this.containerFlush();
                        this.draggStop();
                        
                    });

                    this.draggItem.addEventListener("dragstart", () => {  

                        this.setResultStart();
                            
                    });
                    
                }   
            });


            document.addEventListener("dragover", event => {

                event.preventDefault(); 

                let __containers = null;

                //
                if(  
                    this.options.container && 
                    this.options.containerDraggable == false &&
                    event.target.closest(this.options.container)
                ) return;

                //
                if( this.dragTarget == 'switch' && event.target.closest(this.options.switchGroup) ){  

                    //                        
                    if(this.direction == 'vertical' && this.positionY == event.y) return;
                    else if(this.positionX == event.x) return;   
                    
                    this.positionX   = event.x;  
                    this.positionY   = event.y; 
                        
                    __containers = event.target.closest(this.options.switchGroup); 

                    //                       
                    if( this.containers != __containers ){                    
                        this.containers = __containers; 
                        
                        this.groupClassFlush(__containers);
                        this.draggOn(__containers);
                        this.groupClassAdd(__containers);
                    }

                    //switch - last data
                    this.switch.finishID = this.containers;
                    this.switch.finishHtml = this.containers.innerHTML;

                    //
                    const _tmpLoad = document.querySelectorAll(`.${this.options.switchClass}`);  
                        
                    for( var i = 0 ; i < _tmpLoad.length ; i++){
                        if( this.switch.initID != _tmpLoad[i].parentNode )
                        _tmpLoad[i].remove();
                    }  


                    if( this.switch.initID != null && !this.containers.querySelector(`.${this.options.switchClass}`) ){
                        const _div = document.createElement('div');
                        _div.classList.add(this.options.switchClass);
                        _div.innerHTML = '';
                        this.switch.initID.appendChild(_div);                               
                        this.switch.finishID.appendChild(_div);
                    }  

                }



                //
                if( this.dragTarget == 'sort' && (this.options.container && event.target.closest(this.options.container)) || event.target.closest(this.getGroup()) ){

                    //
                    if(this.direction == 'vertical' && this.positionY == event.y) return;
                    else if(this.positionX == event.x) return;     
                    
                    this.positionX   = event.x;  
                    this.positionY   = event.y; 

                    if( this.options.container && event.target.closest(this.options.container) ) __containers = event.target.closest(this.options.container);
                    else if( event.target.closest(this.getGroup()) )__containers = event.target.closest(this.getGroup());
                
                    //
                    if( this.options.multiGroup && this.containers != __containers ){                    
                        this.containers = __containers; 
                        
                        this.groupClassFlush(__containers);
                        this.draggOn(__containers);
                        this.groupClassAdd(__containers);
                    }                        

                    //
                    const afterElement = this.getDragAfterElement(event);
                    const draggable    = document.querySelector(`${this.getItem()}.${this.getTargetItemClass()}`);

                    //
                    if( this.options.containerReuseable == true && event.target.closest(this.options.container) ) return;   
                                                                                        
                    try{
                        if (afterElement === undefined){
                            this.containers.appendChild(draggable);
                        }else{
                            this.containers.insertBefore( draggable, afterElement );                                                      
                        }
                    }catch(e){
                        //console.log(e);
                    }


                }
            });
        }
        ,
        draggStop(){
            this.draggItem = null;
            this.containers = null;
        }       

    }    

}

//
CPTable.init();


/*
엔터키 비활성화
*/
$(document).keypress(function(e) { 

    if (e.keyCode == 13 && e.target.id != undefined){

        if([
            "cptable_row",
            "cptable_delrow",
            "cptable_col",
            "cptable_delcol",
            "cptable_merge",
            "cptable_splitcol",
            "update_add_row",
            "update_del_row",
            "update_add_col",
            "update_del_col",
        ].includes(e.target.id) == true){

            e.preventDefault(); 

        }

    } 
});