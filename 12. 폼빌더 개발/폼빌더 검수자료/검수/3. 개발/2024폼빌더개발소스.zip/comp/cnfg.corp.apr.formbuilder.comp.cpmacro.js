/**
 * 폼빌더 컴포넌트.
 * 
 * 매크로 사용 구분
 * 기존 매크로 DB 조회 및 replace 처리
         CT_DRFT_USR_NM : "기안자" 
        ,CT_DRFT_USR_DEPT : "기안부서" 
        ,CT_DRFT_USR_EMAIL : "기안자이메일" 
        ,CT_DRFT_USR_POS : "직위" 
        ,CT_DRFT_USR_EMPY_NO : "사번" 
        ,CT_DRFT_USR_HP_NO : "휴대폰번호" 
        ,CT_CORP_TEL_NO : "회사대표번호" 
        ,CT_DRFT_DATE : "기안일" 
        ,CT_DRFT_CORP_TEL_NO : "기안자직통번호" 
        ,CT_CORP_FAX_NO : "회사팩스번호" 
        ,CT_CORP_LOGO : "회사로고" 
신규 수정 기안시 프론트에서 매핑 처리.
        ,AP_FORM_NM : { title: "양식명", varb: "$AP_FORM_NM$" }
        ,AP_OPEN_CD_LOCALE_NAME : { title:"공개여부", varb: "$AP_OPEN_CD_LOCALE_NAME$" }
        ,AP_KEEP_YY : { title:"보존연한", varb: "$AP_KEEP_YY$ $AP_KEEP_MM$" }
        ,AP_REFERENCE_INPUT : { title:"참조자", varb: "" }
        ,AP_ADD_FILES : { title:"첨부파일"        , varb: "" }
        ,AP_VIEWER_INPUT : { title:"조회자"        , varb: "" }

        추가
               제목 컴포넌트 id태그명 pv_APPR_DOC_TIT 

기안후 실시간 조회
         AP_APPR_COMP_DTIME : { title: "완료일", varb: "" }
        ,AP_DOC_NO_FORM : { title:"문서번호", varb: "" }
*/
let CPMacro = {

    ALIAS_MAP : null
	,	
	MacroKeyNameMap : {
		///기존 매크로로 조회되는 정보들.
		CT_DRFT_USR_NM : "기안자"
		,CT_DRFT_USR_DEPT : "기안부서"
		,CT_DRFT_USR_EMAIL : "기안자이메일"
		,CT_DRFT_USR_POS : "직위"
		,CT_DRFT_USR_EMPY_NO : "사번"
		,CT_DRFT_USR_HP_NO : "휴대폰번호"
		,CT_CORP_TEL_NO : "회사대표번호"
		,CT_DRFT_DATE : "기안일"
		,CT_DRFT_CORP_TEL_NO : "기안자직통번호"
		,CT_CORP_FAX_NO : "회사팩스번호"
		,CT_CORP_LOGO : "회사로고"
			
			/*
		,AP_APPR_COMP_DTIME : "완료일"
		,AP_DOC_NO_FORM : "문서번호"
		,AP_OPEN_CD_LOCALE_NAME : "공개여부"
		,AP_KEEP_YY : "보존연한"
		,AP_KEEP_MM : "보존연한월"	
		*/
	}
	,
	init(prop){

		CPMacro.ALIAS_MAP = {};
		
		$.each(Object.keys(CPMacro.MacroKeyNameMap), function(i, itm){
    		
			CPMacro.ALIAS_MAP[CPMacro.MacroKeyNameMap[itm]] = itm;
    	});

        this.CP_MACRO_ALIAS = prop.alias;

	}
	,
    getMacroTagChangeData(){
    	
    	let formData = []; //
    	let returnMacValJson = {}; //
    	let valuestr = "";
    	
    	// formData.push({"name": "cont", "value":
		// "CT_DRFT_USR_NM:$CT_DRFT_USR_NM$" });
        let keys = Object.keys(MacroKeyNameMap); // 키를 가져옵니다. 이때, keys 는
													// 반복가능한 객체가 됩니다.
        
        return new Promise((resolve, reject)=>{
        	
	    	$.each(keys, function(i, itm){
	    		
	    		valuestr = valuestr.concat(itm ,":", "$", itm ,"$$");
	    	});
	    	
	    	formData.push({"name": "cont", "value": valuestr });
	    	
			// CPCommon.console.log('formData', formData);
			
			function fetchParseVar(callbackFn){
				
				return $.ajax({
					type: "post",
					url: CPView.url.macrolist,
					data: formData,
					success: function(result) {
						
						return result.cont;
					}
				});
			}
	    	
			fetchParseVar()
			.then(data => {
				
				CPCommon.console.log('previewEditMacroTagChange', data);
	
				if(data.cont){
					
					let ret = data.cont;
					
					ret.split('$').map((itm) => {
	
		                let oitm = itm.split(':');
		                returnMacValJson[ "$"+ oitm[0] + "$" ] = oitm[1];
		                
		            });
					
					resolve( returnMacValJson );
				}
				else{
					reject( false )
				}
			});
		
        })
	}   
	,
    CP_ID : null
    ,
    CP_TYPE : "CPMacro"
    ,
    CP_ITEM_TITLE : null
    ,
    CP_MACRO_ALIAS : null 
    ,
    getAttrView(prop){
    	

        let vwid = "att_tle";
        let template = `<div id="div_${vwid}" class="formbdTitle"><span>${ CPMacro.MacroKeyNameMap[this.CP_MACRO_ALIAS]} 속성</span></div>
            			<ul id="ul_${vwid}" class="formbdMenu">
            				
            				<li>
                                <p class="formbdMenuTit">정렬</p>
                                <div class="formbdMenuCon">
                                    <span title="" class="k-widget k-dropdown k-header" style="width:100%;">
                                        <span unselectable="on" class="k-dropdown-wrap k-state-default">
                                            <span id="disp_cp_cbtext-align" unselectable="on" class="k-input">왼쪽정렬</span><span unselectable="on" class="k-select" aria-label="select"><span class="k-icon k-i-arrow-s"></span></span>
                                        </span>
                                        <select id="cp_cbtext-align" data-role="dropdownlist" style="display: none;">
                                            <option value="left" selected="selected">왼쪽정렬</option>
                                            <option value="center">가운데정렬</option>
                                            <option value="right">오른쪽정렬</option>
                                        </select>
                                    </span>
                                </div>
                            </li>
            			
            			</ul>
            			</div>`;

        let $templ = $(template);

        return $templ;                
    }
    ,
    addCompo(prop){

        this.init(prop);

        this.CP_ITEM_TITLE = CPMacro.MacroKeyNameMap[ prop.alias];
        
        let template = this.getCpHtml(prop);
        
        let $attrview = CPMacro.getAttrView()
        
    

        CPElemParent.addComp({
            cptype: CPMacro.CP_TYPE
            ,cpid: this.CP_ID
            ,template: template
            ,vwtemplate: $attrview
            //,cmmattrarr: ['textAlign']
        });    
		
		
		/*setTimeout(() => {
			let fntselect = $attrview.find('#cp_cbtext-align');
        	fntselect.kendoDropDownList();
		}, 10);*/
        
    }
    ,
    selectComp(prop){

        this.init(prop);
        
        if(prop.cpid){
        	
        	let _ids = prop.cpid.split('_');
        	
        	_ids.pop();
        	
        	let _als = _ids.join("_").replace(this.CP_TYPE, '');
        	
        	this.CP_MACRO_ALIAS = _als;
        	prop.alias = _als;
        }
        
        let $attrview = CPMacro.getAttrView()
        
        CPElemParent.selectComp({
            cptype: CPMacro.CP_TYPE
            ,cpid: prop.cpid
            ,vwtemplate: $attrview
            ,data_attr: prop.data_attr
            //,cmmattrarr: ['textAlign']
        });      
		
		/*setTimeout(() => {
			let fntselect = $attrview.find('#cp_cbtext-align');
        	fntselect.kendoDropDownList();
		}, 10);*/
        
    }
    ,
    getCpHtml(prop){

        let cpid = null;

        if(prop && prop.cpid){
            cpid = prop.cpid;
        }else{
            cpid = this.createCpid();
        }
        
        this.CP_ID = cpid;       
    
        
        return  `
        <div class="${this.CP_TYPE} previewoff tblformbdCon" id="${cpid}"><span>${this.CP_ITEM_TITLE}</span> <button type="button" class="k-button dltBtn groupTrash"></button></div>
        <div class='${this.CP_TYPE} previewon splitWrap' data-id="${cpid}"> 
            <div class="splitBlock">          

                <!-- 스크립트 입력 -->
                <span id="pv_${this.CP_MACRO_ALIAS}" class="fb-view-tx-df">$${this.CP_MACRO_ALIAS}$</span>


            </div>
        </div>
        `;

    }
    ,
    createCpid(){

        return CPMacro.CP_TYPE + this.CP_MACRO_ALIAS  + '_' + Math.floor(Math.random() * 10000);

    }
    
    
}
