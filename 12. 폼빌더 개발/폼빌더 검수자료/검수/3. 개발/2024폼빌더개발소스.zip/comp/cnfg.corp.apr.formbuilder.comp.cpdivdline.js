/**
 * 폼빌더 컴포넌트.
 * 
 * 속성 : 높이
*/
let CPDivdline = {

    CP_ID : null
    ,
    CP_TYPE : "CPDivdline"
    ,
    CP_ITEM_TITLE : "구분선"
    	
    ,
    MAX_SIZE : 10

    ,
    getAttrView(prop){

        let vwid = "att_tle";
        let template = `<div id="div_${vwid}" class="formbdTitle"><span>구분선컴포넌트 속성</span></div>
                        <ul id="ul_${vwid}" class="formbdMenu">
                            
                            <li>
                                <p class="formbdMenuTit">두께</p>
                                <div class="formbdMenuCon">
                                    
                                    <input id="cp_txheight" data-id="${this.CP_ID}" name="" style="width:70%;" class="k-textbox mL5" type="number" value="1" >
                                    <span>&nbsp;&nbsp;px</span>
                                    
                                </div>
                            </li>
                            <li>
                                <p class="formbdMenuTit">상하간격</p>
                                <div class="formbdMenuCon">
                                    
                                    <input id="cp_txhmargin" data-id="${this.CP_ID}" name="" style="width:70%;" class="k-textbox mL5" type="number" value="10" >
                                    <span>&nbsp;&nbsp;px</span>
                                    
                                </div>
                            </li>
                            
                        </ul>`;

        let $templ = $(template);

        $templ.find('#cp_txheight').on('keyup', function(txe){
        	
            let txcpid = $(txe.target).attr('data-id');

            let inputval = $(txe.target).val();
            
            if(Number(inputval) < 0){
            	inputval = Number(inputval) * -1;
            	$(txe.target).val(inputval);
            }
            
            if(inputval > CPDivdline.MAX_SIZE){
            	
            	$(this).val(CPDivdline.MAX_SIZE);

                layCmn.alert({
                    msg: `가능값을 초과했습니다.  ${CPDivdline.MAX_SIZE}이하로 입력하세요.`,
                    callback: function (e) { }
                });
               
                return;
            }
            
            inputval += 'px';
            if(inputval ){

                $("#pv_"+ txcpid).css( "height", inputval);

            }

            $('#cp_txheight' ).trigger( 'change' );
            
        });
        $templ.find('#cp_txhmargin').on('keyup', function(txe){
        	
            let txcpid = $(txe.target).attr('data-id');

            let inputval = $(txe.target).val();
            
            if(Number(inputval) < 0){
            	inputval = Number(inputval) * -1;
            	$(txe.target).val(inputval);
            }
            
            if(inputval > CPDivdline.MAX_SIZE){
            	
            	$(this).val(CPDivdline.MAX_SIZE);

                layCmn.alert({
                    msg: `가능값을 초과했습니다.  ${CPDivdline.MAX_SIZE}이하로 입력하세요.`,
                    callback: function (e) { }
                });
               
                return;
            }
            
            
        });

        return $templ;                
    }
    ,
    addCompo(prop){

        let template = this.getCpHtml(prop);
        
        let $attrview = CPDivdline.getAttrView()

        CPElemParent.addComp({
            cptype: CPDivdline.CP_TYPE
            ,cpid: this.CP_ID
            ,template: template
            ,vwtemplate: $attrview
        });                    
        
    }
    ,
    selectComp(prop){
        
        let $attrview = CPDivdline.getAttrView()

        CPElemParent.selectComp({
            cptype: CPDivdline.CP_TYPE
            ,cpid: prop.cpid
            ,vwtemplate: $attrview
            ,data_attr: prop.data_attr
        });                  
        
    }
    ,
    getCpHtml(prop){

        let cpid = null;

        if(prop && prop.cpid){
            cpid = prop.cpid;
        }else{
            cpid = this.createCpid();
        }
        
        this.CP_ID = cpid;
        
        return  `
        <div class="${this.CP_TYPE} previewoff tblformbdCon" id="${cpid}"><span>${CPDivdline.CP_ITEM_TITLE}</span> <button type="button" class="k-button dltBtn groupTrash"></button></div>
        <div class='${this.CP_TYPE} previewon splitWrap' data-id="${cpid}" id="pv_${cpid}" style="background:#ddd;width:100%;height:1px;margin-top:10px;margin-bottom:10px;"> 

        </div>
        `;

    }
    ,
    createCpid(){

        return CPDivdline.CP_TYPE + '_' + Math.floor(Math.random() * 10000);

    }
    
    
}
